# Gevent Clicker Pack

Resource pack pour Minecraft **26.2** (format 88), à utiliser avec le plugin Gevent_Clicker.

## v4 — isolation via police custom (changement majeur)

Les versions précédentes retexturaient `generic_54.png` (le fond de TOUS les coffres/conteneurs
6 lignes du jeu), ce qui affectait aussi les vrais coffres — pas seulement `/clicker`. C'est
corrigé dans cette version avec une technique différente :

**Les vrais coffres, grands coffres, barils etc. sont maintenant 100% vanille.** Le fichier
`generic_54.png` n'est plus modifié du tout.

**L'interface `/clicker` garde son thème sombre/doré**, mais via un mécanisme différent : au lieu
de retexturer un fichier partagé, le plugin donne à SON inventaire un titre composé de deux
caractères spéciaux, invisibles en temps normal, qui — uniquement grâce à une police custom
définie dans ce pack — dessinent l'intégralité du fond de panneau à la place du texte. Comme les
vrais coffres utilisent leur propre titre ("Coffre", "Grand coffre"...) et jamais ces caractères
ni cette police, ils ne sont jamais concernés.

### Comment ça marche techniquement

- `assets/gevent_clicker/font/clickerbg.json` définit deux glyphes dans une police custom
  (`gevent_clicker:clickerbg`) :
  - un premier caractère invisible avec une largeur **négative** (-8), qui annule le décalage
    horizontal par défaut du titre dans l'interface (normalement 8px depuis le bord gauche) ;
  - un second caractère dont le "glyphe" n'est pas une lettre mais l'image entière du panneau
    (`textures/font/clicker_panel.png`), agrandie pour couvrir tout le fond de l'interface.
- Le plugin définit le titre de son inventaire comme cette paire de caractères, avec cette police.
  Résultat : à la place du texte, le jeu affiche l'image en fond, uniquement pour ce menu.
- Le titre "Gevent Clicker" que tu voyais avant est maintenant **incrusté directement dans
  l'image** (plus besoin du texte-titre vanille, qui sert désormais uniquement à invoquer l'image).

## v15 — correction mesurée du slot, hotbar renforcée, accents agrandis

- **Faux slot** : j'ai mesuré précisément l'écart directement sur ton dernier screenshot (analyse
  pixel par pixel) plutôt que de deviner. Écart réel trouvé : moins de 2px à l'échelle réelle.
  Correction appliquée en conséquence. Note : le bloc de terre est rendu en perspective 3D
  isométrique par le jeu, ce qui peut le faire paraître visuellement "pas centré" même dans une
  case parfaitement centrée — la correction restante ne pourra pas totalement compenser cet effet
  de perspective.
- **Hotbar** : liseré blanc pur, deux fois plus épais, pour bien se détacher du reste.
- **Accents du faux slot** : agrandis et épaissis pour plus d'impact (déjà en blanc pur à 255,
  impossible d'aller plus clair que ça — la vraie limite pour "plus lumineux" est la teinte,
  pas l'opacité).

## ⚠️ "Inventaire" : limite technique confirmée, définitivement

Nouvelle vérification faite : il n'existe pas d'API Bukkit pour supprimer ou personnaliser ce
texte spécifique. Il est câblé en dur côté client Minecraft et se dessine systématiquement
par-dessus notre image de fond, quel que soit son contenu ou son opacité. Les tentatives de patch
précédentes ne pouvaient techniquement pas fonctionner, et je ne retenterai pas une approche que
je sais vouée à l'échec. Je suis désolé de ne pas avoir de solution ici.

## Ce que fait le pack par ailleurs (inchangé)

- **Pointeur de souris** : raccourci hotbar en curseur, recentré, sans artefact de couleur.
- **Bordures de slots invisibles** : dans l'interface `/clicker` spécifiquement (le fond custom
  couvre toute la zone, donnant un rendu uni). Les vrais coffres gardent leurs bordures normales.
- **Halos doux** derrière la fiole d'xp (aqua) et la pelle "Clicker Upgrader" (violet).
- Bloc de terre (Fric) toujours sans halo — rendu 3D du jeu, risque de casser son apparence.

## Compatibilité sans le pack

Sans ce resource pack, le titre de `/clicker` s'affiche simplement comme du texte brut (les deux
caractères de la zone Unicode privée, quasi invisibles) plutôt que l'image — rien de cassé, juste
moins joli. Tous les autres items (raccourci hotbar, fiole, pelle) restent également fonctionnels
sans le pack, avec leur apparence vanille normale.

## v31 — "Changer de mode de jeu" avec le bouton Quest of Success

- Nouvelle police `gevent_global:portalbg_qos` (`assets/gevent_global/font/portalbg_qos.json`) et ses
  9 tuiles `cmjq_r{1-3}_c{1-3}.png` : même découpage et mêmes réglages que `portalbg`, avec en plus le
  bouton orange « Quest of Success » à droite de « Gevent Clicker » (slots 24, 25, 26, 33, 34, 35).
- L'ancienne police `portalbg` et ses tuiles `cmj_*` restent inchangées dans le pack (inutilisées
  par Gevent_Global depuis sa version 0.1.0.37).
- Dimensions des tuiles vérifiées : 180/180/174 px de large, 225/225/222 px de haut (< 256 px d'atlas).

## v32 — Quêtes de Quest of Success (pages colorées) et skin d'Orel Tût

- Six pages de livre custom (item de base `minecraft:paper`, `custom_model_data` de type chaîne) :
  `qos_page_verte`, `qos_page_rouge`, `qos_page_orange`, `qos_page_jaune`, `qos_page_cyan` (pages
  « bleues » de `/adminq`) et `qos_page_gris` (étapes d'une quête). Modèles
  `assets/minecraft/models/item/qos/page_*.json`, textures `assets/minecraft/textures/item/qos/page_*.png`
  (32 × 32 px, vérifiées), cas ajoutés à la fin de `assets/minecraft/items/paper.json`.
- Skin du PNJ « Orel Tût » : `assets/minecraft/textures/entity/player/wide/orel_tut.png` (64 × 64 px,
  modèle « wide », bras de 4 px). Le plugin QoS y fait référence via l'identifiant de texture
  `entity/player/wide/orel_tut` (profil de l'entité Mannequin). Sans ce pack, le PNJ garde un skin par défaut.

## v33 — Métier de joaillier : presse futuriste, interface de la presse et gemmes

- **Presse** (structure 3 × 3 × 4 blocs) : texture `assets/minecraft/textures/item/qos/presse.png` (128 × 128) et
  4 modèles d'objet Java converti depuis `presse.bbmodel` : `presse_static` (socle, colonnes, sommet),
  `presse_plaque`, `presse_verin1`, `presse_verin2` (les trois pièces mobiles de l'animation). Les modèles sont à
  **demi-échelle** (limite de 48 unités des modèles Java) : le plugin les affiche avec des entités
  `item_display` agrandies × 2. Cas `custom_model_data` (chaîne, item de base `minecraft:paper`) :
  `qos_presse_static`, `qos_presse_plaque`, `qos_presse_verin1`, `qos_presse_verin2`.
  Le masque lumineux `presse_glowmask.png` n'est pas utilisé (pas d'émission possible en vanilla).
- **Gemmes** (10) : `qos_gemme_{charbon,cuivre,fer,or,amethyste,quartz,diamant,emeraude,netherite,nether_star}`,
  textures `assets/minecraft/textures/item/qos/gemme_*.png` (32 × 32, ou 32 × 512 / 32 × 768 pour les trois animées,
  avec leur `.mcmeta` conservé).
- **Interface de la presse** : police `qos:pressebg` (`assets/qos/font/pressebg.json`), un seul glyphe
  `` = `assets/qos/textures/font/presse_panel.png` (176 × 166, recadrage du haut-gauche de `presse.png`),
  qui recouvre l'interface de fourneau ; `` = espace de -1 px (le titre d'un fourneau est centré :
  glyphe de 177 px + (-1) = 176 px, donc le fond démarre exactement au bord gauche). Les sprites `pression.png` et
  `progression.png` ne sont pas utilisés (un titre de fenêtre ne peut pas être animé sans rouvrir l'interface).

### v33.1 — correctif d'affichage (écrans magenta)
Les nouveaux modèles (presse, gemmes) sont sortis de `items/paper.json` : un modèle fautif y invalidait
tout l'item « papier » (hotbar, fonds du menu « Changer de mode de jeu »…). Ils ont désormais leurs propres
définitions : `items/prismarine_shard.json` (10 gemmes `qos_gemme_*`) et `items/heart_of_the_sea.json`
(4 parties de la presse `qos_presse_*`). `paper.json` retrouve ses 100 cas d'origine + les 6 pages de quêtes.
`presse.png` ré-enregistrée sans le bloc de métadonnées `caBX`. Nécessite QoS 0.1.0.12.

### v33.2 — UV de la presse
Les coordonnées UV des 4 modèles `presse_*` étaient exprimées en pixels de la texture 128 x 128 ; le format Java
attend toujours du 0-16 (indépendant de la résolution) : modèles invalides, donc cube magenta. UV divisés par 8,
`texture_size` ramené à [16, 16].

### v34 — Barres de progression de la presse
L'interface de la presse est maintenant un **fumoir** (QoS 0.1.0.13) : sa flamme devient le logo de presse
(remplissage pendant l'écrasement, 5 s) et sa flèche la barre de progression (10 s).
- `textures/gui/sprites/container/smoker/lit_progress.png` (logo) et `burn_progress.png` (flèche) : sprites remplis.
- (`textures/gui/container/smoker.png` a été retiré en v35 : voir ci-dessous.)

## v35 — Autel d'armure (QoS 0.1.0.14) et correctif du fumoir

- **Correctif** : `textures/gui/container/smoker.png` (fond du fumoir) est supprimé : il appliquait l'interface de
  la presse à tous les vrais fumoirs. Le glyphe `presse_panel.png` est régénéré : ses deux trous ne suivent plus
  des rectangles mais exactement les pixels opaques des sprites `lit_progress` (14 x 14, en 56,36) et
  `burn_progress` (24 x 16, en 79,34). Les vrais fumoirs gardent leur fond vanilla ; seules leur flamme et leur
  flèche reprennent les sprites du pack (logo de presse et barre cyan).
- **Autel** (structure 3 x 3 x 5 blocs) : texture `textures/item/qos/autel.png` (128 x 128) et 6 modèles Java
  convertis depuis `autel_gemmes.bbmodel`, à demi-échelle (affichés avec des `item_display` x 2) : `autel_base`,
  `autel_anneau`, `autel_bras` (un seul modèle, affiché 4 fois avec un lacet de 45/135/225/315 degrés),
  `autel_avantbras`, `autel_laser`, `autel_eclairs`. Les rotations des groupes (lacet des bras, inclinaison de
  -5 degrés des avant-bras, rotation des éclairs) et l'animation `activer` sont calculées par le plugin.
  Cas `custom_model_data` (item de base `minecraft:nether_brick`, fichier `items/nether_brick.json`) :
  `qos_autel_base`, `qos_autel_anneau`, `qos_autel_bras`, `qos_autel_avantbras`, `qos_autel_laser`,
  `qos_autel_eclairs`.
- **Interface de l'autel** : police `qos:autelbg` (`assets/qos/font/autelbg.json`), glyphe unique `` =
  `assets/qos/textures/font/autel_panel.png` (176 x 166, recadrage de `interface_autel/autel.png`), qui recouvre
  l'interface de meule. Le glyphe est opaque : le sprite d'erreur de la meule et le fond vanilla sont cachés. Les
  sprites `progression.png` et `erreur.png` ne sont pas utilisés (la meule n'a pas de barre de progression).
- **Bouton de confirmation** (slot du bas) : `echo_shard` + `qos_btn_percer` (actif) et `qos_btn_percer_off`
  (inactif), modèles `item/qos/btn_percer*.json`, textures `btn_percer*.png` (16 x 16, à remplacer par vos icônes).
- **Ligne de lore « Emplacement de gemme disponible »** : police `qos:icons` (`assets/qos/font/icons.json`), glyphe
  `` = `assets/qos/textures/font/slot_gemme.png` (carré gris 8 x 8).

### v35.1 — Interface de l'autel recalée
Le titre d'une meule est aligné à gauche (à 8 px du bord) et non centré comme celui d'un fourneau : le glyphe
`autel_panel.png` était décalé de 8 px vers la droite. Un espace de -8 px (`\uf808`) est ajouté dans
`assets/qos/font/autelbg.json` ; le titre devient `\uf808 \ue000 \uf801`. Nécessite QoS 0.1.0.15.

## v36 — Assembleur de gemmes (QoS 0.1.0.16)

- **Canon à plasma** (structure 3 x 5 x 3) : texture `textures/item/qos/canon_plasma.png` (128 x 128) et 10 modèles
  Java à demi-échelle (affichés x 2) : `canon_base`, `canon_tube`, `canon_laser`, `canon_impact`, `canon_cables`,
  `canon_voyants`, `canon_bobine1..4`. Cas `custom_model_data` `qos_canon_*` dans `items/nether_brick.json`.
  Animation calculée par le plugin.
- **Interface** (tailleur de pierre) : police `qos:canonbg` (`assets/qos/font/canonbg.json`), glyphe `` =
  `assets/qos/textures/font/canon_panel.png` (176 x 166) percé de 11 trous (boutons) et du curseur. Titre
  `  `.
- Sprites `textures/gui/sprites/container/stonecutter/{recipe,recipe_highlighted,recipe_selected,scroller,
  scroller_disabled}.png` remplacés : **les vrais tailleurs de pierre les utilisent aussi**.
- Boutons : `echo_shard` + `qos_btn_valider` (icône provisoire) et `qos_vide` (16 x 16 transparent, pièce fantôme).
