# Gevent Clicker Pack

Resource pack pour Minecraft **26.2** (format 88), à utiliser avec le plugin Gevent_Clicker.

## v4 — isolation via police custom (changement majeur)

Les versions précédentes retexturaient `generic_54.png` (le fond de TOUS les coffres/conteneurs
6 lignes du jeu), ce qui affectait aussi les vrais coffres — pas seulement `/clicker`. C'est
corrigé dans cette version avec une technique différente :

**Les vrais coffres, grands coffres, barils etc. sont maintenant 100% vanille.** Le fichier
`generic_54.png` n'est plus modifié du tout.

**L'interface `/clicker` garde son thème sombre/doré**, mais via un mécanisme différent : au lieu
de retexturer un fichier partagé, le plugin donne à SON inventaire un titre composé de deux
caractères spéciaux, invisibles en temps normal, qui — uniquement grâce à une police custom
définie dans ce pack — dessinent l'intégralité du fond de panneau à la place du texte. Comme les
vrais coffres utilisent leur propre titre ("Coffre", "Grand coffre"...) et jamais ces caractères
ni cette police, ils ne sont jamais concernés.

### Comment ça marche techniquement

- `assets/gevent_clicker/font/clickerbg.json` définit deux glyphes dans une police custom
  (`gevent_clicker:clickerbg`) :
  - un premier caractère invisible avec une largeur **négative** (-8), qui annule le décalage
    horizontal par défaut du titre dans l'interface (normalement 8px depuis le bord gauche) ;
  - un second caractère dont le "glyphe" n'est pas une lettre mais l'image entière du panneau
    (`textures/font/clicker_panel.png`), agrandie pour couvrir tout le fond de l'interface.
- Le plugin définit le titre de son inventaire comme cette paire de caractères, avec cette police.
  Résultat : à la place du texte, le jeu affiche l'image en fond, uniquement pour ce menu.
- Le titre "Gevent Clicker" que tu voyais avant est maintenant **incrusté directement dans
  l'image** (plus besoin du texte-titre vanille, qui sert désormais uniquement à invoquer l'image).

## v15 — correction mesurée du slot, hotbar renforcée, accents agrandis

- **Faux slot** : j'ai mesuré précisément l'écart directement sur ton dernier screenshot (analyse
  pixel par pixel) plutôt que de deviner. Écart réel trouvé : moins de 2px à l'échelle réelle.
  Correction appliquée en conséquence. Note : le bloc de terre est rendu en perspective 3D
  isométrique par le jeu, ce qui peut le faire paraître visuellement "pas centré" même dans une
  case parfaitement centrée — la correction restante ne pourra pas totalement compenser cet effet
  de perspective.
- **Hotbar** : liseré blanc pur, deux fois plus épais, pour bien se détacher du reste.
- **Accents du faux slot** : agrandis et épaissis pour plus d'impact (déjà en blanc pur à 255,
  impossible d'aller plus clair que ça — la vraie limite pour "plus lumineux" est la teinte,
  pas l'opacité).

## ⚠️ "Inventaire" : limite technique confirmée, définitivement

Nouvelle vérification faite : il n'existe pas d'API Bukkit pour supprimer ou personnaliser ce
texte spécifique. Il est câblé en dur côté client Minecraft et se dessine systématiquement
par-dessus notre image de fond, quel que soit son contenu ou son opacité. Les tentatives de patch
précédentes ne pouvaient techniquement pas fonctionner, et je ne retenterai pas une approche que
je sais vouée à l'échec. Je suis désolé de ne pas avoir de solution ici.

## Ce que fait le pack par ailleurs (inchangé)

- **Pointeur de souris** : raccourci hotbar en curseur, recentré, sans artefact de couleur.
- **Bordures de slots invisibles** : dans l'interface `/clicker` spécifiquement (le fond custom
  couvre toute la zone, donnant un rendu uni). Les vrais coffres gardent leurs bordures normales.
- **Halos doux** derrière la fiole d'xp (aqua) et la pelle "Clicker Upgrader" (violet).
- Bloc de terre (Fric) toujours sans halo — rendu 3D du jeu, risque de casser son apparence.

## Compatibilité sans le pack

Sans ce resource pack, le titre de `/clicker` s'affiche simplement comme du texte brut (les deux
caractères de la zone Unicode privée, quasi invisibles) plutôt que l'image — rien de cassé, juste
moins joli. Tous les autres items (raccourci hotbar, fiole, pelle) restent également fonctionnels
sans le pack, avec leur apparence vanille normale.

## v31 — "Changer de mode de jeu" avec le bouton Quest of Success

- Nouvelle police `gevent_global:portalbg_qos` (`assets/gevent_global/font/portalbg_qos.json`) et ses
  9 tuiles `cmjq_r{1-3}_c{1-3}.png` : même découpage et mêmes réglages que `portalbg`, avec en plus le
  bouton orange « Quest of Success » à droite de « Gevent Clicker » (slots 24, 25, 26, 33, 34, 35).
- L'ancienne police `portalbg` et ses tuiles `cmj_*` restent inchangées dans le pack (inutilisées
  par Gevent_Global depuis sa version 0.1.0.37).
- Dimensions des tuiles vérifiées : 180/180/174 px de large, 225/225/222 px de haut (< 256 px d'atlas).

## v32 — Quêtes de Quest of Success (pages colorées) et skin d'Orel Tût

- Six pages de livre custom (item de base `minecraft:paper`, `custom_model_data` de type chaîne) :
  `qos_page_verte`, `qos_page_rouge`, `qos_page_orange`, `qos_page_jaune`, `qos_page_cyan` (pages
  « bleues » de `/adminq`) et `qos_page_gris` (étapes d'une quête). Modèles
  `assets/minecraft/models/item/qos/page_*.json`, textures `assets/minecraft/textures/item/qos/page_*.png`
  (32 × 32 px, vérifiées), cas ajoutés à la fin de `assets/minecraft/items/paper.json`.
- Skin du PNJ « Orel Tût » : `assets/minecraft/textures/entity/player/wide/orel_tut.png` (64 × 64 px,
  modèle « wide », bras de 4 px). Le plugin QoS y fait référence via l'identifiant de texture
  `entity/player/wide/orel_tut` (profil de l'entité Mannequin). Sans ce pack, le PNJ garde un skin par défaut.
