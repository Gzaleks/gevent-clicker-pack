# Gevent Clicker Pack

Resource pack pour Minecraft **26.2** (format 88), à utiliser avec le plugin Gevent_Clicker.

## v4 — isolation via police custom (changement majeur)

Les versions précédentes retexturaient `generic_54.png` (le fond de TOUS les coffres/conteneurs
6 lignes du jeu), ce qui affectait aussi les vrais coffres — pas seulement `/clicker`. C'est
corrigé dans cette version avec une technique différente :

**Les vrais coffres, grands coffres, barils etc. sont maintenant 100% vanille.** Le fichier
`generic_54.png` n'est plus modifié du tout.

**L'interface `/clicker` garde son thème sombre/doré**, mais via un mécanisme différent : au lieu
de retexturer un fichier partagé, le plugin donne à SON inventaire un titre composé de deux
caractères spéciaux, invisibles en temps normal, qui — uniquement grâce à une police custom
définie dans ce pack — dessinent l'intégralité du fond de panneau à la place du texte. Comme les
vrais coffres utilisent leur propre titre ("Coffre", "Grand coffre"...) et jamais ces caractères
ni cette police, ils ne sont jamais concernés.

### Comment ça marche techniquement

- `assets/gevent_clicker/font/clickerbg.json` définit deux glyphes dans une police custom
  (`gevent_clicker:clickerbg`) :
  - un premier caractère invisible avec une largeur **négative** (-8), qui annule le décalage
    horizontal par défaut du titre dans l'interface (normalement 8px depuis le bord gauche) ;
  - un second caractère dont le "glyphe" n'est pas une lettre mais l'image entière du panneau
    (`textures/font/clicker_panel.png`), agrandie pour couvrir tout le fond de l'interface.
- Le plugin définit le titre de son inventaire comme cette paire de caractères, avec cette police.
  Résultat : à la place du texte, le jeu affiche l'image en fond, uniquement pour ce menu.
- Le titre "Gevent Clicker" que tu voyais avant est maintenant **incrusté directement dans
  l'image** (plus besoin du texte-titre vanille, qui sert désormais uniquement à invoquer l'image).

## v12 — retour au panneau unique, couleur très claire, liserés de séparation

Retour à l'approche qui avait fonctionné (panneau unique couvrant toute l'interface, sans
tentative de "trou" vers le jeu) :

- **Couleur nettement éclaircie** : `#E8F5FA`, quasi pastel — poussée volontairement bien
  au-delà du hex demandé à l'origine pour compenser l'assombrissement que le jeu semble
  appliquer aux fonds custom en police. Si ça reste trop sombre à l'écran, dis-le moi et
  j'irai encore plus loin.
- **Deux liserés blancs arrondis** : un autour de la grille du clicker (en haut), un autour
  de ton inventaire réel (en bas) — pour distinguer visuellement les deux zones sans créer de
  vrai "trou" vers le jeu (qui aurait nécessité de toucher au panneau vanilla partagé par tous
  les coffres).
- Fade réduit et faux slot du bloc de terre conservés tels quels.

## Ce que fait le pack par ailleurs (inchangé)

- **Pointeur de souris** : raccourci hotbar en curseur, recentré, sans artefact de couleur.
- **Bordures de slots invisibles** : dans l'interface `/clicker` spécifiquement (le fond custom
  couvre toute la zone, donnant un rendu uni). Les vrais coffres gardent leurs bordures normales.
- **Halos doux** derrière la fiole d'xp (aqua) et la pelle "Clicker Upgrader" (violet).
- Bloc de terre (Fric) toujours sans halo — rendu 3D du jeu, risque de casser son apparence.

## Compatibilité sans le pack

Sans ce resource pack, le titre de `/clicker` s'affiche simplement comme du texte brut (les deux
caractères de la zone Unicode privée, quasi invisibles) plutôt que l'image — rien de cassé, juste
moins joli. Tous les autres items (raccourci hotbar, fiole, pelle) restent également fonctionnels
sans le pack, avec leur apparence vanille normale.
