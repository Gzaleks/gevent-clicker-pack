package fr.geven.clicker.util;

import net.kyori.adventure.text.format.TextColor;

import java.util.Locale;

public final class NumberFormatting {

    /** Couleur "marron", utilisée pour toutes les valeurs de Dirt (ɗ) affichées. */
    public static final TextColor DIRT_COLOR = TextColor.color(0x8B5A2B);

    /** Couleur "jaune", utilisée pour toutes les valeurs d'Ecus affichées. */
    public static final TextColor ECUS_COLOR = TextColor.color(0xFFD700);

    /** Formate un montant entier d'Ecus (sans symbole, le symbole est un glyphe séparé). */
    public static String ecus(long value) {
        return frenchLong(value);
    }

    private NumberFormatting() {
    }

    /** Formate un long avec des espaces comme séparateurs de milliers (ex: 2 000 000 000). */
    public static String frenchLong(long value) {
        return String.format(Locale.US, "%,d", value).replace(',', ' ');
    }

    /** Formate un montant décimal (Dirt) avec le symbole ɗ en suffixe et espaces (ex: 1 234.5ɗ). */
    public static String money(double value) {
        String formatted = String.format(Locale.US, "%,.1f", value).replace(',', ' ');
        return formatted + "ɗ";
    }

    /** Formate un montant entier (prix d'amélioration) avec le symbole ɗ en suffixe (ex: 20 000 000 000ɗ). */
    public static String money(long value) {
        return frenchLong(value) + "ɗ";
    }
}
