package fr.geven.clicker.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Bibliothèque centralisée de têtes customs (skulls avec texture custom), pour toutes les
 * améliorations/items décoratifs du plugin qui en ont besoin.
 *
 * ⚠️ IMPORTANT : je n'ai pas pu récupérer de valeur base64 vérifiée depuis minecraft-heads.com
 * (le site bloque les requêtes automatisées, impossible de la copier moi-même). La structure
 * est prête, mais tu dois toi-même coller la texture que tu veux pour chaque tête ci-dessous.
 *
 * Comment faire :
 *  1. Va sur minecraft-heads.com, trouve la tête que tu veux.
 *  2. Sur sa page, cherche le bloc "Minecraft-URL" ou "Value" (une longue chaîne base64).
 *  3. Colle cette chaîne comme valeur dans la map HEADS ci-dessous, à la clé correspondante.
 *  4. Recompile — c'est tout, aucun autre changement de code nécessaire.
 *
 * Tant qu'une clé n'a pas de valeur valide, {@link #build} se rabat automatiquement sur un
 * item de secours (fourni en paramètre) pour ne jamais afficher une tête cassée/Steve en jeu.
 */
public final class CustomHeads {

    private static final Logger LOGGER = Logger.getLogger("Gevent_Clicker");

    /** Clé -> valeur base64 de la texture (à remplir toi-même, voir instructions ci-dessus). */
    private static final Map<String, String> HEADS = new HashMap<>();

    static {
        // Amélioration tier 1 -> tier 2 de la pelle. Remplace la chaîne vide par la valeur
        // base64 de la tête de ton choix (ex: une tête "flèche vers le haut", "étoile", etc.)
        HEADS.put("SHOVEL_TIER_UP", "");
    }

    private CustomHeads() {
    }

    /**
     * Construit un item tête custom pour cette clé. Si aucune texture valide n'est enregistrée
     * pour cette clé, retourne le fallback fourni à la place (jamais de tête cassée en jeu).
     */
    public static ItemStack build(String key, ItemStack fallback) {
        String base64 = HEADS.get(key);
        if (base64 == null || base64.isBlank()) {
            return fallback;
        }

        try {
            ItemStack item = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) item.getItemMeta();

            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID());
            String decodedJson = new String(Base64.getDecoder().decode(base64), StandardCharsets.UTF_8);
            String url = extractSkinUrl(decodedJson);
            if (url == null) {
                LOGGER.warning("CustomHeads: impossible de lire l'URL de texture pour la clé " + key);
                return fallback;
            }

            PlayerTextures textures = profile.getTextures();
            textures.setSkin(new URL(url));
            profile.setTextures(textures);
            meta.setPlayerProfile(profile);

            item.setItemMeta(meta);
            return item;
        } catch (MalformedURLException | IllegalArgumentException ex) {
            LOGGER.warning("CustomHeads: valeur base64 invalide pour la clé " + key + " (" + ex.getMessage() + ")");
            return fallback;
        }
    }

    /** Extrait grossièrement l'URL "url":"..." du JSON décodé, sans dépendance JSON externe. */
    private static String extractSkinUrl(String decodedJson) {
        int idx = decodedJson.indexOf("\"url\":\"");
        if (idx < 0) return null;
        int start = idx + 7;
        int end = decodedJson.indexOf('"', start);
        if (end < 0) return null;
        return decodedJson.substring(start, end);
    }
}
