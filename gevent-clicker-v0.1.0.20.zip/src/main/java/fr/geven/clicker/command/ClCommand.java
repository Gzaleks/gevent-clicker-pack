package fr.geven.clicker.command;

import fr.geven.clicker.data.GrassManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.ClickerGui;
import fr.geven.clicker.gui.ClickerHolder;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.ShovelTier;
import fr.geven.clicker.util.NumberFormatting;
import fr.geven.clicker.xp.LevelCurve;
import fr.geven.clicker.xp.XpBarSync;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Commande d'administration unifiée pour les tests :
 *   /cl fric give <pseudo> <nombre>
 *   /cl fric remove <pseudo> <nombre>
 *   /cl xp give <pseudo> <nombre>
 *   /cl xp remove <pseudo> <nombre>
 *   /cl reset <pseudo>
 *
 * Réservée aux administrateurs (permission "geventclicker.admin", par défaut OP).
 * Fournit aussi l'auto-complétion (tab) pour chaque mot de la commande.
 *
 * Note : le Fric donné/retiré via cette commande n'est PAS multiplié par le bonus xp
 * (contrairement aux clics normaux) — c'est un ajout brut, pratique pour tester des
 * montants précis.
 */
public class ClCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION = "geventclicker.admin";
    private static final List<String> SUBCOMMANDS =
            List.of("dirt", "xp", "grass", "ecu", "blé", "patate", "reset", "pack", "cleanholograms", "checkpoint");
    private static final List<String> ACTIONS = List.of("give", "remove");
    private static final List<String> CHECKPOINTS = List.of("Grassification");

    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final UpgradeManager upgradeManager;
    private final GrassManager grassManager;
    private final fr.geven.clicker.data.DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final FricScoreboardManager scoreboardManager;
    private final org.bukkit.plugin.java.JavaPlugin plugin;

    private final fr.geven.clicker.listener.CoinSlotsListener coinSlotsListener;
    private final fr.geven.clicker.world.WorldStructuresManager structuresManager;
    private final fr.geven.clicker.world.CoinDoorWorldManager worldManager;
    private final fr.geven.clicker.data.EcusManager ecusManager;
    private final fr.geven.clicker.world.WheatFarmManager wheatFarmManager;
    private final fr.geven.clicker.world.PotatoFarmManager potatoFarmManager;
    private final fr.geven.clicker.world.VoidComposterManager voidComposterManager;

    public ClCommand(org.bukkit.plugin.java.JavaPlugin plugin, PlayerDataManager dataManager, XpManager xpManager,
                      UpgradeManager upgradeManager, GrassManager grassManager,
                      fr.geven.clicker.data.DirtyfyUpgradeManager dirtyfyUpgradeManager,
                      FricScoreboardManager scoreboardManager,
                      fr.geven.clicker.listener.CoinSlotsListener coinSlotsListener,
                      fr.geven.clicker.world.WorldStructuresManager structuresManager,
                      fr.geven.clicker.world.CoinDoorWorldManager worldManager,
                      fr.geven.clicker.data.EcusManager ecusManager,
                      fr.geven.clicker.world.WheatFarmManager wheatFarmManager,
                      fr.geven.clicker.world.PotatoFarmManager potatoFarmManager,
                      fr.geven.clicker.world.VoidComposterManager voidComposterManager) {
        this.plugin = plugin;
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
        this.grassManager = grassManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.scoreboardManager = scoreboardManager;
        this.coinSlotsListener = coinSlotsListener;
        this.structuresManager = structuresManager;
        this.worldManager = worldManager;
        this.ecusManager = ecusManager;
        this.wheatFarmManager = wheatFarmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                              @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Component.text("Tu n'as pas la permission d'utiliser cette commande.", NamedTextColor.RED));
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("reset")) {
            if (args.length != 2) {
                sender.sendMessage(Component.text("Usage : /cl reset <pseudo>", NamedTextColor.RED));
                return true;
            }
            handleReset(sender, args[1]);
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("cleanholograms")) {
            int removed = structuresManager.cleanupStrayHolograms(worldManager.getWorld());
            sender.sendMessage(Component.text(removed + " hologramme(s) orphelin(s) supprimé(s) (chunks chargés uniquement — "
                    + "approche-toi de celui à retirer avant de relancer la commande si besoin).", NamedTextColor.GREEN));
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("checkpoint")) {
            if (args.length != 3) {
                sender.sendMessage(Component.text("Usage : /cl checkpoint <joueur> <checkpoint>", NamedTextColor.RED));
                return true;
            }
            handleCheckpoint(sender, args[1], args[2]);
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("pack")) {
            if (args.length != 2) {
                sender.sendMessage(Component.text("Usage : /cl pack <sha1>", NamedTextColor.RED));
                return true;
            }
            handlePackPush(sender, args[1]);
            return true;
        }

        if (args.length != 4 || !(args[0].equalsIgnoreCase("dirt") || args[0].equalsIgnoreCase("xp")
                        || args[0].equalsIgnoreCase("grass") || args[0].equalsIgnoreCase("ecu")
                        || args[0].equalsIgnoreCase("blé") || args[0].equalsIgnoreCase("patate"))
                || !(args[1].equalsIgnoreCase("give") || args[1].equalsIgnoreCase("remove"))) {
            sender.sendMessage(usage());
            return true;
        }

        String targetName = args[2];
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            sender.sendMessage(Component.text("Joueur introuvable ou hors ligne : " + targetName, NamedTextColor.RED));
            return true;
        }

        boolean give = args[1].equalsIgnoreCase("give");

        if (args[0].equalsIgnoreCase("dirt")) {
            handleFric(sender, target, args[3], give);
        } else if (args[0].equalsIgnoreCase("xp")) {
            handleXp(sender, target, args[3], give);
        } else if (args[0].equalsIgnoreCase("grass")) {
            handleGrass(sender, target, args[3], give);
        } else if (args[0].equalsIgnoreCase("ecu")) {
            handleEcu(sender, target, args[3], give);
        } else if (args[0].equalsIgnoreCase("blé")) {
            handleBle(sender, target, args[3], give);
        } else {
            handlePatate(sender, target, args[3], give);
        }
        return true;
    }

    private void handleGrass(CommandSender sender, Player target, String amountStr, boolean give) {
        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        double delta = give ? amount : -amount;
        double newGrass = grassManager.addGrass(target.getUniqueId(), delta);
        grassManager.saveAsync();
        scoreboardManager.updateGrass(target, newGrass);

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amount + " Grass pour " + target.getName()
                        + " (total : " + newGrass + ")",
                NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Tu as reçu " : "On t'a retiré ") + amount + " Grass (total : " + newGrass + ")",
                    give ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
    }

    private void handleEcu(CommandSender sender, Player target, String amountStr, boolean give) {
        long amount;
        try {
            amount = Long.parseLong(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        long delta = give ? amount : -amount;
        long newEcus = ecusManager.addEcus(target.getUniqueId(), delta);
        ecusManager.saveAsync();
        scoreboardManager.updateEcus(target, newEcus);

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amount + " Ecus pour " + target.getName()
                        + " (total : " + newEcus + ")",
                NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Tu as reçu " : "On t'a retiré ") + amount + " Ecus (total : " + newEcus + ")",
                    give ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
    }

    /** Le Blé est une valeur PARTAGÉE (une seule farm pour tout le monde) : le pseudo cible ne
     *  sert qu'à savoir à qui répondre, pas "à qui" créditer le blé. */
    private void handleBle(CommandSender sender, Player target, String amountStr, boolean give) {
        long amount;
        try {
            amount = Long.parseLong(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        long delta = give ? amount : -amount;
        long newWheat = wheatFarmManager.addWheat(delta);
        wheatFarmManager.saveSync();

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amount + " Blé (stock partagé) — demandé via " + target.getName()
                        + " (total : " + newWheat + ")",
                NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Un administrateur a ajouté " : "Un administrateur a retiré ") + amount
                            + " Blé au stock partagé (total : " + newWheat + ")",
                    give ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
    }

    /** Même principe que le Blé : la Patate est une valeur PARTAGÉE (une seule farm dupliquée). */
    private void handlePatate(CommandSender sender, Player target, String amountStr, boolean give) {
        long amount;
        try {
            amount = Long.parseLong(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        long delta = give ? amount : -amount;
        long newPotato = potatoFarmManager.addPotato(delta);
        potatoFarmManager.saveSync();

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amount + " Patate (stock partagé) — demandé via " + target.getName()
                        + " (total : " + newPotato + ")",
                NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Un administrateur a ajouté " : "Un administrateur a retiré ") + amount
                            + " Patate au stock partagé (total : " + newPotato + ")",
                    give ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
    }

    private void handleReset(CommandSender sender, String targetName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            sender.sendMessage(Component.text("Joueur introuvable ou hors ligne : " + targetName, NamedTextColor.RED));
            return;
        }

        dataManager.resetFric(target.getUniqueId());
        xpManager.resetXp(target.getUniqueId());
        upgradeManager.resetAll(target.getUniqueId());
        grassManager.resetGrass(target.getUniqueId());
        dirtyfyUpgradeManager.resetAll(target.getUniqueId());
        // La Shovel Coin (et les autres pièces) doivent refléter l'état remis à zéro : sinon
        // l'item reste physiquement dans l'inventaire alors que grassificationBought est repassé
        // à false, et le joueur garde l'accès à la porte alors qu'il ne devrait plus l'avoir.
        coinSlotsListener.ensurePresent(target);
        dataManager.saveAsync();
        xpManager.saveAsync();
        upgradeManager.saveAsync();
        grassManager.saveAsync();
        dirtyfyUpgradeManager.saveAsync();

        scoreboardManager.updateFric(target, 0.0);
        scoreboardManager.updateXp(target, 0L);
        scoreboardManager.updateGrass(target, 0.0);
        XpBarSync.sync(target, 0L);
        refreshAllSlots(target);

        sender.sendMessage(Component.text(
                "Progression de " + target.getName() + " remise à zéro (Dirt, xp, Grass, améliorations).",
                NamedTextColor.GREEN));

        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    "Ta progression du Gevent Clicker a été remise à zéro par un administrateur.",
                    NamedTextColor.YELLOW));
        }
    }

    /**
     * Fait avancer (ou reculer) un joueur jusqu'à l'état exact d'un checkpoint nommé, et efface
     * TOUTE progression postérieure à ce point (aujourd'hui : la farm de blé partagée et les
     * Ecus/tier du Void Composter, puisque le seul checkpoint existant — "Grassification" — se
     * situe juste avant que ce contenu n'existe). Un seul checkpoint pour l'instant ; la liste
     * CHECKPOINTS grandira au fur et à mesure que de nouveaux jalons seront définis.
     */
    private void handleCheckpoint(CommandSender sender, String targetName, String checkpointName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            sender.sendMessage(Component.text("Joueur introuvable ou hors ligne : " + targetName, NamedTextColor.RED));
            return;
        }
        if (!checkpointName.equalsIgnoreCase("Grassification")) {
            sender.sendMessage(Component.text("Checkpoint inconnu : " + checkpointName
                    + " (disponibles : " + String.join(", ", CHECKPOINTS) + ")", NamedTextColor.RED));
            return;
        }

        UUID uuid = target.getUniqueId();

        // --- Pelle / bouteille / Strong Upgrades au maximum ---
        UpgradeManager.ShovelState shovel = upgradeManager.getState(uuid);
        shovel.unlocked = true;
        shovel.tier = ShovelTier.TIER_5.tier;
        shovel.purchases = ShovelTier.TIER_5.maxPurchases;
        shovel.bottleUnlocked = true;
        shovel.bottlePurchases = fr.geven.clicker.upgrade.BottleUpgrade.MAX_PURCHASES;
        shovel.strongUpgradeUnlocked = true;
        shovel.fricX2Bought = true;
        shovel.xpX2Bought = true;
        shovel.betterShovelBought = true;
        shovel.betterExperienceBought = true;
        shovel.fricX2_5Bought = true;
        shovel.xpX2_5Bought = true;
        shovel.autoDirtingBought = true;
        shovel.autoDirtingMoreInfoBought = true;
        shovel.moreAutoDirtBought = true;
        shovel.autoDirtingSlotUnlocked = true;
        // Grassification suppose au moins un Dirtyfy effectué (c'est ce qui débloque son shop).
        if (shovel.dirtyfyCount < 1) {
            shovel.dirtyfyCount = 1;
        }
        shovel.infoDiscoveredShovel = true;
        shovel.infoDiscoveredBottle = true;
        shovel.infoDiscoveredStrongUpgrade = true;
        shovel.infoDiscoveredAutoDirting = true;
        shovel.infoDiscoveredDirtyfyUpgrades = true;
        upgradeManager.saveSync();

        // --- Dirtyfy Upgrades au maximum, Grassification achetée ---
        fr.geven.clicker.data.DirtyfyUpgradeManager.State dirtyfy = dirtyfyUpgradeManager.getState(uuid);
        dirtyfy.baseDirtBoosterLevel = fr.geven.clicker.data.DirtyfyUpgradeManager.BASE_DIRT_BOOSTER_MAX;
        dirtyfy.mardiGrassLevel = fr.geven.clicker.data.DirtyfyUpgradeManager.MARDI_GRASS_MAX;
        dirtyfy.experienceAutobuyerBought = true;
        dirtyfy.chagrassLevel = fr.geven.clicker.data.DirtyfyUpgradeManager.CHAGRASS_MAX;
        dirtyfy.fenetreXpBought = true;
        dirtyfy.xpForHomelessLevel = fr.geven.clicker.data.DirtyfyUpgradeManager.XP_FOR_HOMELESS_MAX;
        dirtyfy.grassificationBought = true;
        dirtyfy.grassBaseBoosterLevel = fr.geven.clicker.data.DirtyfyUpgradeManager.GRASS_BOOSTER_MAX;
        dirtyfyUpgradeManager.saveSync();
        coinSlotsListener.ensurePresent(target);

        // --- Tout ce qui vient APRÈS Grassification (côté houe) est effacé ---
        ecusManager.resetEcus(uuid);
        wheatFarmManager.resetAll(worldManager.getWorld());
        wheatFarmManager.setYieldMultiplier(1);
        wheatFarmManager.saveSync();
        potatoFarmManager.resetAll(worldManager.getWorld());
        potatoFarmManager.saveSync();
        voidComposterManager.resetToTierOne(worldManager.getWorld(),
                plugin.getConfig().getInt("composter.x", 10), plugin.getConfig().getInt("composter.y", 1),
                plugin.getConfig().getInt("composter.z", 10));
        // Refait redescendre le champ à sa structure tier 1 (retire la 2e moitié patate).
        structuresManager.refreshFarmPatch(worldManager.getWorld(), false);

        scoreboardManager.updateEcus(target, 0L);
        refreshAllSlots(target);

        sender.sendMessage(Component.text(target.getName() + " ramené au checkpoint « " + checkpointName
                + " » (pelle/bouteille/Strong Upgrades/Dirtyfy Upgrades au max, farm de blé et Void Composter réinitialisés).",
                NamedTextColor.GREEN));
        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    "Un administrateur t'a ramené au checkpoint « " + checkpointName + " ».", NamedTextColor.YELLOW));
        }
    }

    private void handleFric(CommandSender sender, Player target, String amountStr, boolean give) {
        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        double delta = give ? amount : -amount;
        double newFric = dataManager.addFric(target.getUniqueId(), delta);
        dataManager.saveAsync();

        scoreboardManager.updateFric(target, newFric);
        refreshAllSlots(target);

        String amountStrFmt = NumberFormatting.money(amount);
        String totalStr = NumberFormatting.money(newFric);

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amountStrFmt + " pour " + target.getName()
                        + " (total : " + totalStr + ")",
                NumberFormatting.DIRT_COLOR));

        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Tu as reçu " : "On t'a retiré ") + amountStrFmt
                            + " (total : " + totalStr + ")",
                    give ? NumberFormatting.DIRT_COLOR : NamedTextColor.YELLOW));
        }
    }

    private void handleXp(CommandSender sender, Player target, String amountStr, boolean give) {
        long amount;
        try {
            amount = Long.parseLong(amountStr);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Component.text("« " + amountStr + " » n'est pas un nombre valide.", NamedTextColor.RED));
            return;
        }
        if (amount < 0) {
            sender.sendMessage(Component.text("Le nombre doit être positif.", NamedTextColor.RED));
            return;
        }

        long delta = give ? amount : -amount;
        long newXp = xpManager.addXp(target.getUniqueId(), delta);
        xpManager.saveAsync();

        XpBarSync.sync(target, newXp);
        scoreboardManager.updateXp(target, newXp);
        refreshAllSlots(target);

        int newLevel = LevelCurve.levelForXp(newXp);
        String amountStrFmt = NumberFormatting.frenchLong(amount);
        String totalStr = NumberFormatting.frenchLong(newXp);

        sender.sendMessage(Component.text(
                (give ? "+ " : "- ") + amountStrFmt + " xp pour " + target.getName()
                        + " (total : " + totalStr + ", niveau " + newLevel + ")",
                NamedTextColor.GREEN));

        if (!sender.equals(target)) {
            target.sendMessage(Component.text(
                    (give ? "Tu as reçu " : "On t'a retiré ") + amountStrFmt + " xp"
                            + " (total : " + totalStr + ", niveau " + newLevel + ")",
                    give ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        }
    }

    /** Reconstruit tous les slots du GUI (terre/pelle/bouton tier/fiole) selon l'état actuel, si ouvert. */
    private void refreshAllSlots(Player target) {
        Inventory topInventory = target.getOpenInventory().getTopInventory();
        if (!(topInventory.getHolder() instanceof ClickerHolder)) {
            return;
        }

        UUID uuid = target.getUniqueId();
        double fric = dataManager.getFric(uuid);
        long xp = xpManager.getXp(uuid);
        int xpLevel = LevelCurve.levelForXp(xp);
        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        boolean strongUpgradeUnlocked = upgradeManager.isStrongUpgradeUnlocked(uuid);
        fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);
        int baseDirtBoosterLevel = dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel;
        boolean fenetreXpBought = dirtyfyUpgradeManager.getState(uuid).fenetreXpBought;

        topInventory.setItem(ClickerGui.DIRT_SLOT,
                ClickerGui.buildDirtItem(fric, xpLevel, shovelUnlocked, tier, purchases, bottleUnlocked, bottlePurchases,
                        strongUpgrades, baseDirtBoosterLevel, fenetreXpBought));

        if (!shovelUnlocked) {
            topInventory.setItem(ClickerGui.SHOVEL_SLOT, ClickerGui.buildLockedItem(
                    "Pelle", ClickerGui.fricUnlockCondition(ClickerGui.SHOVEL_UNLOCK_FRIC)));
            topInventory.setItem(ClickerGui.SHOVEL_TIER_UP_SLOT, null);
        } else {
            topInventory.setItem(ClickerGui.SHOVEL_SLOT, ClickerGui.buildShovelItem(tier, purchases));
            if (tier.next() != null && purchases >= tier.maxPurchases) {
                topInventory.setItem(ClickerGui.SHOVEL_TIER_UP_SLOT, ClickerGui.buildShovelTierUpItem(tier));
            } else {
                topInventory.setItem(ClickerGui.SHOVEL_TIER_UP_SLOT, null);
            }
        }

        if (!shovelUnlocked) {
            topInventory.setItem(ClickerGui.XP_BOTTLE_SLOT, null);
        } else if (!bottleUnlocked) {
            topInventory.setItem(ClickerGui.XP_BOTTLE_SLOT,
                    ClickerGui.buildLockedItem("Amélioration : Expérience", ClickerGui.TIER2_UNLOCK_CONDITION));
        } else {
            topInventory.setItem(ClickerGui.XP_BOTTLE_SLOT, ClickerGui.buildXpBottleItem(xp, bottlePurchases, strongUpgrades));
        }

        if (bottlePurchases < 1) {
            topInventory.setItem(ClickerGui.STRONG_UPGRADE_SLOT, null);
        } else if (!strongUpgradeUnlocked) {
            topInventory.setItem(ClickerGui.STRONG_UPGRADE_SLOT,
                    ClickerGui.buildLockedItem("Strong Upgrades", ClickerGui.TIER3_UNLOCK_CONDITION));
        } else {
            topInventory.setItem(ClickerGui.STRONG_UPGRADE_SLOT, ClickerGui.buildStrongUpgradeItem());
        }

        if (tier.tier < 4) {
            topInventory.setItem(ClickerGui.AUTO_DIRTING_SLOT, null);
        } else if (!strongUpgrades.autoDirting()) {
            topInventory.setItem(ClickerGui.AUTO_DIRTING_SLOT,
                    ClickerGui.buildLockedItem("Auto Dirting", ClickerGui.AUTO_DIRTING_UNLOCK_CONDITION));
        } else {
            topInventory.setItem(ClickerGui.AUTO_DIRTING_SLOT,
                    ClickerGui.buildAutoDirtingItem(strongUpgrades, xpLevel, shovelUnlocked, tier, purchases));
        }

        boolean tier5Maxed = tier == fr.geven.clicker.upgrade.ShovelTier.TIER_5
                && purchases >= fr.geven.clicker.upgrade.ShovelTier.TIER_5.maxPurchases;
        if (tier.tier < 5) {
            for (int slot : ClickerGui.DIRTYFY_SLOTS) {
                topInventory.setItem(slot, null);
            }
            topInventory.setItem(ClickerGui.DIRTYFY_INFO_SLOT, null);
        } else if (!tier5Maxed) {
            for (int slot : ClickerGui.DIRTYFY_SLOTS) {
                topInventory.setItem(slot, null);
            }
            topInventory.setItem(ClickerGui.DIRTYFY_SLOTS[4],
                    ClickerGui.buildLockedItem("Dirtyfy", ClickerGui.DIRTYFY_UNLOCK_CONDITION));
            topInventory.setItem(ClickerGui.DIRTYFY_INFO_SLOT, null);
        } else {
            for (int slot : ClickerGui.DIRTYFY_SLOTS) {
                topInventory.setItem(slot, null);
            }
            topInventory.setItem(ClickerGui.DIRTYFY_INFO_SLOT,
                    ClickerGui.buildDirtyfyInfoItem(dirtyfyUpgradeManager.getState(uuid).mardiGrassLevel,
                            dirtyfyUpgradeManager.getState(uuid).chagrassLevel));
        }

        int dirtyfyCount = upgradeManager.getDirtyfyCount(uuid);
        if (dirtyfyCount >= 1) {
            topInventory.setItem(ClickerGui.DIRTYFY_UPGRADES_SLOT, ClickerGui.buildDirtyfyUpgradesItem());
        } else if (tier5Maxed) {
            topInventory.setItem(ClickerGui.DIRTYFY_UPGRADES_SLOT,
                    ClickerGui.buildLockedItem("Dirtyfy Upgrades", ClickerGui.DIRTYFY_UPGRADES_UNLOCK_CONDITION));
        } else {
            topInventory.setItem(ClickerGui.DIRTYFY_UPGRADES_SLOT, null);
        }
    }

    /**
     * Repousse le resource pack (URL fixe depuis config.yml, SHA-1 donné en argument) à tous
     * les joueurs déjà connectés, sans avoir besoin de redémarrer le serveur. Les joueurs qui
     * se connecteront après ce push utiliseront toujours celui configuré dans
     * server.properties — pense à le mettre à jour aussi pour rester cohérent.
     */
    private void handlePackPush(CommandSender sender, String sha1) {
        if (!sha1.matches("[a-fA-F0-9]{40}")) {
            sender.sendMessage(Component.text(
                    "SHA-1 invalide : doit faire exactement 40 caractères hexadécimaux.", NamedTextColor.RED));
            return;
        }

        String url = plugin.getConfig().getString("resourcepack.url");
        if (url == null || url.isBlank()) {
            sender.sendMessage(Component.text(
                    "Aucune URL de resource pack configurée (resourcepack.url dans config.yml).",
                    NamedTextColor.RED));
            return;
        }

        int count = 0;
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.setResourcePack(url, sha1);
            count++;
        }

        sender.sendMessage(Component.text(
                "Resource pack repoussé à " + count + " joueur(s) connecté(s). "
                        + "Pense aussi à mettre à jour resource-pack-sha1 dans server.properties "
                        + "pour les prochaines connexions.",
                NamedTextColor.GREEN));
    }

    private Component usage() {
        return Component.text(
                "Usage : /cl <dirt|xp|grass|ecu|blé|patate> <give|remove> <pseudo> <nombre>  |  /cl reset <pseudo>",
                NamedTextColor.RED);
    }

    // ------------------------------------------------------------------
    // Auto-complétion (tab) pour chaque mot de la commande
    // ------------------------------------------------------------------

    @Override
    @Nullable
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                       @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            return List.of();
        }

        String current = args[args.length - 1].toLowerCase();

        if (args.length == 1) {
            return filter(SUBCOMMANDS, current);
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("reset")) {
            if (args.length == 2) {
                return filterPlayers(current);
            }
            return List.of();
        }

        if (sub.equals("checkpoint")) {
            if (args.length == 2) {
                return filterPlayers(current);
            }
            if (args.length == 3) {
                return CHECKPOINTS.stream()
                        .filter(opt -> opt.toLowerCase().startsWith(current))
                        .collect(Collectors.toList());
            }
            return List.of();
        }

        if (sub.equals("dirt") || sub.equals("xp") || sub.equals("grass") || sub.equals("ecu") || sub.equals("blé")
                || sub.equals("patate")) {
            if (args.length == 2) {
                return filter(ACTIONS, current);
            }
            if (args.length == 3) {
                return filterPlayers(current);
            }
            return List.of();
        }

        return List.of();
    }

    private List<String> filter(List<String> options, String current) {
        return options.stream()
                .filter(opt -> opt.startsWith(current))
                .collect(Collectors.toList());
    }

    private List<String> filterPlayers(String current) {
        List<String> names = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase().startsWith(current)) {
                names.add(p.getName());
            }
        }
        return names;
    }
}
