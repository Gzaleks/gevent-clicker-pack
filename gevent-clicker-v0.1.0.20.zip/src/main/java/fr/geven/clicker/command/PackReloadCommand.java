package fr.geven.clicker.command;

import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.UUID;

/**
 * /packreload : repousse le resource pack (url + sha1 lus depuis config.yml) à tous les
 * joueurs actuellement connectés, sans qu'ils aient besoin de se reconnecter et sans
 * redémarrer le serveur. Pratique pour itérer sur le pack pendant les tests.
 *
 * Ne remplace PAS resource-pack=/resource-pack-sha1= dans server.properties : ces valeurs-là
 * restent nécessaires pour les joueurs qui rejoignent APRÈS coup. Après avoir republié le
 * pack sur GitHub, mets à jour les DEUX (server.properties ET config.yml de ce plugin) avec
 * le nouveau SHA-1, puis lance /packreload pour les joueurs déjà en ligne.
 *
 * Réservée aux administrateurs (permission "geventclicker.admin").
 */
public class PackReloadCommand implements CommandExecutor {

    private static final String PERMISSION = "geventclicker.admin";

    private final JavaPlugin plugin;

    public PackReloadCommand(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                              @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Component.text("Tu n'as pas la permission d'utiliser cette commande.", NamedTextColor.RED));
            return true;
        }

        plugin.reloadConfig(); // relit config.yml depuis le disque, au cas où il vient d'être modifié
        String url = plugin.getConfig().getString("resource-pack.url", "");
        String sha1 = plugin.getConfig().getString("resource-pack.sha1", "");

        if (url.isBlank() || sha1.isBlank()) {
            sender.sendMessage(Component.text(
                    "resource-pack.url ou resource-pack.sha1 vide dans config.yml — renseigne les deux d'abord.",
                    NamedTextColor.RED));
            return true;
        }

        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException ex) {
            sender.sendMessage(Component.text("URL invalide dans config.yml : " + ex.getMessage(), NamedTextColor.RED));
            return true;
        }

        ResourcePackInfo info = ResourcePackInfo.resourcePackInfo(UUID.randomUUID(), uri, sha1);
        ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(false)
                .prompt(Component.text("Mise à jour du resource pack Gevent Clicker", NamedTextColor.AQUA))
                .build();

        int count = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendResourcePacks(request);
            count++;
        }

        sender.sendMessage(Component.text(
                "Resource pack repoussé à " + count + " joueur(s) connecté(s).", NamedTextColor.GREEN));
        return true;
    }
}
