package fr.geven.clicker.command;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.GuiOpener;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ClickerCommand implements CommandExecutor {

    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final UpgradeManager upgradeManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public ClickerCommand(PlayerDataManager dataManager, XpManager xpManager, UpgradeManager upgradeManager,
                           DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                              @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Cette commande est réservée aux joueurs.", NamedTextColor.RED));
            return true;
        }

        GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
        return true;
    }
}
