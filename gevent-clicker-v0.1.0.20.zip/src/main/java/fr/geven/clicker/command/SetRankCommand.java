package fr.geven.clicker.command;

import fr.geven.clicker.rank.Rank;
import fr.geven.clicker.rank.RankManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /setrank <pseudo> <rank> : définit directement le rank d'un joueur (n'importe lequel,
 * staff ou non — utile aussi bien pour donner un premier rank staff que pour rétrograder).
 *
 * Réservée aux administrateurs (permission "geventclicker.admin").
 */
public class SetRankCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION = "geventclicker.admin";

    private final RankManager rankManager;

    public SetRankCommand(RankManager rankManager) {
        this.rankManager = rankManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                              @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Component.text("Tu n'as pas la permission d'utiliser cette commande.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 2) {
            sender.sendMessage(Component.text("Usage : /setrank <pseudo> <rank>", NamedTextColor.RED));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(Component.text("Joueur introuvable ou hors ligne : " + args[0], NamedTextColor.RED));
            return true;
        }

        Rank newRank = Rank.fromName(args[1]);
        if (newRank == null) {
            String options = Arrays.stream(Rank.values()).map(r -> r.displayName).collect(Collectors.joining(", "));
            sender.sendMessage(Component.text("Rank inconnu : " + args[1] + ". Ranks disponibles : " + options,
                    NamedTextColor.RED));
            return true;
        }

        Rank oldRank = rankManager.getRank(target.getUniqueId());
        rankManager.setRank(target.getUniqueId(), newRank);
        rankManager.saveAsync();
        rankManager.applyListName(target);

        sender.sendMessage(Component.text(
                target.getName() + " : " + oldRank.displayName + " -> " + newRank.displayName + " !",
                NamedTextColor.GREEN));
        target.sendMessage(Component.text(
                "Tu es maintenant " + newRank.displayName + " !", NamedTextColor.GREEN));

        return true;
    }

    @Override
    @Nullable
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                       @NotNull String alias, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            return List.of();
        }

        if (args.length == 1) {
            String current = args[0].toLowerCase();
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase().startsWith(current))
                    .collect(Collectors.toList());
        }

        if (args.length == 2) {
            String current = args[1].toLowerCase();
            return Arrays.stream(Rank.values())
                    .map(r -> r.displayName)
                    .filter(name -> name.toLowerCase().startsWith(current))
                    .collect(Collectors.toList());
        }

        return List.of();
    }
}
