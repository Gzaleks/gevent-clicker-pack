package fr.geven.clicker.command;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.gui.FarmerInventoryGui;
import fr.geven.clicker.gui.FarmerInventoryHolder;
import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.VoidComposterManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** "/fi" : ouvre directement l'interface "Farmer's Inventory", sans avoir à se déplacer jusqu'au
 *  tonneau. Même garde-fou (Grassification) que le clic sur le tonneau. */
public class FarmerInventoryCommand implements CommandExecutor {

    private final WheatFarmManager wheatFarmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public FarmerInventoryCommand(WheatFarmManager wheatFarmManager, PotatoFarmManager potatoFarmManager,
                                   VoidComposterManager voidComposterManager,
                                   DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.wheatFarmManager = wheatFarmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Commande réservée aux joueurs.", NamedTextColor.RED));
            return true;
        }

        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return true;
        }

        FarmerInventoryHolder holder = new FarmerInventoryHolder();
        player.openInventory(FarmerInventoryGui.create(holder, wheatFarmManager, potatoFarmManager,
                voidComposterManager.getTier() >= 2));
        return true;
    }
}
