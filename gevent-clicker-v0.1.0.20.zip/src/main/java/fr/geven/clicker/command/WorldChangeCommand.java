package fr.geven.clicker.command;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * "/wc <nom du monde>" (worldchange) : téléporte l'admin vers le spawn d'un autre monde.
 * Réservé aux admins (permission geventclicker.admin). La liste des mondes disponibles
 * s'affiche en prévisualisation dans le tchat pendant la frappe grâce à onTabComplete.
 */
public class WorldChangeCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Commande réservée aux joueurs.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1) {
            player.sendMessage(Component.text("Usage : /wc <nom du monde>", NamedTextColor.RED));
            return true;
        }

        World target = Bukkit.getWorld(args[0]);
        if (target == null) {
            player.sendMessage(Component.text("Monde introuvable : " + args[0], NamedTextColor.RED));
            return true;
        }

        Location spawn = target.getSpawnLocation();
        player.teleport(spawn);
        player.sendMessage(Component.text("Téléporté vers le monde \"" + target.getName() + "\".", NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        List<String> worldNames = Bukkit.getWorlds().stream().map(World::getName).collect(Collectors.toList());
        List<String> matches = new ArrayList<>();
        StringUtil.copyPartialMatches(args[0], worldNames, matches);
        return matches;
    }
}
