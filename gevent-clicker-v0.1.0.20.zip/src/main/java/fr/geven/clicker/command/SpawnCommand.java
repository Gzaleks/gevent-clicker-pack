package fr.geven.clicker.command;

import fr.geven.clicker.world.CoinDoorWorldManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** "/spawn" : téléporte instantanément au point de spawn configuré (config.yml : spawn_point),
 *  par défaut (0;1;0) en regardant vers le nord, dans gevent_clicker_world. Disponible à tous. */
public class SpawnCommand implements CommandExecutor {

    private final JavaPlugin plugin;
    private final CoinDoorWorldManager worldManager;

    public SpawnCommand(JavaPlugin plugin, CoinDoorWorldManager worldManager) {
        this.plugin = plugin;
        this.worldManager = worldManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Commande réservée aux joueurs.", NamedTextColor.RED));
            return true;
        }

        World world = worldManager.getWorld();
        if (world == null) {
            player.sendMessage(Component.text("Le monde de spawn n'est pas encore chargé.", NamedTextColor.RED));
            return true;
        }

        var config = plugin.getConfig();
        double x = config.getDouble("spawn_point.x", 0);
        double y = config.getDouble("spawn_point.y", 1);
        double z = config.getDouble("spawn_point.z", 0);
        float yaw = (float) config.getDouble("spawn_point.yaw", 180); // 180 = regarde vers le nord
        float pitch = (float) config.getDouble("spawn_point.pitch", 0);

        player.teleport(new Location(world, x, y, z, yaw, pitch));
        player.sendMessage(Component.text("Téléporté au spawn.", NamedTextColor.GREEN));
        return true;
    }
}
