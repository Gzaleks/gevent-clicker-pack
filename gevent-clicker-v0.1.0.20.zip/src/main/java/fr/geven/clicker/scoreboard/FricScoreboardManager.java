package fr.geven.clicker.scoreboard;

import fr.geven.clicker.util.NumberFormatting;
import fr.geven.clicker.xp.LevelCurve;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.NumberFormat;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Crée et met à jour le scoreboard individuel de chaque joueur, affiché en permanence :
 *  - titre "Gevent Clicker" en bouton doré (image custom, via le resource pack)
 *  - ligne "Dirt" (marron, symbole ɗ) — chiffres en police fine custom
 *  - ligne "Expérience" (aqua, "Niveau X à Y%") — chiffres en police fine custom
 *  - ligne "Grass" (vert clair, icône bloc d'herbe) — obtenu via le Dirtyfy
 *
 * Note technique : un score Minecraft natif n'affiche que des entiers. Pour afficher du texte
 * libre par ligne, chaque ligne est une Team dont le préfixe contient le texte complet, et le
 * nombre de score natif est masqué via NumberFormat.blank().
 */
public class FricScoreboardManager {

    private static final String OBJECTIVE_ID = "gevent_stats";
    private static final String TITLE_TEAM = "gevent_title_line";
    private static final String FRIC_TEAM = "gevent_fric_line";
    private static final String XP_TEAM = "gevent_xp_line";
    private static final String GRASS_TEAM = "gevent_grass_line";
    private static final String ECUS_TEAM = "gevent_ecus_line";
    // Entrées invisibles et uniques pour identifier chaque ligne (ne correspondent à aucun joueur réel).
    // IMPORTANT : ces chaînes ne doivent contenir QUE des codes couleur (§ + caractère de code),
    // jamais de vrai caractère, sinon ce caractère s'affiche en clair sur le scoreboard
    // (c'est le bug des lettres "a"/"b" visibles).
    private static final String TITLE_ENTRY = "\u00A78\u00A79";
    private static final String FRIC_ENTRY = "\u00A70\u00A71";
    private static final String XP_ENTRY = "\u00A72\u00A73";
    private static final String GRASS_ENTRY = "\u00A74\u00A75";
    private static final String ECUS_ENTRY = "\u00A76\u00A77";

    /**
     * Initialise (ou réinitialise) le scoreboard complet d'un joueur.
     *
     * Le "titre" visible est en réalité la ligne de score la plus haute (Team#prefix, comme
     * les autres lignes), pas Objective#displayName — ce dernier ne supporte pas la police
     * bitmap custom (testé, cassé : cases vides). L'objective lui-même reste sans nom visible.
     */
    public void setup(Player player, double fric, long xp, double grass, long ecus) {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();

        Objective objective = scoreboard.registerNewObjective(OBJECTIVE_ID, Criteria.DUMMY, Component.empty());
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        Team titleTeam = scoreboard.registerNewTeam(TITLE_TEAM);
        titleTeam.addEntry(TITLE_ENTRY);
        titleTeam.prefix(Component.text("Gevent Clicker", NamedTextColor.GOLD, net.kyori.adventure.text.format.TextDecoration.BOLD)
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        Score titleScore = objective.getScore(TITLE_ENTRY);
        titleScore.setScore(5); // ligne la plus haute
        titleScore.numberFormat(NumberFormat.blank());

        Team fricTeam = scoreboard.registerNewTeam(FRIC_TEAM);
        fricTeam.addEntry(FRIC_ENTRY);
        fricTeam.prefix(fricLine(fric));
        Score fricScore = objective.getScore(FRIC_ENTRY);
        fricScore.setScore(4);
        fricScore.numberFormat(NumberFormat.blank());

        Team xpTeam = scoreboard.registerNewTeam(XP_TEAM);
        xpTeam.addEntry(XP_ENTRY);
        xpTeam.prefix(xpLine(xp));
        Score xpScore = objective.getScore(XP_ENTRY);
        xpScore.setScore(3);
        xpScore.numberFormat(NumberFormat.blank());

        Team grassTeam = scoreboard.registerNewTeam(GRASS_TEAM);
        grassTeam.addEntry(GRASS_ENTRY);
        grassTeam.prefix(grassLine(grass));
        Score grassScore = objective.getScore(GRASS_ENTRY);
        grassScore.setScore(2);
        grassScore.numberFormat(NumberFormat.blank());

        Team ecusTeam = scoreboard.registerNewTeam(ECUS_TEAM);
        ecusTeam.addEntry(ECUS_ENTRY);
        ecusTeam.prefix(ecusLine(ecus));
        Score ecusScore = objective.getScore(ECUS_ENTRY);
        ecusScore.setScore(1); // ligne du bas
        ecusScore.numberFormat(NumberFormat.blank());

        player.setScoreboard(scoreboard);
    }

    /** Met à jour instantanément la ligne Dirt. */
    public void updateFric(Player player, double fric) {
        Team team = player.getScoreboard().getTeam(FRIC_TEAM);
        if (team == null) return; // scoreboard pas encore initialisé (cas rare)
        team.prefix(fricLine(fric));
    }

    /** Met à jour instantanément la ligne XP. */
    public void updateXp(Player player, long xp) {
        Team team = player.getScoreboard().getTeam(XP_TEAM);
        if (team == null) return; // scoreboard pas encore initialisé (cas rare)
        team.prefix(xpLine(xp));
    }

    /** Met à jour instantanément la ligne Grass. */
    public void updateGrass(Player player, double grass) {
        Team team = player.getScoreboard().getTeam(GRASS_TEAM);
        if (team == null) return;
        team.prefix(grassLine(grass));
    }

    /** Met à jour instantanément la ligne Ecus. */
    public void updateEcus(Player player, long ecus) {
        Team team = player.getScoreboard().getTeam(ECUS_TEAM);
        if (team == null) return;
        team.prefix(ecusLine(ecus));
    }

    private Component ecusLine(long ecus) {
        return ScoreboardFont.render(NumberFormatting.ecus(ecus) + " ", NumberFormatting.ECUS_COLOR)
                .append(ScoreboardFont.ecusIcon(NumberFormatting.ECUS_COLOR));
    }

    private Component fricLine(double fric) {
        return ScoreboardFont.render(NumberFormatting.money(fric), NumberFormatting.DIRT_COLOR);
    }

    private Component xpLine(long xp) {
        int level = LevelCurve.levelForXp(xp);
        int percent = Math.round(LevelCurve.progressInLevel(xp) * 100f);
        return ScoreboardFont.render("Niveau " + level + " à " + percent + "%", NamedTextColor.AQUA);
    }

    private Component grassLine(double grass) {
        return ScoreboardFont.render(Math.round(grass) + " ", NamedTextColor.GREEN)
                .append(ScoreboardFont.grassIcon(NamedTextColor.GREEN));
    }
}
