package fr.geven.clicker.scoreboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.key.Key;

import java.util.Map;

/**
 * Convertit un texte en Component où les CHIFFRES et la ponctuation numérique (. , % : espace)
 * utilisent la police custom "scorefont" (glyphes plus fins que la police par défaut, un peu
 * "cubique"), tandis que le reste (lettres, symboles comme ɗ) reste en police par défaut —
 * ma police custom ne définit QUE les caractères listés ci-dessous, donc lui appliquer tout un
 * texte casserait l'affichage des lettres qu'elle ne connaît pas.
 */
public final class ScoreboardFont {

    private static final Key CUSTOM_FONT = Key.key("gevent_clicker", "scorefont");
    private static final Key DEFAULT_FONT = Key.key("minecraft", "default");

    private static final Map<Character, Character> DIGIT_MAP = Map.ofEntries(
            Map.entry('0', '\uE100'), Map.entry('1', '\uE101'), Map.entry('2', '\uE102'),
            Map.entry('3', '\uE103'), Map.entry('4', '\uE104'), Map.entry('5', '\uE105'),
            Map.entry('6', '\uE106'), Map.entry('7', '\uE107'), Map.entry('8', '\uE108'),
            Map.entry('9', '\uE109'), Map.entry('.', '\uE10A'), Map.entry(',', '\uE10B'),
            Map.entry('%', '\uE10C'), Map.entry(':', '\uE10D'), Map.entry(' ', '\uE10E'),
            Map.entry('N', '\uE10F'), Map.entry('i', '\uE110'), Map.entry('v', '\uE111'),
            Map.entry('e', '\uE112'), Map.entry('a', '\uE113'), Map.entry('u', '\uE114'),
            Map.entry('à', '\uE115'), Map.entry('I', '\uE116'), Map.entry('V', '\uE117'),
            Map.entry('E', '\uE118'), Map.entry('A', '\uE119'), Map.entry('U', '\uE11A')
    );

    private ScoreboardFont() {
    }

    /** Composant du titre "Gevent Clicker" en bouton (image custom). À utiliser en Team#prefix,
     *  PAS en Objective#displayName qui ne supporte pas la police custom (testé, cassé). */
    public static Component title() {
        return Component.text("\uE150").font(CUSTOM_FONT);
    }

    /** Le glyphe icône Grass (petit bloc d'herbe), coloré. */
    public static Component grassIcon(TextColor color) {
        return Component.text("\uE151", color).font(CUSTOM_FONT);
    }

    /** Le glyphe icône Ecus (trois pièces superposées), utilisé pour la monnaie du clicker houe. */
    public static Component ecusIcon(TextColor color) {
        return Component.text("", color).font(CUSTOM_FONT);
    }

    /**
     * Convertit le texte : chaque chiffre/ponctuation numérique passe par la police custom,
     * le reste (lettres, symboles) reste en police par défaut. Un seul appel construit un
     * Component composite avec les bons segments/polices, dans la couleur donnée.
     */
    public static Component render(String text, TextColor color) {
        Component result = Component.empty();
        StringBuilder segment = new StringBuilder();
        Boolean segmentIsCustom = null;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            boolean isCustom = DIGIT_MAP.containsKey(c);

            if (segmentIsCustom != null && segmentIsCustom != isCustom) {
                result = result.append(buildSegment(segment.toString(), segmentIsCustom, color));
                segment.setLength(0);
            }
            segment.append(isCustom ? DIGIT_MAP.get(c) : c);
            segmentIsCustom = isCustom;
        }
        if (segment.length() > 0) {
            result = result.append(buildSegment(segment.toString(), segmentIsCustom, color));
        }
        return result;
    }

    private static Component buildSegment(String text, boolean custom, TextColor color) {
        return Component.text(text, color)
                .font(custom ? CUSTOM_FONT : DEFAULT_FONT)
                .decoration(TextDecoration.ITALIC, false);
    }
}
