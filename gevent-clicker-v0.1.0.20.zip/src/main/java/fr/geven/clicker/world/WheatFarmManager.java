package fr.geven.clicker.world;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * Gère les 10 emplacements de graines de blé de farm_patch : achat auprès du PNJ (shop), pose
 * automatique dans la farm (ligne gauche d'abord, puis ligne droite), pousse chronométrée
 * (indépendante du système vanilla, âge 0-7 calculé à partir du temps écoulé), récolte (clic
 * gauche une fois à 100%) qui alimente le compteur de blé du Farmer's Inventory. État partagé
 * (un seul champ pour tout le monde), persisté dans wheat_farm.yml.
 */
public class WheatFarmManager {

    private static final int SLOT_COUNT = 10;
    private static final int FARM_WIDTH = 5;
    private static final int MAX_AGE = 7;

    private final JavaPlugin plugin;
    private final File dataFile;

    private int farmX0;
    private int farmY;
    private int farmZ0;
    private int growSeconds;
    private int yieldPerHarvest;
    private int sellPricePerUnit;

    private final List<Location> slotLocations = new ArrayList<>();
    private final long[] plantedAtMillis = new long[SLOT_COUNT];
    private int totalPurchased = 0;
    private long wheatCount = 0;
    private volatile boolean dirty = false;
    /** x2 à partir du Void Composter Tier 2 (voir VoidComposterManager). */
    private volatile int yieldMultiplier = 1;

    public WheatFarmManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "wheat_farm.yml");
        for (int i = 0; i < SLOT_COUNT; i++) plantedAtMillis[i] = -1L;
    }

    /** Lit config.yml (farm_patch + wheat_farm) et charge l'état persisté. À appeler dans onEnable
     *  une fois le monde disponible. */
    public void setup(World world) {
        var config = plugin.getConfig();
        this.farmX0 = config.getInt("farm_patch.x", 30);
        this.farmY = config.getInt("farm_patch.y", 1);
        this.farmZ0 = config.getInt("farm_patch.z", 30);
        this.growSeconds = Math.max(1, config.getInt("wheat_farm.grow_seconds", 10));
        this.yieldPerHarvest = Math.max(1, config.getInt("wheat_farm.yield_per_harvest", 1));
        this.sellPricePerUnit = Math.max(1, config.getInt("wheat_farm.sell_price_per_unit", 1));

        // Les graines de blé sont posées UN BLOC AU-DESSUS de la terre labourée (comme en vanilla :
        // la farmland reste intacte à farmY, la culture occupe farmY + 1).
        slotLocations.clear();
        for (int i = 0; i < FARM_WIDTH; i++) {
            slotLocations.add(new Location(world, farmX0 + i, farmY + 1, farmZ0));
        }
        for (int i = 0; i < FARM_WIDTH; i++) {
            slotLocations.add(new Location(world, farmX0 + i, farmY + 1, farmZ0 + 1));
        }

        load();
        reapplyAll(world);
    }

    private void load() {
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        totalPurchased = Math.min(SLOT_COUNT, yml.getInt("total_purchased", 0));
        wheatCount = yml.getLong("wheat_count", 0L);
        for (int i = 0; i < totalPurchased; i++) {
            plantedAtMillis[i] = yml.getLong("planted_at." + i, System.currentTimeMillis());
        }
    }

    public void saveSync() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("total_purchased", totalPurchased);
        yml.set("wheat_count", wheatCount);
        for (int i = 0; i < totalPurchased; i++) {
            yml.set("planted_at." + i, plantedAtMillis[i]);
        }
        try {
            yml.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder wheat_farm.yml", ex);
        }
    }

    // ----- Achat -----

    /** Prix (en Ecus) du prochain achat. -1 si épuisé (les 10 emplacements sont remplis). 0 = gratuit. */
    public long priceForNextPurchase() {
        if (totalPurchased >= SLOT_COUNT) return -1;
        int n = totalPurchased + 1; // index du prochain achat (1-based)
        if (n == 1) return 0;
        long price = 1;
        for (int i = 0; i < n - 1; i++) price *= 10;
        return price;
    }

    public boolean isSoldOut() {
        return totalPurchased >= SLOT_COUNT;
    }

    public int getTotalPurchased() {
        return totalPurchased;
    }

    /** Tente d'acheter une graine pour ce joueur. Débite les Ecus si besoin, plante dans le
     *  prochain emplacement libre. Retourne true si l'achat a réussi. */
    public boolean purchaseSeed(Player player, fr.geven.clicker.data.EcusManager ecusManager) {
        if (isSoldOut()) return false;
        long price = priceForNextPurchase();
        if (price > 0 && !ecusManager.tryRemoveEcus(player.getUniqueId(), price)) {
            return false;
        }
        int slot = totalPurchased;
        totalPurchased++;
        plantedAtMillis[slot] = System.currentTimeMillis();
        dirty = true;
        applySlotBlock(slot);
        return true;
    }

    // ----- Pousse / récolte -----

    /** Réapplique tous les emplacements actifs (auto-réparation, comme les autres structures). */
    public void reapplyAll(World world) {
        for (int i = 0; i < totalPurchased; i++) {
            applySlotBlock(i);
        }
    }

    private void applySlotBlock(int slot) {
        Block block = slotLocations.get(slot).getBlock();
        if (block.getType() != Material.WHEAT) {
            block.setType(Material.WHEAT, false);
        }
        int targetAge = ageForSlot(slot);
        if (block.getBlockData() instanceof Ageable ageable && ageable.getAge() != targetAge) {
            ageable.setAge(targetAge);
            block.setBlockData(ageable, false);
        }
    }

    private int ageForSlot(int slot) {
        if (slot < 0 || slot >= totalPurchased || plantedAtMillis[slot] < 0) return 0;
        long elapsedMs = System.currentTimeMillis() - plantedAtMillis[slot];
        double fraction = Math.min(1.0, elapsedMs / (growSeconds * 1000.0));
        return Math.min(MAX_AGE, (int) Math.floor(fraction * MAX_AGE));
    }

    /** Progression 0.0-1.0 de la pousse de cet emplacement. */
    public double progressForSlot(int slot) {
        if (slot < 0 || slot >= totalPurchased || plantedAtMillis[slot] < 0) return 0.0;
        long elapsedMs = System.currentTimeMillis() - plantedAtMillis[slot];
        return Math.min(1.0, elapsedMs / (growSeconds * 1000.0));
    }

    public int secondsRemainingForSlot(int slot) {
        double progress = progressForSlot(slot);
        return (int) Math.ceil(growSeconds * (1.0 - progress));
    }

    public int getGrowSeconds() {
        return growSeconds;
    }

    /** Bonus multiplicatif au blé gagné par récolte (x2 à partir du Void Composter Tier 2). */
    public void setYieldMultiplier(int multiplier) {
        this.yieldMultiplier = Math.max(1, multiplier);
    }

    public int getYieldMultiplier() {
        return yieldMultiplier;
    }

    public int getYieldPerHarvest() {
        return yieldPerHarvest;
    }

    public long getWheatCount() {
        return wheatCount;
    }

    public int getSellPricePerUnit() {
        return sellPricePerUnit;
    }

    /** Vend jusqu'à "amount" blé (plafonné à ce que le joueur a réellement) contre des Ecus.
     *  Retourne le nombre réel de blé vendu (0 si rien à vendre). */
    public long sellWheat(java.util.UUID uuid, long amount, fr.geven.clicker.data.EcusManager ecusManager) {
        long toSell = Math.min(amount, wheatCount);
        if (toSell <= 0) return 0;
        wheatCount -= toSell;
        dirty = true;
        ecusManager.addEcus(uuid, toSell * sellPricePerUnit);
        return toSell;
    }

    /** Débite "amount" blé si le joueur en a assez. Retourne true si le débit a réussi. */
    public boolean tryRemoveWheat(long amount) {
        if (wheatCount < amount) return false;
        wheatCount -= amount;
        dirty = true;
        return true;
    }

    /** Ajoute (ou retire si négatif, plafonné à 0) "delta" blé au stock partagé. Utilisé par
     *  "/cl blé give/remove". Retourne le nouveau total. */
    public long addWheat(long delta) {
        wheatCount = Math.max(0, wheatCount + delta);
        dirty = true;
        return wheatCount;
    }

    /** Remet toute la farm à zéro : plus aucune graine plantée, plus de blé en stock. Utilisé par
     *  les checkpoints pour effacer la progression "houe" du joueur. */
    public void resetAll(World world) {
        totalPurchased = 0;
        wheatCount = 0;
        for (int i = 0; i < SLOT_COUNT; i++) {
            plantedAtMillis[i] = -1L;
            if (i < slotLocations.size()) {
                Block block = slotLocations.get(i).getBlock();
                if (block.getType() == Material.WHEAT) {
                    block.setType(Material.AIR, false);
                }
            }
        }
        dirty = true;
    }

    /** Index d'emplacement pour ce bloc, ou -1 si ce n'est pas un emplacement de la farm. */
    public int slotIndexFor(Block block) {
        for (int i = 0; i < slotLocations.size(); i++) {
            Location loc = slotLocations.get(i);
            if (loc.getBlockX() == block.getX() && loc.getBlockY() == block.getY() && loc.getBlockZ() == block.getZ()
                    && loc.getWorld().equals(block.getWorld())) {
                return i;
            }
        }
        return -1;
    }

    public boolean isActiveSlot(int slot) {
        return slot >= 0 && slot < totalPurchased;
    }

    public boolean isMature(int slot) {
        return isActiveSlot(slot) && ageForSlot(slot) >= MAX_AGE;
    }

    /** Récolte : remet l'emplacement à 0 (nouveau cycle) et crédite le blé au Farmer's Inventory. */
    public void harvest(int slot) {
        if (!isMature(slot)) return;
        plantedAtMillis[slot] = System.currentTimeMillis();
        wheatCount += (long) yieldPerHarvest * yieldMultiplier;
        dirty = true;
        applySlotBlock(slot);
    }

    public boolean isDirty() {
        return dirty;
    }
}
