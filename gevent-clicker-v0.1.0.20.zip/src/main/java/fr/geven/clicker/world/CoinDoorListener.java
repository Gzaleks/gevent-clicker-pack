package fr.geven.clicker.world;

import fr.geven.clicker.gui.ShovelCoinItem;
import fr.geven.clicker.listener.CoinSlotsListener;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gère l'ouverture/fermeture de la porte 3x3 (CoinDoorWorldManager) INDIVIDUELLEMENT par
 * joueur : les blocs réels de la porte restent posés en dur (solides pour tout le monde côté
 * serveur/monde), mais chaque joueur possédant le Shovel Coin reçoit un changement de bloc
 * envoyé uniquement à lui (Player#sendBlockChange) qui lui montre ces blocs en air — ça ne
 * touche jamais le vrai monde, donc un joueur juste à côté sans le Shovel Coin continue de voir
 * (et de percuter) des blocs bien solides.
 */
public class CoinDoorListener implements Listener {

    private final JavaPlugin plugin;
    private final CoinDoorWorldManager worldManager;
    private final ShovelCoinItem shovelCoinItem;

    /** true = porte actuellement affichée OUVERTE (air) pour ce joueur, côté client uniquement. */
    private final Map<UUID, Boolean> openForPlayer = new ConcurrentHashMap<>();

    public CoinDoorListener(JavaPlugin plugin, CoinDoorWorldManager worldManager, ShovelCoinItem shovelCoinItem) {
        this.plugin = plugin;
        this.worldManager = worldManager;
        this.shovelCoinItem = shovelCoinItem;
    }

    /** Démarre le rafraîchissement périodique (toutes les 10 ticks) pour les joueurs du monde.
     *  Contrairement à refresh(), ceci REENVOIE le paquet à chaque fois (pas seulement au
     *  changement) — filet de sécurité bon marché (9 blocs) contre tout désync client/serveur,
     *  quelle qu'en soit la cause (rechargement de chunk, redémarrage, bug quelconque). */
    public BukkitTask startTicking() {
        return new BukkitRunnable() {
            @Override
            public void run() {
                if (worldManager.getWorld() == null) return;
                for (Player player : worldManager.getWorld().getPlayers()) {
                    forceSync(player);
                }
            }
        }.runTaskTimer(plugin, 10L, 10L);
    }

    private void forceSync(Player player) {
        if (!player.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            return;
        }
        boolean shouldBeOpen = hasShovelCoin(player);
        sendDoorState(player, shouldBeOpen);
        openForPlayer.put(player.getUniqueId(), shouldBeOpen);
    }

    private boolean hasShovelCoin(Player player) {
        return shovelCoinItem.matches(player.getInventory().getItem(CoinSlotsListener.SHOVEL_SLOT));
    }

    /** Renvoie l'état correct de la porte à ce joueur, seulement si ça a changé depuis la dernière fois. */
    public void refresh(Player player) {
        if (!player.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            openForPlayer.remove(player.getUniqueId());
            return;
        }
        boolean shouldBeOpen = hasShovelCoin(player);
        Boolean current = openForPlayer.get(player.getUniqueId());
        if (current != null && current == shouldBeOpen) {
            return; // déjà à jour, rien à renvoyer
        }
        sendDoorState(player, shouldBeOpen);
        openForPlayer.put(player.getUniqueId(), shouldBeOpen);
    }

    private void sendDoorState(Player player, boolean open) {
        List<Location> locations = worldManager.doorBlockLocations();
        for (Location loc : locations) {
            player.sendBlockChange(loc, open ? Material.AIR.createBlockData() : CoinDoorWorldManager.DOOR_MATERIAL.createBlockData());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        refresh(event.getPlayer());
    }

    @EventHandler
    public void onChangeWorld(PlayerChangedWorldEvent event) {
        refresh(event.getPlayer());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!player.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            return;
        }

        // Barrière dure côté serveur : un joueur sans le Shovel Coin ne peut jamais entrer dans
        // le volume de la porte, quel que soit l'état visuel déjà reçu côté client (paquet en
        // retard, lag, etc.) — évite tout "clip"/rejet bizarre puisque les vrais blocs sont
        // désormais toujours de l'air (voir CoinDoorWorldManager).
        Location to = event.getTo();
        if (to != null && !hasShovelCoin(player) && isInsideDoorVolume(to)) {
            event.setCancelled(true);
            return;
        }

        // Ne rafraîchit l'affichage que si le joueur change vraiment de bloc, pour ne pas
        // spammer de paquets à chaque micro-mouvement.
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }
        refresh(player);
    }

    /** true si les pieds OU la tête du joueur à cette position tombent sur un bloc de la porte. */
    private boolean isInsideDoorVolume(Location to) {
        int feetY = to.getBlockY();
        for (Location doorLoc : worldManager.doorBlockLocations()) {
            if (doorLoc.getBlockX() == to.getBlockX() && doorLoc.getBlockZ() == to.getBlockZ()
                    && (doorLoc.getBlockY() == feetY || doorLoc.getBlockY() == feetY + 1)) {
                return true;
            }
        }
        return false;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        openForPlayer.remove(event.getPlayer().getUniqueId());
    }
}
