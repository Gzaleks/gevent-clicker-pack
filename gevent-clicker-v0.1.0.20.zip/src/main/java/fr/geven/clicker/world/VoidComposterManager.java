package fr.geven.clicker.world;

import fr.geven.clicker.data.EcusManager;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Levelled;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Gère le tier du Void Composter (1 ou 2, état partagé — un seul composteur sur la carte).
 * Le tier est physiquement représenté par le "level" (Levelled) du bloc COMPOSTER lui-même :
 * level 0 = tier 1 (modèle de base, tubes ouest/est), level 1 = tier 2 (+ tubes nord/sud, via
 * le modèle "composter_contents1" du resource pack, appliqué en multipart quand level=1).
 * Persisté dans voidcomposter.yml pour survivre aux redémarrages (et aux heals de
 * StructureIntegrityTask, qui ne réinitialisent PAS le bloc tant qu'il est déjà un composteur).
 */
public class VoidComposterManager {

    public static final int MAX_TIER = 3;
    public static final long TIER2_WHEAT_COST = 20L;
    public static final long TIER2_ECUS_COST = 10L;
    public static final long TIER3_WHEAT_COST = 45L;
    public static final long TIER3_ECUS_COST = 40L;
    public static final long TIER3_POTATO_COST = 100L;

    private final JavaPlugin plugin;
    private final File dataFile;
    private volatile int tier = 1;

    public VoidComposterManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "voidcomposter.yml");
    }

    public void load() {
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        tier = Math.max(1, Math.min(MAX_TIER, yml.getInt("tier", 1)));
    }

    public void saveSync() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("tier", tier);
        try {
            yml.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder voidcomposter.yml", ex);
        }
    }

    public int getTier() {
        return tier;
    }

    public boolean isMaxTier() {
        return tier >= MAX_TIER;
    }

    /** Coût (blé, ecus, patate) du prochain tier up. Patate = 0 si non concerné (tier 1 -> 2).
     *  null si déjà au tier max. */
    public long[] nextCost() {
        if (isMaxTier()) return null;
        if (tier == 1) {
            return new long[] { TIER2_WHEAT_COST, TIER2_ECUS_COST, 0L };
        }
        return new long[] { TIER3_WHEAT_COST, TIER3_ECUS_COST, TIER3_POTATO_COST };
    }

    /** Tente le tier up : débite blé + ecus (+ patate à partir du tier 2) si toutes les conditions
     *  sont réunies, sinon ne fait rien et retourne false. Répercute immédiatement le changement
     *  visuel sur le bloc. potatoFarmManager peut être null tant que le tier 1 -> 2 n'exige pas de
     *  patate. */
    public boolean tryTierUp(UUID uuid, WheatFarmManager wheatFarmManager, PotatoFarmManager potatoFarmManager,
                              EcusManager ecusManager, World world,
                              int composterX, int composterY, int composterZ) {
        if (isMaxTier()) return false;
        long[] cost = nextCost();
        long wheatCost = cost[0];
        long ecusCost = cost[1];
        long potatoCost = cost[2];
        if (wheatFarmManager.getWheatCount() < wheatCost || ecusManager.getEcus(uuid) < ecusCost) {
            return false;
        }
        if (potatoCost > 0 && (potatoFarmManager == null || potatoFarmManager.getPotatoCount() < potatoCost)) {
            return false;
        }
        // Toutes les conditions viennent d'être vérifiées ci-dessus (thread principal, pas de
        // concurrence possible entre les appels) : on débite tout sans risque d'état intermédiaire
        // incohérent.
        wheatFarmManager.tryRemoveWheat(wheatCost);
        ecusManager.tryRemoveEcus(uuid, ecusCost);
        if (potatoCost > 0) {
            potatoFarmManager.tryRemovePotato(potatoCost);
        }
        tier++;
        saveSync();
        applyBlockLevel(world, composterX, composterY, composterZ);
        return true;
    }

    /** Remet le tier à 1 (utilisé par les checkpoints). */
    public void resetToTierOne(World world, int composterX, int composterY, int composterZ) {
        tier = 1;
        saveSync();
        applyBlockLevel(world, composterX, composterY, composterZ);
    }

    /** Réapplique le level du bloc correspondant au tier actuel. À appeler après chaque
     *  (re)placement du composteur (applyAll), car un setType frais repart de level 0. Gère aussi
     *  le "bloc compagnon" invisible (Tier 3) qui étend l'emprise cliquable d'1 bloc côté nord
     *  (la face nord du modèle avance d'1 bloc à partir du Tier 3, voir composter_contents2.json). */
    public void applyBlockLevel(World world, int x, int y, int z) {
        if (world == null) return;
        Block block = world.getBlockAt(x, y, z);
        if (block.getBlockData() instanceof Levelled levelled) {
            int targetLevel = tier - 1;
            if (levelled.getLevel() != targetLevel) {
                levelled.setLevel(targetLevel);
                block.setBlockData(levelled, false);
            }
        }

        Block companion = world.getBlockAt(x, y, z - 1); // côté nord (-Z)
        if (tier >= 3) {
            if (companion.getType() != org.bukkit.Material.BARRIER) {
                companion.setType(org.bukkit.Material.BARRIER, false);
            }
        } else if (companion.getType() == org.bukkit.Material.BARRIER) {
            companion.setType(org.bukkit.Material.AIR, false);
        }
    }

    /** true si ce bloc est le "compagnon" nord (Tier 3) du composteur situé à (x;y;z). */
    public boolean isCompanionBlock(Block clicked, int composterX, int composterY, int composterZ) {
        return tier >= 3 && clicked.getX() == composterX && clicked.getY() == composterY
                && clicked.getZ() == composterZ - 1;
    }
}
