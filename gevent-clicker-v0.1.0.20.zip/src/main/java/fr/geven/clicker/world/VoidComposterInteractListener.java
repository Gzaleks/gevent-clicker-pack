package fr.geven.clicker.world;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.gui.VoidComposterGui;
import fr.geven.clicker.gui.VoidComposterHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;

/** Ouvre l'interface de tier up du Void Composter au clic (droit OU gauche) sur son bloc,
 *  et empêche le clic gauche de le casser (il n'est de toute façon pas censé être cassable,
 *  mais en Adventure le clic gauche déclenche PlayerInteractEvent, pas BlockBreakEvent). */
public class VoidComposterInteractListener implements Listener {

    private final int x;
    private final int y;
    private final int z;
    private final EcusManager ecusManager;
    private final WheatFarmManager wheatFarmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public VoidComposterInteractListener(JavaPlugin plugin, EcusManager ecusManager, WheatFarmManager wheatFarmManager,
                                          PotatoFarmManager potatoFarmManager,
                                          VoidComposterManager voidComposterManager,
                                          DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        var config = plugin.getConfig();
        this.x = config.getInt("composter.x", 10);
        this.y = config.getInt("composter.y", 1);
        this.z = config.getInt("composter.z", 10);
        this.ecusManager = ecusManager;
        this.wheatFarmManager = wheatFarmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        boolean isMainBlock = block.getType() == Material.COMPOSTER && block.getX() == x && block.getY() == y && block.getZ() == z;
        boolean isCompanionBlock = block.getType() == Material.BARRIER
                && voidComposterManager.isCompanionBlock(block, x, y, z);
        if (!isMainBlock && !isCompanionBlock) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return;
        }
        VoidComposterHolder holder = new VoidComposterHolder();
        player.openInventory(VoidComposterGui.create(holder, voidComposterManager, wheatFarmManager, potatoFarmManager,
                ecusManager, player.getUniqueId()));
    }
}
