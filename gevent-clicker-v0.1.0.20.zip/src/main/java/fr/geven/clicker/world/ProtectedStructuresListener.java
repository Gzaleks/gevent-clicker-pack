package fr.geven.clicker.world;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;

/**
 * Rend le composter, le tonneau et le champ 5x2 (bordure de bûches incluse) totalement
 * incassables — y compris en créatif, où Bukkit envoie quand même un BlockBreakEvent (juste
 * instantané). Un admin ("geventclicker.admin") accroupi peut casser volontairement, pour
 * corriger un placement sans devoir passer par une commande.
 */
public class ProtectedStructuresListener implements Listener {

    private static final int FARM_WIDTH = 5;
    private static final int FARM_DEPTH = 2;
    private static final String PERMISSION = "geventclicker.admin";

    private final Set<Long> protectedCells = new HashSet<>();

    public ProtectedStructuresListener(JavaPlugin plugin) {
        var config = plugin.getConfig();

        int composterX = config.getInt("composter.x", 10);
        int composterY = config.getInt("composter.y", 1);
        int composterZ = config.getInt("composter.z", 10);
        addCell(composterX, composterY, composterZ);
        // Bloc "compagnon" nord (Tier 3, voir VoidComposterManager) : réservé même hors tier 3.
        addCell(composterX, composterY, composterZ - 1);
        addCell(config.getInt("barrel.x", 12), config.getInt("barrel.y", 1), config.getInt("barrel.z", 10));

        int x0 = config.getInt("farm_patch.x", 30);
        int y = config.getInt("farm_patch.y", 1);
        int z0 = config.getInt("farm_patch.z", 30);
        // Emprise maximale (patch blé + patch patate dupliqué, Tier 2+ du Void Composter).
        int maxZ = WorldStructuresManager.secondPatchZ(z0) + FARM_DEPTH;
        for (int x = x0 - 1; x <= x0 + FARM_WIDTH; x++) {
            for (int z = z0 - 1; z <= maxZ; z++) {
                addCell(x, y, z);
            }
        }

        addCell(config.getInt("lectern.x", 0), config.getInt("lectern.y", 1), config.getInt("lectern.z", 16));
    }

    private void addCell(int x, int y, int z) {
        protectedCells.add(encode(x, y, z));
    }

    private long encode(int x, int y, int z) {
        return (((long) x & 0x3FFFFFFL) << 38) | (((long) y & 0xFFFL) << 26) | ((long) z & 0x3FFFFFFL);
    }

    private boolean isProtected(Block block) {
        return block.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)
                && protectedCells.contains(encode(block.getX(), block.getY(), block.getZ()));
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        if (!isProtected(event.getBlock())) {
            return;
        }
        Player player = event.getPlayer();
        if (player.hasPermission(PERMISSION) && player.isSneaking()) {
            return; // échappatoire volontaire pour les admins qui veulent corriger un placement
        }
        event.setCancelled(true);
    }
}
