package fr.geven.clicker.world;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Force le gamemode ADVENTURE pour tout joueur qui se connecte ou entre dans
 * gevent_clicker_world, sauf les administrateurs ("geventclicker.admin").
 */
public class AdventureModeListener implements Listener {

    private static final String PERMISSION = "geventclicker.admin";

    private void enforce(Player player) {
        if (!player.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            return;
        }
        if (player.hasPermission(PERMISSION)) {
            return;
        }
        if (player.getGameMode() != GameMode.ADVENTURE) {
            player.setGameMode(GameMode.ADVENTURE);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        enforce(event.getPlayer());
    }

    @EventHandler
    public void onChangeWorld(PlayerChangedWorldEvent event) {
        enforce(event.getPlayer());
    }
}
