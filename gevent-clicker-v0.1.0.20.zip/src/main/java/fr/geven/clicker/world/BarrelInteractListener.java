package fr.geven.clicker.world;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.gui.FarmerInventoryGui;
import fr.geven.clicker.gui.FarmerInventoryHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;

/** Remplace l'ouverture vanilla du tonneau "Farmer's Inventory" par l'interface custom. */
public class BarrelInteractListener implements Listener {

    private final int x;
    private final int y;
    private final int z;
    private final WheatFarmManager farmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public BarrelInteractListener(JavaPlugin plugin, WheatFarmManager farmManager, PotatoFarmManager potatoFarmManager,
                                   VoidComposterManager voidComposterManager,
                                   DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        var config = plugin.getConfig();
        this.x = config.getInt("barrel.x", 12);
        this.y = config.getInt("barrel.y", 1);
        this.z = config.getInt("barrel.z", 10);
        this.farmManager = farmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.BARREL) {
            return;
        }
        if (block.getX() != x || block.getY() != y || block.getZ() != z) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return;
        }
        FarmerInventoryHolder holder = new FarmerInventoryHolder();
        player.openInventory(FarmerInventoryGui.create(holder, farmManager, potatoFarmManager,
                voidComposterManager.getTier() >= 2));
    }
}
