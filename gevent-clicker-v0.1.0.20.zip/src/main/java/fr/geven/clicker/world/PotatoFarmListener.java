package fr.geven.clicker.world;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Gère la récolte des emplacements de patates de PotatoFarmManager : même mécanique que
 * WheatFarmListener (clic gauche sur un emplacement mûr récolte et relance le cycle), avec en plus
 * un message temporaire ("+ X patates") au-dessus de la barre de vie, qui ne persiste qu'1 seconde.
 */
public class PotatoFarmListener implements Listener {

    private static final TextColor LIGHT_GREEN = TextColor.color(0x7CFC7C);

    private final JavaPlugin plugin;
    private final PotatoFarmManager farmManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public PotatoFarmListener(JavaPlugin plugin, PotatoFarmManager farmManager,
                               DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.plugin = plugin;
        this.farmManager = farmManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onLeftClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.POTATOES
                || !block.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            return;
        }
        int slot = farmManager.slotIndexFor(block);
        if (slot < 0 || !farmManager.isActiveSlot(slot)) {
            return; // pas un de nos emplacements de patate gérés
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return;
        }
        if (farmManager.isMature(slot)) {
            int gained = farmManager.harvest(slot);
            if (gained > 0) {
                farmManager.suppressHologramFor(player.getUniqueId(), 1000L);
                player.sendActionBar(Component.text("+ " + gained + " patates", LIGHT_GREEN));
                // Ne persiste qu'1 seconde : on efface ensuite la barre d'action explicitement.
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin,
                        () -> player.sendActionBar(Component.empty()), 20L);
            }
        }
        // Sinon (pas encore mûr) : rien ne se passe, comme demandé.
    }
}
