package fr.geven.clicker.world;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Pupitre custom "Informations" (config.yml : lectern.x/y/z) : au clic, ouvre directement un
 * livre (sans passer par l'inventaire du pupitre) affichant le message de fin de zone.
 */
public class LecternInfoListener implements Listener {

    private static final List<String> PAGES = List.of(
            "GG pour ta Grassifictaion ! Afin de récupérer les autres pièces (en haut à gauche de ton inventaire), termine les trois autres zones incrémentales.",
            "Une fois toutes les pièces récupérée, un truc vraiment super cool se passera ! :D"
    );

    private final int x;
    private final int y;
    private final int z;

    public LecternInfoListener(JavaPlugin plugin) {
        var config = plugin.getConfig();
        this.x = config.getInt("lectern.x", 0);
        this.y = config.getInt("lectern.y", 1);
        this.z = config.getInt("lectern.z", 16);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.LECTERN) {
            return;
        }
        if (block.getX() != x || block.getY() != y || block.getZ() != z) {
            return;
        }
        event.setCancelled(true);

        Player player = event.getPlayer();
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.title(Component.text("Informations"));
        meta.author(Component.text("Gevent_Clicker"));
        for (String page : PAGES) {
            meta.addPages(Component.text(page));
        }
        book.setItemMeta(meta);
        player.openBook(book);
    }
}
