package fr.geven.clicker.world;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.gui.SellGui;
import fr.geven.clicker.gui.SellHolder;
import fr.geven.clicker.gui.ShopGui;
import fr.geven.clicker.gui.ShopHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

/** Ouvre le shop custom correspondant (au lieu du commerce vanilla) au clic sur un PNJ marchand,
 *  et empêche totalement de les frapper (invulnérable ne bloque que les dégâts, pas le coup). */
public class ShopNpcListener implements Listener {

    private final WorldStructuresManager structuresManager;
    private final WheatFarmManager farmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public ShopNpcListener(WorldStructuresManager structuresManager, WheatFarmManager farmManager,
                            PotatoFarmManager potatoFarmManager, VoidComposterManager voidComposterManager,
                            DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.structuresManager = structuresManager;
        this.farmManager = farmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        String id = structuresManager.getNpcId(event.getRightClicked());
        if (id == null) return;
        event.setCancelled(true);
        Player player = event.getPlayer();

        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return;
        }

        boolean potatoUnlocked = voidComposterManager.getTier() >= 2;
        if (id.equals("seller")) {
            ShopHolder holder = new ShopHolder();
            player.openInventory(ShopGui.create(holder, farmManager, potatoFarmManager, potatoUnlocked));
        } else if (id.equals("buyer")) {
            SellHolder holder = new SellHolder();
            player.openInventory(SellGui.create(holder, farmManager, potatoFarmManager, potatoUnlocked));
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (structuresManager.getNpcId(event.getEntity()) != null) {
            event.setCancelled(true);
        }
    }
}
