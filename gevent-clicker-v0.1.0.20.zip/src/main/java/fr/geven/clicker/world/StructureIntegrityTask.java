package fr.geven.clicker.world;

import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/**
 * Réapplique périodiquement composter/tonneau/champ/pupitre (WorldStructuresManager#applyAll) :
 * c'est ce qui garantit qu'ils "réapparaissent quoi qu'il arrive" même si un joueur les supprime
 * par un moyen qui ne déclenche pas de BlockBreakEvent (ex: //cut ou //set WorldEdit), puisque
 * ProtectedStructuresListener seul ne peut pas intercepter ce genre d'opération.
 */
public class StructureIntegrityTask {

    /** Toutes les 1200 ticks = 60 secondes : assez réactif sans surcharger le serveur. */
    private static final long PERIOD_TICKS = 1200L;

    private final JavaPlugin plugin;
    private final WorldStructuresManager structuresManager;
    private final CoinDoorWorldManager worldManager;
    private final VoidComposterManager voidComposterManager;

    public StructureIntegrityTask(JavaPlugin plugin, WorldStructuresManager structuresManager,
                                   CoinDoorWorldManager worldManager, VoidComposterManager voidComposterManager) {
        this.plugin = plugin;
        this.structuresManager = structuresManager;
        this.worldManager = worldManager;
        this.voidComposterManager = voidComposterManager;
    }

    public BukkitTask start() {
        return new BukkitRunnable() {
            @Override
            public void run() {
                World world = worldManager.getWorld();
                if (world == null) return;
                structuresManager.applyAll(world, voidComposterManager.getTier() >= 2);
                // Un heal qui recrée le bloc (marker changé) repartirait sinon en tier 1 (level 0).
                var config = plugin.getConfig();
                voidComposterManager.applyBlockLevel(world,
                        config.getInt("composter.x", 10), config.getInt("composter.y", 1),
                        config.getInt("composter.z", 10));
            }
        }.runTaskTimer(plugin, PERIOD_TICKS, PERIOD_TICKS);
    }
}
