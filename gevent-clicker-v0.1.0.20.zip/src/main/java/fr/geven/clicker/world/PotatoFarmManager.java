package fr.geven.clicker.world;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Gère les 10 emplacements de patates : débloqué uniquement à partir du Void Composter Tier 2
 * (voir VoidComposterManager), planté dans la 2e moitié du champ dupliqué (juste à droite de la
 * moitié blé, séparée par la même bordure de bûches partagée). Même mécanique que
 * WheatFarmManager (achat progressif, pousse chronométrée, récolte), avec ses propres constantes :
 * pousse en 20 secondes, récolte 1 à 3 patates aléatoirement, vendues 1 Ecu l'unité.
 */
public class PotatoFarmManager {

    private static final int SLOT_COUNT = 10;
    private static final int FARM_WIDTH = 5;
    private static final int MAX_AGE = 7;
    private static final int GROW_SECONDS = 16;
    private static final int SELL_PRICE_PER_UNIT = 1;

    private final JavaPlugin plugin;
    private final File dataFile;
    private final Random random = new Random();

    private int farmX0;
    private int farmY;
    private int farmZ0; // z du début de la 2e moitié (dupliquée), calculé depuis farm_patch + FARM_DEPTH + 1

    private final List<Location> slotLocations = new ArrayList<>();
    private final long[] plantedAtMillis = new long[SLOT_COUNT];
    private int totalPurchased = 0;
    private long potatoCount = 0;
    private volatile boolean dirty = false;
    /** Tant que System.currentTimeMillis() < cette valeur pour un joueur, PotatoFarmTask ne doit
     *  pas écraser son message "+ X patates" avec l'hologramme de progression habituel. */
    private final Map<java.util.UUID, Long> suppressHologramUntil = new ConcurrentHashMap<>();

    public PotatoFarmManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "potato_farm.yml");
        for (int i = 0; i < SLOT_COUNT; i++) plantedAtMillis[i] = -1L;
    }

    /** offsetZ0 = z de départ de la 2e moitié du champ dupliqué (juste après la bordure partagée). */
    public void setup(World world, int farmX0, int farmY, int offsetZ0) {
        this.farmX0 = farmX0;
        this.farmY = farmY;
        this.farmZ0 = offsetZ0;

        slotLocations.clear();
        for (int i = 0; i < FARM_WIDTH; i++) {
            slotLocations.add(new Location(world, farmX0 + i, farmY + 1, farmZ0));
        }
        for (int i = 0; i < FARM_WIDTH; i++) {
            slotLocations.add(new Location(world, farmX0 + i, farmY + 1, farmZ0 + 1));
        }

        load();
        reapplyAll();
    }

    private void load() {
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        totalPurchased = Math.min(SLOT_COUNT, yml.getInt("total_purchased", 0));
        potatoCount = yml.getLong("potato_count", 0L);
        for (int i = 0; i < totalPurchased; i++) {
            plantedAtMillis[i] = yml.getLong("planted_at." + i, System.currentTimeMillis());
        }
    }

    public void saveSync() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("total_purchased", totalPurchased);
        yml.set("potato_count", potatoCount);
        for (int i = 0; i < totalPurchased; i++) {
            yml.set("planted_at." + i, plantedAtMillis[i]);
        }
        try {
            yml.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder potato_farm.yml", ex);
        }
    }

    // ----- Achat -----

    /** Prix propre à la patate : 8 Ecus la première, x4 à chaque achat suivant. */
    private static final long PRICE_BASE = 8L;
    private static final long PRICE_GROWTH = 4L;

    public long priceForNextPurchase() {
        if (totalPurchased >= SLOT_COUNT) return -1;
        long price = PRICE_BASE;
        for (int i = 0; i < totalPurchased; i++) price *= PRICE_GROWTH;
        return price;
    }

    public boolean isSoldOut() {
        return totalPurchased >= SLOT_COUNT;
    }

    public int getTotalPurchased() {
        return totalPurchased;
    }

    public boolean purchaseSeed(Player player, fr.geven.clicker.data.EcusManager ecusManager) {
        if (isSoldOut()) return false;
        long price = priceForNextPurchase();
        if (price > 0 && !ecusManager.tryRemoveEcus(player.getUniqueId(), price)) {
            return false;
        }
        int slot = totalPurchased;
        totalPurchased++;
        plantedAtMillis[slot] = System.currentTimeMillis();
        dirty = true;
        applySlotBlock(slot);
        return true;
    }

    // ----- Pousse / récolte -----

    public void reapplyAll() {
        for (int i = 0; i < totalPurchased; i++) {
            applySlotBlock(i);
        }
    }

    private void applySlotBlock(int slot) {
        Block block = slotLocations.get(slot).getBlock();
        if (block.getType() != Material.POTATOES) {
            block.setType(Material.POTATOES, false);
        }
        int targetAge = ageForSlot(slot);
        if (block.getBlockData() instanceof Ageable ageable && ageable.getAge() != targetAge) {
            ageable.setAge(targetAge);
            block.setBlockData(ageable, false);
        }
    }

    private int ageForSlot(int slot) {
        if (slot < 0 || slot >= totalPurchased || plantedAtMillis[slot] < 0) return 0;
        long elapsedMs = System.currentTimeMillis() - plantedAtMillis[slot];
        double fraction = Math.min(1.0, elapsedMs / (GROW_SECONDS * 1000.0));
        return Math.min(MAX_AGE, (int) Math.floor(fraction * MAX_AGE));
    }

    public double progressForSlot(int slot) {
        if (slot < 0 || slot >= totalPurchased || plantedAtMillis[slot] < 0) return 0.0;
        long elapsedMs = System.currentTimeMillis() - plantedAtMillis[slot];
        return Math.min(1.0, elapsedMs / (GROW_SECONDS * 1000.0));
    }

    public int secondsRemainingForSlot(int slot) {
        double progress = progressForSlot(slot);
        return (int) Math.ceil(GROW_SECONDS * (1.0 - progress));
    }

    public int getGrowSeconds() {
        return GROW_SECONDS;
    }

    public long getPotatoCount() {
        return potatoCount;
    }

    public int getSellPricePerUnit() {
        return SELL_PRICE_PER_UNIT;
    }

    public long sellPotato(java.util.UUID uuid, long amount, fr.geven.clicker.data.EcusManager ecusManager) {
        long toSell = Math.min(amount, potatoCount);
        if (toSell <= 0) return 0;
        potatoCount -= toSell;
        dirty = true;
        ecusManager.addEcus(uuid, toSell * SELL_PRICE_PER_UNIT);
        return toSell;
    }

    /** Ajoute (ou retire si négatif, plafonné à 0) "delta" patates au stock partagé. Utilisé par
     *  "/cl patate give/remove". Retourne le nouveau total. */
    public long addPotato(long delta) {
        potatoCount = Math.max(0, potatoCount + delta);
        dirty = true;
        return potatoCount;
    }

    public boolean tryRemovePotato(long amount) {
        if (potatoCount < amount) return false;
        potatoCount -= amount;
        dirty = true;
        return true;
    }

    /** Remet toute la patch de patates à zéro (utilisé par les checkpoints, comme WheatFarmManager). */
    public void resetAll(World world) {
        totalPurchased = 0;
        potatoCount = 0;
        for (int i = 0; i < SLOT_COUNT; i++) {
            plantedAtMillis[i] = -1L;
            if (i < slotLocations.size()) {
                Block block = slotLocations.get(i).getBlock();
                if (block.getType() == Material.POTATOES) {
                    block.setType(Material.AIR, false);
                }
            }
        }
        dirty = true;
    }

    public int slotIndexFor(Block block) {
        for (int i = 0; i < slotLocations.size(); i++) {
            Location loc = slotLocations.get(i);
            if (loc.getBlockX() == block.getX() && loc.getBlockY() == block.getY() && loc.getBlockZ() == block.getZ()
                    && loc.getWorld().equals(block.getWorld())) {
                return i;
            }
        }
        return -1;
    }

    public boolean isActiveSlot(int slot) {
        return slot >= 0 && slot < totalPurchased;
    }

    public boolean isMature(int slot) {
        return isActiveSlot(slot) && ageForSlot(slot) >= MAX_AGE;
    }

    /** Récolte : remet l'emplacement à 0 (nouveau cycle) et crédite 1 à 3 patates aléatoirement.
     *  Retourne le nombre de patates effectivement récoltées (0 si l'emplacement n'était pas mûr). */
    public int harvest(int slot) {
        if (!isMature(slot)) return 0;
        plantedAtMillis[slot] = System.currentTimeMillis();
        int gained = 1 + random.nextInt(3); // 1 à 3 inclus
        potatoCount += gained;
        dirty = true;
        applySlotBlock(slot);
        return gained;
    }

    public boolean isDirty() {
        return dirty;
    }

    /** Empêche PotatoFarmTask d'écraser le message "+ X patates" de ce joueur pendant durationMs. */
    public void suppressHologramFor(java.util.UUID uuid, long durationMs) {
        suppressHologramUntil.put(uuid, System.currentTimeMillis() + durationMs);
    }

    public boolean isHologramSuppressed(java.util.UUID uuid) {
        Long until = suppressHologramUntil.get(uuid);
        return until != null && System.currentTimeMillis() < until;
    }
}
