package fr.geven.clicker.world;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/** Envoie chaque joueur dans gevent_clicker_world dès sa toute première connexion au serveur —
 *  c'est désormais le monde de base du plugin. */
public class SpawnWorldListener implements Listener {

    private final CoinDoorWorldManager worldManager;

    public SpawnWorldListener(CoinDoorWorldManager worldManager) {
        this.worldManager = worldManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPlayedBefore()) {
            return;
        }
        if (worldManager.getWorld() == null) {
            return;
        }
        player.teleport(worldManager.getWorld().getSpawnLocation());
    }
}
