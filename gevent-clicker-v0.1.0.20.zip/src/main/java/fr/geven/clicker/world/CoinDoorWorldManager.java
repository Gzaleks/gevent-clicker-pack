package fr.geven.clicker.world;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Crée et prépare le monde de base du plugin (WORLD_NAME) : un monde entièrement vide (générateur void),
 * avec une plateforme de bedrock 101x101 centrée en (0;0) et une porte 3x3 verrouillée (voir
 * CoinDoorListener pour la logique d'ouverture par joueur). Les murs restent à la charge du
 * joueur — seule la porte est posée ici, à l'emplacement défini dans config.yml (door.x/y/z/axis)
 * pour pouvoir la faire correspondre à l'endroit exact où le mur est construit.
 */
public class CoinDoorWorldManager {

    public static final String WORLD_NAME = "gevent_clicker_world";

    /** Rayon de la plateforme de bedrock autour de (0;0) : 50 -> 101x101 blocs (> 100 demandé). */
    private static final int PLATFORM_RADIUS = 50;

    public static final Material DOOR_MATERIAL = Material.IRON_BLOCK;

    private final JavaPlugin plugin;
    private final NamespacedKey platformGeneratedKey;
    private final NamespacedKey doorLocationKey;
    private World world;

    private int doorCenterX;
    private int doorCenterY;
    private int doorCenterZ;
    private String doorAxis;

    public CoinDoorWorldManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.platformGeneratedKey = new NamespacedKey(plugin, "hoe_world_platform_generated");
        this.doorLocationKey = new NamespacedKey(plugin, "hoe_world_door_location");
    }

    /** Crée le monde s'il n'existe pas, pose la plateforme une seule fois, puis (re)positionne
     *  la porte à l'endroit actuellement défini dans config.yml. */
    public void setup() {
        loadDoorConfig();

        world = Bukkit.getWorld(WORLD_NAME);
        if (world == null) {
            WorldCreator creator = new WorldCreator(WORLD_NAME);
            creator.generator(new VoidChunkGenerator());
            creator.environment(World.Environment.NORMAL);
            world = Bukkit.createWorld(creator);
        }
        if (world == null) {
            plugin.getLogger().severe("Impossible de créer/charger le monde " + WORLD_NAME);
            return;
        }

        if (!world.getPersistentDataContainer().has(platformGeneratedKey, PersistentDataType.BYTE)) {
            generatePlatform();
            world.getPersistentDataContainer().set(platformGeneratedKey, PersistentDataType.BYTE, (byte) 1);
        }

        placeDoorAtConfiguredLocation();

        world.setSpawnLocation(0, 1, 0);
    }

    private void loadDoorConfig() {
        var config = plugin.getConfig();
        doorCenterX = config.getInt("door.x", 0);
        doorCenterY = config.getInt("door.y", 2);
        doorCenterZ = config.getInt("door.z", 0);
        doorAxis = config.getString("door.axis", "x");
        if (!"x".equalsIgnoreCase(doorAxis) && !"z".equalsIgnoreCase(doorAxis)) {
            doorAxis = "x";
        }
        // Log explicite pour vérifier facilement, depuis la console, que config.yml a bien été
        // relu avec les bonnes valeurs après un changement + redémarrage.
        plugin.getLogger().info("Gevent_Clicker : config porte lue -> x=" + doorCenterX + " y=" + doorCenterY
                + " z=" + doorCenterZ + " axis=" + doorAxis);
    }

    private void generatePlatform() {
        for (int x = -PLATFORM_RADIUS; x <= PLATFORM_RADIUS; x++) {
            for (int z = -PLATFORM_RADIUS; z <= PLATFORM_RADIUS; z++) {
                world.getBlockAt(x, 0, z).setType(Material.BEDROCK, false);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : plateforme du monde " + WORLD_NAME + " générée.");
    }

    /** Pose la porte à l'emplacement configuré. Si elle avait été posée ailleurs lors d'un
     *  précédent démarrage (config.yml modifié entre-temps), l'ancien emplacement est effacé
     *  (remis en air) avant de poser les nouveaux blocs. */
    private void placeDoorAtConfiguredLocation() {
        String newMarker = doorCenterX + "," + doorCenterY + "," + doorCenterZ + "," + doorAxis;
        String previousMarker = world.getPersistentDataContainer().get(doorLocationKey, PersistentDataType.STRING);

        // Les blocs RÉELS de la porte restent TOUJOURS de l'air : le "fermé" est entièrement
        // visuel, envoyé en paquet par joueur (CoinDoorListener). Si les vrais blocs étaient
        // solides, même le joueur autorisé se ferait rejeter par le serveur en essayant de
        // traverser (c'était le bug : ça "glitchait" dedans). On force l'air ici à chaque
        // démarrage (idempotent, gère aussi la migration depuis une ancienne version qui posait
        // encore des blocs solides en dur).
        if (previousMarker != null && !newMarker.equals(previousMarker)) {
            for (Location loc : doorBlockLocationsFor(previousMarker)) {
                loc.getBlock().setType(Material.AIR, false);
            }
        }
        for (Location loc : doorBlockLocations()) {
            loc.getBlock().setType(Material.AIR, false);
        }
        world.getPersistentDataContainer().set(doorLocationKey, PersistentDataType.STRING, newMarker);
        plugin.getLogger().info("Gevent_Clicker : porte positionnée en " + newMarker + ".");
    }

    private List<Location> doorBlockLocationsFor(String marker) {
        String[] parts = marker.split(",");
        int cx = Integer.parseInt(parts[0]);
        int cy = Integer.parseInt(parts[1]);
        int cz = Integer.parseInt(parts[2]);
        String axis = parts[3];
        return computeDoorBlocks(cx, cy, cz, axis);
    }

    /** Les 9 emplacements (blocs) actuels de la porte 3x3. */
    public List<Location> doorBlockLocations() {
        return computeDoorBlocks(doorCenterX, doorCenterY, doorCenterZ, doorAxis);
    }

    private List<Location> computeDoorBlocks(int cx, int cy, int cz, String axis) {
        List<Location> locations = new ArrayList<>();
        if (world == null) return locations;
        boolean spanZ = "z".equalsIgnoreCase(axis);
        for (int offset = -1; offset <= 1; offset++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = spanZ ? cx : cx + offset;
                int z = spanZ ? cz + offset : cz;
                locations.add(new Location(world, x, cy + dy, z));
            }
        }
        return locations;
    }

    public World getWorld() {
        return world;
    }
}
