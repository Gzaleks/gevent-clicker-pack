package fr.geven.clicker.world;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

/**
 * Gère la récolte des graines de blé de WheatFarmManager : clic gauche sur un emplacement mûr
 * (âge 7) récolte le blé (crédité au Farmer's Inventory) et relance le cycle ; sur un emplacement
 * pas encore mûr, rien ne se passe (bloqué, comme demandé). Utilise PlayerInteractEvent (et non
 * BlockBreakEvent) car les joueurs sont en gamemode ADVENTURE dans ce monde (AdventureModeListener),
 * où le clic gauche ne casse normalement AUCUN bloc — l'événement d'interaction, lui, se déclenche
 * quand même.
 */
public class WheatFarmListener implements Listener {

    private final WheatFarmManager farmManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public WheatFarmListener(WheatFarmManager farmManager, DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.farmManager = farmManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onLeftClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.WHEAT
                || !block.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME)) {
            return;
        }
        int slot = farmManager.slotIndexFor(block);
        if (slot < 0 || !farmManager.isActiveSlot(slot)) {
            return; // pas un de nos emplacements de graine gérés
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            player.sendActionBar(Component.text(
                    "Tu dois d'abord atteindre la Grassification pour accéder à ceci.", NamedTextColor.RED));
            return;
        }
        if (farmManager.isMature(slot)) {
            farmManager.harvest(slot);
        }
        // Sinon (pas encore mûr) : rien ne se passe, comme demandé.
    }
}
