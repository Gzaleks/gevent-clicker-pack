package fr.geven.clicker.world;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Levelled;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/**
 * Empêche le champ 5x2 (WorldStructuresManager) de sécher (BlockFadeEvent, manque d'eau à
 * proximité) ou de repasser en terre par piétinement (EntityChangeBlockEvent, un joueur ou mob
 * qui saute dessus). Lit les coordonnées du champ dans config.yml (farm_patch), donc pas besoin
 * de suivre chaque bloc individuellement : une simple zone rectangulaire suffit.
 */
public class FarmPatchListener implements Listener {

    private static final int FARM_WIDTH = 5;
    private static final int FARM_DEPTH = 2;

    /** Marge de sécurité autour de la parcelle 5x2 gérée par le plugin : couvre toute terre
     *  labourée que le joueur aurait construite à la main juste à côté (bordure, extension...),
     *  qui resterait sinon sèche puisqu'elle est en dehors de la zone strictement calculée. */
    private static final int MARGIN = 6;

    private final int coreMinX;
    private final int coreMaxX;
    private final int coreMinZ;
    private final int coreMaxZ;
    private final int minX;
    private final int maxX;
    private final int minZ;
    private final int maxZ;
    private final int y;
    private final CoinDoorWorldManager worldManager;
    private final JavaPlugin plugin;

    public FarmPatchListener(JavaPlugin plugin, CoinDoorWorldManager worldManager) {
        this.plugin = plugin;
        this.worldManager = worldManager;
        var config = plugin.getConfig();
        int x0 = config.getInt("farm_patch.x", 30);
        int z0 = config.getInt("farm_patch.z", 30);
        this.y = config.getInt("farm_patch.y", 1);
        this.coreMinX = x0;
        this.coreMaxX = x0 + FARM_WIDTH - 1;
        this.coreMinZ = z0;
        this.coreMaxZ = z0 + FARM_DEPTH - 1;
        this.minX = x0 - MARGIN;
        this.maxX = x0 + FARM_WIDTH - 1 + MARGIN;
        this.minZ = z0 - MARGIN;
        this.maxZ = z0 + FARM_DEPTH - 1 + MARGIN;
    }

    /** Force l'humidité au max sur toute la parcelle toutes les secondes : la baisse d'humidité
     *  (avant séchage complet) ne déclenche AUCUN événement Bukkit, donc seule une vérification
     *  fréquente garantit que la terre labourée reste visuellement humide en permanence.
     *  La conversion forcée en FARMLAND (si le bloc a fini par redevenir de la terre simple) ne
     *  s'applique QUE sur la zone 5x2 gérée par le plugin : dans la marge de sécurité autour, on
     *  ne touche qu'aux blocs déjà en FARMLAND, pour ne jamais transformer une bordure/chemin posé
     *  à la main par le joueur. */
    public BukkitTask start() {
        return new BukkitRunnable() {
            @Override
            public void run() {
                World world = worldManager.getWorld();
                if (world == null) return;
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        Block block = world.getBlockAt(x, y, z);
                        boolean core = x >= coreMinX && x <= coreMaxX && z >= coreMinZ && z <= coreMaxZ;
                        if (block.getType() != Material.FARMLAND) {
                            if (core) {
                                block.setType(Material.FARMLAND, false);
                            } else {
                                continue;
                            }
                        }
                        if (block.getBlockData() instanceof Levelled levelled
                                && levelled.getLevel() != levelled.getMaximumLevel()) {
                            levelled.setLevel(levelled.getMaximumLevel());
                            block.setBlockData(levelled, false);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    /** Couvre aussi la marge de sécurité, pas seulement la parcelle 5x2 stricte : voir start(). */
    private boolean inPatch(Block block) {
        return block.getY() == y && block.getX() >= minX && block.getX() <= maxX
                && block.getZ() >= minZ && block.getZ() <= maxZ
                && block.getWorld().getName().equals(CoinDoorWorldManager.WORLD_NAME);
    }

    /** Séchage naturel (manque d'eau à proximité) : on annule et on remet l'humidité au max. */
    @EventHandler
    public void onFade(BlockFadeEvent event) {
        Block block = event.getBlock();
        if (block.getType() != Material.FARMLAND || !inPatch(block)) {
            return;
        }
        event.setCancelled(true);
        if (block.getBlockData() instanceof Levelled levelled) {
            levelled.setLevel(levelled.getMaximumLevel());
            block.setBlockData(levelled, false);
        }
    }

    /** Piétinement (un joueur/mob saute dessus) qui transformerait la terre labourée en terre normale. */
    @EventHandler
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        Block block = event.getBlock();
        if (event.getTo() != Material.DIRT || block.getType() != Material.FARMLAND || !inPatch(block)) {
            return;
        }
        event.setCancelled(true);
    }
}
