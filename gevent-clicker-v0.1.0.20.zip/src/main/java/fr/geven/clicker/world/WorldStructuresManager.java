package fr.geven.clicker.world;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Levelled;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.ArrayList;

/**
 * Gère le composter "NàC", le tonneau "Farmer's Inventory", le champ 5x2 labouré/bordé de
 * bûches, et le pupitre "Informations" de gevent_clicker_world (anciennement gevent_hoe_world).
 * Positions lues dans config.yml (composter/barrel/farm_patch/lectern).
 *
 * Contrairement à la version précédente, ces structures se comportent maintenant comme la porte
 * (CoinDoorWorldManager) : si tu changes une position dans config.yml, un redémarrage/reload
 * efface l'ancien emplacement et repose la structure au nouvel endroit. En plus de ça,
 * applyAll(world) est rappelée périodiquement par StructureIntegrityTask pour "réparer" toute
 * structure cassée/supprimée (y compris par un //cut WorldEdit, qui ne déclenche aucun
 * BlockBreakEvent et n'est donc pas concerné par ProtectedStructuresListener) — c'est ce qui
 * garantit que le composter etc. "réapparaissent quoi qu'il arrive".
 */
public class WorldStructuresManager {

    private static final int FARM_WIDTH = 5;  // le long de X
    private static final int FARM_DEPTH = 2;  // le long de Z

    private final JavaPlugin plugin;
    private final NamespacedKey composterMarkerKey;
    private final NamespacedKey barrelMarkerKey;
    private final NamespacedKey farmPatchMarkerKey;
    private final NamespacedKey lecternMarkerKey;
    private final NamespacedKey tagEntityKey;
    private final NamespacedKey npcIdKey;
    /** Ancien tag (v0.1.0.6 et avant, un seul PNJ possible) : sert uniquement à repérer et
     *  supprimer les PNJ orphelins posés par cette ancienne version lors de la migration. */
    private final NamespacedKey legacyNpcTagKey;

    public WorldStructuresManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.composterMarkerKey = new NamespacedKey(plugin, "hoe_world_composter_location");
        this.barrelMarkerKey = new NamespacedKey(plugin, "hoe_world_barrel_location");
        this.farmPatchMarkerKey = new NamespacedKey(plugin, "hoe_world_farm_patch_location");
        this.lecternMarkerKey = new NamespacedKey(plugin, "hoe_world_lectern_location");
        this.tagEntityKey = new NamespacedKey(plugin, "hoe_world_structure_tag");
        this.npcIdKey = new NamespacedKey(plugin, "hoe_world_npc_id");
        this.legacyNpcTagKey = new NamespacedKey(plugin, "hoe_world_shop_npc");
    }

    /** (Re)lit config.yml et (re)pose toutes les structures à leurs emplacements actuels,
     *  en effaçant l'ancien emplacement si une position a changé depuis la dernière fois.
     *  Appelée au démarrage ET périodiquement (StructureIntegrityTask) pour l'auto-réparation.
     *  farmExpanded = true si le champ dupliqué (patate, débloqué au Void Composter Tier 2+)
     *  doit être présent. */
    public void applyAll(World world, boolean farmExpanded) {
        if (world == null) return;
        var config = plugin.getConfig();

        removeLegacyNpcs(world, config.getInt("npc.x", 6), config.getInt("npc.z", 39));
        removeLegacyNpcs(world, config.getInt("npc_farm_buyer.x", 8), config.getInt("npc_farm_buyer.z", 39));

        applyComposter(world,
                config.getInt("composter.x", 10), config.getInt("composter.y", 1), config.getInt("composter.z", 10),
                config.getString("composter.name", "Void Composter"));
        applyBarrel(world,
                config.getInt("barrel.x", 12), config.getInt("barrel.y", 1), config.getInt("barrel.z", 10),
                config.getString("barrel.name", "Farmer's Inventory"));
        applyFarmPatch(world,
                config.getInt("farm_patch.x", 30), config.getInt("farm_patch.y", 1), config.getInt("farm_patch.z", 30),
                farmExpanded);
        applyLectern(world,
                config.getInt("lectern.x", 0), config.getInt("lectern.y", 1), config.getInt("lectern.z", 16),
                config.getString("lectern.facing", "NORTH"), config.getString("lectern.name", "Informations"));
        applyNpc(world, "seller",
                config.getInt("npc.x", 6), config.getInt("npc.y", 1), config.getInt("npc.z", 39),
                (float) config.getDouble("npc.yaw", 180), config.getString("npc.name", "Seed Seller"));
        applyNpc(world, "buyer",
                config.getInt("npc_farm_buyer.x", 8), config.getInt("npc_farm_buyer.y", 1), config.getInt("npc_farm_buyer.z", 39),
                (float) config.getDouble("npc_farm_buyer.yaw", 180), config.getString("npc_farm_buyer.name", "Farm Buyer"));
    }

    /** Supprime tout PNJ posé par l'ancien système (v0.1.0.6 et avant, un seul tag générique) :
     *  invisible pour la nouvelle logique par id, il ne pouvait jamais être nettoyé ni renommé
     *  et s'accumulait à chaque redémarrage. Force le chargement du chunk pour être sûr de le voir. */
    private void removeLegacyNpcs(World world, int x, int z) {
        world.getChunkAt(x >> 4, z >> 4).load();
        for (Entity entity : new ArrayList<>(world.getEntities())) {
            if (entity instanceof Villager villager
                    && villager.getPersistentDataContainer().has(legacyNpcTagKey, PersistentDataType.BYTE)) {
                villager.remove();
            }
        }
    }

    // ----- PNJ(s) marchand(s) -----

    /** id = identifiant stable ("seller", "buyer", ...) pour distinguer plusieurs PNJ. Force le
     *  chargement du chunk avant de chercher un PNJ existant (sinon, un PNJ posé dans un chunk pas
     *  encore chargé au démarrage n'est pas vu -> un doublon était reposé à chaque redémarrage,
     *  c'était le bug). Garantit qu'il n'existe jamais plus d'un PNJ pour cet id. */
    private void applyNpc(World world, String id, int x, int y, int z, float yaw, String name) {
        world.getChunkAt(x >> 4, z >> 4).load();

        NamespacedKey markerKey = new NamespacedKey(plugin, "hoe_world_npc_location_" + id);
        String marker = x + "," + y + "," + z + "," + yaw + "," + name;
        String previous = world.getPersistentDataContainer().get(markerKey, PersistentDataType.STRING);

        List<Villager> found = findNpcs(world, id);
        if (found.size() == 1 && marker.equals(previous)) {
            found.get(0).customName(Component.text(name, NamedTextColor.GREEN));
        } else {
            for (Villager villager : found) {
                villager.remove();
            }
            spawnNpc(world, id, x, y, z, yaw, name);
        }
        world.getPersistentDataContainer().set(markerKey, PersistentDataType.STRING, marker);
    }

    /** Supprime toute armor stand "hologramme" flottante encore présente dans les chunks CHARGÉS
     *  du monde mais qui n'est PAS taguée par ce manager : orpheline d'une version plus ancienne
     *  du plugin (avant l'ajout du tag), ex: recréée à un ancien emplacement après un déplacement
     *  de structure. Retourne le nombre supprimé. Le joueur doit être à proximité pour que le
     *  chunk soit chargé (les chunks non chargés ne sont pas scannés). */
    public int cleanupStrayHolograms(World world) {
        int removed = 0;
        for (Entity entity : new ArrayList<>(world.getEntities())) {
            if (entity instanceof ArmorStand stand && stand.isCustomNameVisible()
                    && !stand.getPersistentDataContainer().has(tagEntityKey, PersistentDataType.BYTE)) {
                stand.remove();
                removed++;
            } else if (entity instanceof Villager villager
                    && villager.getPersistentDataContainer().has(legacyNpcTagKey, PersistentDataType.BYTE)) {
                villager.remove();
                removed++;
            }
        }
        return removed;
    }

    /** id du PNJ géré par ce manager si cette entité en est un ("seller"/"buyer"), sinon null. */
    public String getNpcId(Entity entity) {
        if (!(entity instanceof Villager)) return null;
        return entity.getPersistentDataContainer().get(npcIdKey, PersistentDataType.STRING);
    }

    private List<Villager> findNpcs(World world, String id) {
        List<Villager> result = new ArrayList<>();
        for (Entity entity : world.getEntities()) {
            if (entity instanceof Villager villager
                    && id.equals(villager.getPersistentDataContainer().get(npcIdKey, PersistentDataType.STRING))) {
                result.add(villager);
            }
        }
        return result;
    }

    private void spawnNpc(World world, String id, int x, int y, int z, float yaw, String name) {
        Location loc = new Location(world, x + 0.5, y, z + 0.5, yaw, 0);
        world.spawn(loc, Villager.class, villager -> {
            villager.setAI(false);
            villager.setInvulnerable(true);
            villager.setSilent(true);
            villager.setGravity(false);
            villager.setCollidable(false);
            villager.setPersistent(true);
            villager.setCustomNameVisible(true);
            villager.customName(Component.text(name, NamedTextColor.GREEN));
            villager.setVillagerType(org.bukkit.entity.Villager.Type.PLAINS);
            villager.setProfession(org.bukkit.entity.Villager.Profession.NONE);
            villager.getPersistentDataContainer().set(npcIdKey, PersistentDataType.STRING, id);
        });
    }

    // ----- Composter -----

    private void applyComposter(World world, int x, int y, int z, String name) {
        String marker = x + "," + y + "," + z + "," + name;
        String previous = world.getPersistentDataContainer().get(composterMarkerKey, PersistentDataType.STRING);
        if (previous != null && !previous.equals(marker)) {
            int[] p = parseXYZ(previous);
            clearSingleBlock(world, p[0], p[1], p[2]);
        }
        placeComposter(world, x, y, z, name);
        world.getPersistentDataContainer().set(composterMarkerKey, PersistentDataType.STRING, marker);
    }

    private void placeComposter(World world, int x, int y, int z, String name) {
        Block block = world.getBlockAt(x, y, z);
        if (block.getType() != Material.COMPOSTER) {
            block.setType(Material.COMPOSTER, false);
        }
        spawnNameTagIfMissing(world, x, y, z, name);
    }

    // ----- Barrel -----

    private void applyBarrel(World world, int x, int y, int z, String name) {
        String marker = x + "," + y + "," + z + "," + name;
        String previous = world.getPersistentDataContainer().get(barrelMarkerKey, PersistentDataType.STRING);
        if (previous != null && !previous.equals(marker)) {
            int[] p = parseXYZ(previous);
            clearSingleBlock(world, p[0], p[1], p[2]);
        }
        placeBarrel(world, x, y, z, name);
        world.getPersistentDataContainer().set(barrelMarkerKey, PersistentDataType.STRING, marker);
    }

    private void placeBarrel(World world, int x, int y, int z, String name) {
        Block block = world.getBlockAt(x, y, z);
        if (block.getType() != Material.BARREL) {
            block.setType(Material.BARREL, false);
        }
        if (block.getState() instanceof org.bukkit.block.Barrel barrel) {
            barrel.customName(Component.text(name));
            barrel.update();
        }
        spawnNameTagIfMissing(world, x, y, z, name);
    }

    // ----- Farm patch -----

    /** Z de départ de la 2e moitié (patate) : juste après la bordure partagée avec la 1re moitié. */
    public static int secondPatchZ(int z0) {
        return z0 + FARM_DEPTH + 1;
    }

    private void applyFarmPatch(World world, int x0, int y, int z0, boolean expanded) {
        String marker = x0 + "," + y + "," + z0 + "," + expanded;
        String previous = world.getPersistentDataContainer().get(farmPatchMarkerKey, PersistentDataType.STRING);
        if (previous != null && !previous.equals(marker)) {
            String[] parts = previous.split(",");
            clearFarmPatchMax(world, Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
        }
        placeFarmPatch(world, x0, y, z0, expanded);
        world.getPersistentDataContainer().set(farmPatchMarkerKey, PersistentDataType.STRING, marker);
    }

    /** Relit config.yml et repose immédiatement le champ (sans attendre le prochain passage de
     *  StructureIntegrityTask) : utilisé juste après un tier up / checkpoint du Void Composter. */
    public void refreshFarmPatch(World world, boolean expanded) {
        if (world == null) return;
        var config = plugin.getConfig();
        applyFarmPatch(world,
                config.getInt("farm_patch.x", 30), config.getInt("farm_patch.y", 1), config.getInt("farm_patch.z", 30),
                expanded);
    }

    /** Champ(s) 5x2 labouré(s) + humidifié(s) en permanence, bordé(s) de bûches verticales. Si
     *  expanded, une 2e moitié (patate) est dupliquée juste après en partageant la même colonne
     *  de bordure que la 1re moitié (blé). */
    private void placeFarmPatch(World world, int x0, int y, int z0, boolean expanded) {
        tillPatch(world, x0, y, z0);
        int sharedBorderZ = z0 + FARM_DEPTH;
        int secondZ0 = secondPatchZ(z0);
        if (expanded) {
            tillPatch(world, x0, y, secondZ0);
        }

        int minX = x0 - 1;
        int maxX = x0 + FARM_WIDTH;
        int minZ = z0 - 1;
        int maxZ = expanded ? (secondZ0 + FARM_DEPTH) : sharedBorderZ;
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                boolean onBorder = x == minX || x == maxX || z == minZ || z == maxZ
                        || (expanded && z == sharedBorderZ);
                if (onBorder) {
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType() != Material.OAK_LOG) {
                        block.setType(Material.OAK_LOG, false); // axe Y (vertical) par défaut
                    }
                }
            }
        }
    }

    private void tillPatch(World world, int x0, int y, int z0) {
        for (int x = x0; x < x0 + FARM_WIDTH; x++) {
            for (int z = z0; z < z0 + FARM_DEPTH; z++) {
                Block block = world.getBlockAt(x, y, z);
                if (block.getType() != Material.FARMLAND) {
                    block.setType(Material.FARMLAND, false);
                }
                if (block.getBlockData() instanceof Levelled levelled && levelled.getLevel() != levelled.getMaximumLevel()) {
                    levelled.setLevel(levelled.getMaximumLevel());
                    block.setBlockData(levelled, false);
                }
            }
        }
    }

    /** Efface généreusement toute l'emprise possible du champ (les 2 moitiés comprises), utilisé
     *  quand la position ou l'état "expanded" a changé, pour ne jamais laisser de résidu. */
    private void clearFarmPatchMax(World world, int x0, int y, int z0) {
        int minX = x0 - 1;
        int maxX = x0 + FARM_WIDTH;
        int minZ = z0 - 1;
        int maxZ = secondPatchZ(z0) + FARM_DEPTH;
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                world.getBlockAt(x, y, z).setType(Material.AIR, false);
            }
        }
    }

    // ----- Lectern -----

    private void applyLectern(World world, int x, int y, int z, String facing, String name) {
        String marker = x + "," + y + "," + z + "," + facing + "," + name;
        String previous = world.getPersistentDataContainer().get(lecternMarkerKey, PersistentDataType.STRING);
        if (previous != null && !previous.equals(marker)) {
            String[] parts = previous.split(",");
            clearSingleBlock(world, Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
        }
        placeLectern(world, x, y, z, facing, name);
        world.getPersistentDataContainer().set(lecternMarkerKey, PersistentDataType.STRING, marker);
    }

    private void placeLectern(World world, int x, int y, int z, String facing, String name) {
        Block block = world.getBlockAt(x, y, z);
        if (block.getType() != Material.LECTERN) {
            block.setType(Material.LECTERN, false);
        }
        BlockData data = block.getBlockData();
        if (data instanceof Directional directional) {
            org.bukkit.block.BlockFace face;
            try {
                face = org.bukkit.block.BlockFace.valueOf(facing.toUpperCase());
            } catch (IllegalArgumentException ex) {
                face = org.bukkit.block.BlockFace.NORTH;
            }
            if (directional.getFacing() != face) {
                directional.setFacing(face);
                block.setBlockData(directional, false);
            }
        }
        spawnNameTagIfMissing(world, x, y, z, name);
    }

    // ----- Utilitaires communs -----

    private void clearSingleBlock(World world, int x, int y, int z) {
        world.getBlockAt(x, y, z).setType(Material.AIR, false);
        removeNameTag(world, x, y, z);
    }

    /** Pose une armor stand invisible/marker portant "name" juste au-dessus de (x;y;z), sauf si
     *  une étiquette posée par le plugin existe déjà à cet endroit (évite les doublons lors des
     *  passages répétés de StructureIntegrityTask). */
    private void spawnNameTagIfMissing(World world, int x, int y, int z, String name) {
        Location tagLoc = new Location(world, x + 0.5, y + 1.3, z + 0.5);

        // Une étiquette déjà taguée par le plugin existe : on la met juste à jour, rien d'autre à faire.
        for (Entity entity : world.getNearbyEntities(tagLoc, 0.6, 0.6, 0.6)) {
            if (entity instanceof ArmorStand stand
                    && stand.getPersistentDataContainer().has(tagEntityKey, PersistentDataType.BYTE)) {
                stand.customName(Component.text(name, NamedTextColor.GOLD));
                return;
            }
        }

        // Sinon : nettoie tout doublon "orphelin" (posé par une version plus ancienne du plugin,
        // avant l'ajout du tag, ex: après qu'un composter ait été cassé puis re-généré) avant
        // d'en reposer une seule, correctement taguée cette fois.
        for (Entity entity : world.getNearbyEntities(tagLoc, 0.6, 0.6, 0.6)) {
            if (entity instanceof ArmorStand) {
                entity.remove();
            }
        }

        world.spawn(tagLoc, ArmorStand.class, stand -> {
            stand.setInvisible(true);
            stand.setMarker(true);
            stand.setGravity(false);
            stand.setInvulnerable(true);
            stand.setSmall(true);
            stand.setBasePlate(false);
            stand.setCustomNameVisible(true);
            stand.customName(Component.text(name, NamedTextColor.GOLD));
            stand.setPersistent(true);
            stand.getPersistentDataContainer().set(tagEntityKey, PersistentDataType.BYTE, (byte) 1);
        });
    }

    private void removeNameTag(World world, int x, int y, int z) {
        Location tagLoc = new Location(world, x + 0.5, y + 1.3, z + 0.5);
        for (Entity entity : world.getNearbyEntities(tagLoc, 0.6, 0.6, 0.6)) {
            if (entity instanceof ArmorStand stand
                    && stand.getPersistentDataContainer().has(tagEntityKey, PersistentDataType.BYTE)) {
                stand.remove();
            }
        }
    }

    private int[] parseXYZ(String marker) {
        String[] parts = marker.split(",");
        return new int[]{Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2])};
    }
}
