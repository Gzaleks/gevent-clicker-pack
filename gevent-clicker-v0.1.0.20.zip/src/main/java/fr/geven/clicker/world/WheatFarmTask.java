package fr.geven.clicker.world;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;

import java.util.List;

/**
 * Deux tâches périodiques pour WheatFarmManager :
 *  - growth/self-heal (toutes les secondes) : met à jour l'âge visuel des graines plantées, et
 *    replante automatiquement un bloc de blé manquant (auto-réparation, comme les autres
 *    structures).
 *  - hologramme d'infos (toutes les 5 ticks) : quand un joueur regarde un emplacement planté,
 *    lui envoie une barre d'action avec la progression/temps restant/rendement.
 */
public class WheatFarmTask {

    private final JavaPlugin plugin;
    private final WheatFarmManager farmManager;
    private final CoinDoorWorldManager worldManager;

    public WheatFarmTask(JavaPlugin plugin, WheatFarmManager farmManager, CoinDoorWorldManager worldManager) {
        this.plugin = plugin;
        this.farmManager = farmManager;
        this.worldManager = worldManager;
    }

    public List<BukkitTask> start() {
        BukkitTask growth = new BukkitRunnable() {
            @Override
            public void run() {
                if (worldManager.getWorld() == null) return;
                farmManager.reapplyAll(worldManager.getWorld());
            }
        }.runTaskTimer(plugin, 20L, 20L);

        BukkitTask actionBar = new BukkitRunnable() {
            @Override
            public void run() {
                if (worldManager.getWorld() == null) return;
                for (Player player : worldManager.getWorld().getPlayers()) {
                    sendInfoIfLookingAtSeed(player);
                }
            }
        }.runTaskTimer(plugin, 5L, 5L);

        return List.of(growth, actionBar);
    }

    private void sendInfoIfLookingAtSeed(Player player) {
        RayTraceResult trace = player.rayTraceBlocks(6.0);
        if (trace == null || trace.getHitBlock() == null) return;
        Block block = trace.getHitBlock();
        if (block.getType() != Material.WHEAT) return;

        int slot = farmManager.slotIndexFor(block);
        if (slot < 0 || !farmManager.isActiveSlot(slot)) return;

        double progress = farmManager.progressForSlot(slot);
        int barLength = 20;
        int filled = (int) Math.round(progress * barLength);
        String bar = "█".repeat(Math.max(0, filled)) + "░".repeat(Math.max(0, barLength - filled));

        Component message;
        if (farmManager.isMature(slot)) {
            message = Component.text(bar, NamedTextColor.GREEN)
                    .append(Component.text("  Prêt à récolter !  ", NamedTextColor.GOLD))
                    .append(Component.text("+" + farmManager.getYieldPerHarvest() + " blé", NamedTextColor.YELLOW));
        } else {
            int remaining = farmManager.secondsRemainingForSlot(slot);
            message = Component.text(bar, NamedTextColor.GREEN)
                    .append(Component.text("  " + remaining + "s / " + farmManager.getGrowSeconds() + "s  ",
                            NamedTextColor.WHITE))
                    .append(Component.text("+" + farmManager.getYieldPerHarvest() + " blé", NamedTextColor.YELLOW));
        }
        player.sendActionBar(message);
    }
}
