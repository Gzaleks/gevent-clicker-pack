package fr.geven.clicker.xp;

import org.bukkit.entity.Player;

/**
 * Fait correspondre la barre d'expérience / niveau vanille du joueur
 * (celle visible en bas de l'écran) à son XP custom stockée par le plugin.
 */
public final class XpBarSync {

    private XpBarSync() {
    }

    public static void sync(Player player, long totalXp) {
        int level = LevelCurve.levelForXp(totalXp);
        float progress = LevelCurve.progressInLevel(totalXp);
        player.setLevel(level);
        player.setExp(Math.max(0f, Math.min(progress, 1f)));
    }
}
