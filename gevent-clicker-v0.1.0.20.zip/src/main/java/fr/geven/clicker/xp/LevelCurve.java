package fr.geven.clicker.xp;

/**
 * Modélise la courbe d'expérience du plugin.
 *
 * Formule : xp nécessaire pour passer du niveau n au niveau n+1 = 10 * r^n
 * où r est calculé pour que :
 *   - niveau 0 -> 1 coûte exactement 10 xp
 *   - niveau 999 -> 1000 coûte exactement 2 000 000 000 xp (2 milliards)
 *
 * r = (2_000_000_000 / 10) ^ (1/999) ≈ 1.01932 (environ +1.93% par niveau).
 *
 * Le dernier palier (999 -> 1000) est fixé de façon exacte à 2 000 000 000
 * pour ne souffrir d'aucune dérive d'arrondi après les 999 multiplications.
 */
public final class LevelCurve {

    public static final int MAX_LEVEL = 1000;
    private static final double BASE_XP = 10.0;
    private static final long LAST_STEP_XP = 2_000_000_000L;
    private static final double R = Math.pow(LAST_STEP_XP / BASE_XP, 1.0 / (MAX_LEVEL - 1));

    // REQUIRED[n] = xp nécessaire pour passer du niveau n au niveau n+1 (n de 0 à 999)
    private static final long[] REQUIRED = new long[MAX_LEVEL];
    // CUMULATIVE[level] = xp total nécessaire depuis 0 pour atteindre "level" (0 à 1000)
    private static final long[] CUMULATIVE = new long[MAX_LEVEL + 1];
    public static final long MAX_TOTAL_XP;

    static {
        for (int n = 0; n < MAX_LEVEL - 1; n++) {
            REQUIRED[n] = Math.round(BASE_XP * Math.pow(R, n));
        }
        REQUIRED[MAX_LEVEL - 1] = LAST_STEP_XP; // ancrage exact du dernier palier

        CUMULATIVE[0] = 0L;
        for (int level = 1; level <= MAX_LEVEL; level++) {
            CUMULATIVE[level] = CUMULATIVE[level - 1] + REQUIRED[level - 1];
        }
        MAX_TOTAL_XP = CUMULATIVE[MAX_LEVEL];
    }

    private LevelCurve() {
    }

    /** XP totale nécessaire pour atteindre ce niveau depuis 0. */
    public static long cumulativeXpForLevel(int level) {
        level = Math.max(0, Math.min(level, MAX_LEVEL));
        return CUMULATIVE[level];
    }

    /** XP nécessaire pour passer de ce niveau au suivant (0 si niveau max atteint). */
    public static long xpForNextLevel(int level) {
        if (level >= MAX_LEVEL) return 0L;
        return REQUIRED[level];
    }

    /**
     * Même formule que {@link #xpForNextLevel}, mais en valeur EXACTE (non arrondie à
     * l'entier). À utiliser quand on a besoin de multiplier cette valeur par autre chose
     * (ex: un prix) : réutiliser la table arrondie ferait des paliers plats artificiels sur
     * les premières valeurs (10, 10, 10, 11... avant même que r ait un effet visible).
     */
    public static double preciseXpForNextLevel(int level) {
        if (level >= MAX_LEVEL) return 0.0;
        return BASE_XP * Math.pow(R, level);
    }

    /** Détermine le niveau correspondant à une quantité d'xp totale (recherche dichotomique). */
    public static int levelForXp(long totalXp) {
        totalXp = Math.max(0, Math.min(totalXp, MAX_TOTAL_XP));

        int low = 0, high = MAX_LEVEL;
        while (low < high) {
            int mid = (low + high + 1) >>> 1;
            if (CUMULATIVE[mid] <= totalXp) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return low;
    }

    /** Progression (0.0 à 1.0) à l'intérieur du niveau actuel, pour la barre d'xp vanille. */
    public static float progressInLevel(long totalXp) {
        int level = levelForXp(totalXp);
        if (level >= MAX_LEVEL) return 1.0f;
        long into = totalXp - CUMULATIVE[level];
        long need = REQUIRED[level];
        return need == 0 ? 0f : (float) ((double) into / (double) need);
    }

    /** XP déjà acquise dans le niveau actuel (hors totalXp). */
    public static long xpIntoCurrentLevel(long totalXp) {
        int level = levelForXp(totalXp);
        return totalXp - CUMULATIVE[level];
    }
}
