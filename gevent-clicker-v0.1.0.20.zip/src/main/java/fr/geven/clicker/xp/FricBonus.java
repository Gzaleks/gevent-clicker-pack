package fr.geven.clicker.xp;

/**
 * Bonus permanent de Fric accordé par le niveau d'xp du joueur.
 * Chaque niveau passé (à partir du niveau 1) ajoute +0.2 au multiplicateur de Fric :
 *   niveau 0 -> x1.0 (aucun bonus)
 *   niveau 1 -> x1.2
 *   niveau 2 -> x1.4
 *   niveau 3 -> x1.6
 *   ...
 */
public final class FricBonus {

    private static final double BONUS_PER_LEVEL = 0.2;

    private FricBonus() {
    }

    public static double multiplierForLevel(int level) {
        return 1.0 + BONUS_PER_LEVEL * level;
    }

    public static double applyBonus(double baseAmount, int level) {
        return baseAmount * multiplierForLevel(level);
    }
}
