package fr.geven.clicker.rank;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.key.Key;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère le rank de chaque joueur (fichier plugins/Gevent_Clicker/ranks.yml) et applique le
 * préfixe correspondant (badge custom via le resource pack + nom du rank) dans le tab-list.
 */
public class RankManager {

    private final JavaPlugin plugin;
    private final File dataFile;
    private final Map<UUID, Rank> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public RankManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "ranks.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                Rank rank = Rank.fromName(config.getString(key, "DIRTY"));
                cache.put(uuid, rank != null ? rank : Rank.DIRTY);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans ranks.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " rank(s) chargé(s).");
    }

    public Rank getRank(UUID uuid) {
        return cache.getOrDefault(uuid, Rank.DIRTY);
    }

    public void setRank(UUID uuid, Rank rank) {
        cache.put(uuid, rank);
        dirty = true;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, Rank> entry : cache.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue().name());
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder ranks.yml", ex);
        }
    }

    /**
     * Applique le nom affiché dans le tab-list pour ce joueur, avec le badge de son rank.
     * Le badge (fond + texte du rank) est une seule image custom : taille AFFICHÉE petite et
     * inchangée (10, tient dans la ligne), mais fichier source en résolution 8x plus fine que
     * cette taille affichée — c'est ça qui donne des contours nets et détaillés plutôt que des
     * gros pixels, peu importe l'échelle GUI du joueur.
     */
    public void applyListName(Player player) {
        Rank rank = getRank(player.getUniqueId());

        String fontKey = rank == Rank.ADMIN ? "badge_admin" : "badge_dirty";
        Component badge = Component.text("\uE010").font(Key.key("gevent_clicker", fontKey));

        Component listName = badge
                .append(Component.text("  ").font(Key.key("minecraft", "default")))
                .append(Component.text(player.getName(), rank.color)
                        .font(Key.key("minecraft", "default"))
                        .decoration(TextDecoration.ITALIC, false));

        player.playerListName(listName);
    }
}
