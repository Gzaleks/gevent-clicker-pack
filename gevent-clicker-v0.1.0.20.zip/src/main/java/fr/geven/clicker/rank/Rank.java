package fr.geven.clicker.rank;

import fr.geven.clicker.util.NumberFormatting;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;

import java.util.List;

/**
 * Les ranks du serveur. Pour l'instant seulement 2 :
 *  - DIRTY : rank joueur par défaut (marron, même couleur que le Dirt)
 *  - ADMIN : rank staff (rouge foncé)
 *
 * {@link #STAFF_ORDER} définit l'échelle des ranks STAFF UNIQUEMENT, dans l'ordre, utilisée
 * par /rankup. DIRTY n'y figure pas exprès : ce n'est pas un rank staff, donc /rankup n'a
 * aucun effet dessus (il faudra un autre moyen pour donner le tout premier rank staff — à
 * ajouter quand il y aura un vrai besoin).
 */
public enum Rank {

    DIRTY("Dirty", NumberFormatting.DIRT_COLOR, false),
    ADMIN("Admin", NamedTextColor.DARK_RED, true);

    /** Échelle des ranks STAFF, dans l'ordre de progression. DIRTY n'y est pas (pas un rank staff). */
    public static final List<Rank> STAFF_ORDER = List.of(ADMIN);

    public final String displayName;
    public final TextColor color;
    public final boolean staff;

    Rank(String displayName, TextColor color, boolean staff) {
        this.displayName = displayName;
        this.color = color;
        this.staff = staff;
    }

    /** Rank staff suivant dans {@link #STAFF_ORDER}, ou null s'il n'y en a pas (pas staff, ou déjà au sommet). */
    public Rank nextStaffRank() {
        if (!staff) return null;
        int idx = STAFF_ORDER.indexOf(this);
        if (idx < 0 || idx + 1 >= STAFF_ORDER.size()) return null;
        return STAFF_ORDER.get(idx + 1);
    }

    public static Rank fromName(String name) {
        for (Rank rank : values()) {
            if (rank.name().equalsIgnoreCase(name) || rank.displayName.equalsIgnoreCase(name)) {
                return rank;
            }
        }
        return null;
    }
}
