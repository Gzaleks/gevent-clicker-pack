package fr.geven.clicker.rank;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/** Applique le badge de rank dans le tab-list dès la connexion du joueur. */
public class RankJoinListener implements Listener {

    private final RankManager rankManager;

    public RankJoinListener(RankManager rankManager) {
        this.rankManager = rankManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        rankManager.applyListName(event.getPlayer());
    }
}
