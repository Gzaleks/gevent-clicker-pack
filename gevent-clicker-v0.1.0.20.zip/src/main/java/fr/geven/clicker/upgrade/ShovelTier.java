package fr.geven.clicker.upgrade;

import org.bukkit.Material;

/**
 * Les tiers de l'amélioration "Clicker Upgrader" (la pelle).
 * Tier 1 : pelle en bois, jusqu'à 20 achats, +0.1 Fric/clic chacun, prix dès $1, croissance x1.35.
 * Tier 2 : pelle en pierre, jusqu'à 40 achats, +0.2 Fric/clic chacun, prix dès $2, croissance x1.5.
 */
public enum ShovelTier {

    TIER_1(1, Material.WOODEN_SHOVEL, 20, 1.0, 1.35, 0.1),
    TIER_2(2, Material.STONE_SHOVEL, 40, 2.0, 1.18, 0.2),
    TIER_3(3, Material.IRON_SHOVEL, 60, 10.0, 1.14, 0.4),
    TIER_4(4, Material.DIAMOND_SHOVEL, 80, 8.1, 1.16, 0.8),
    TIER_5(5, Material.NETHERITE_SHOVEL, 100, 1.8, 1.17, 1.6);

    public final int tier;
    public final Material material;
    public final int maxPurchases;
    public final double baseCost;
    public final double growth;
    public final double bonusPerPurchase;

    ShovelTier(int tier, Material material, int maxPurchases, double baseCost, double growth, double bonusPerPurchase) {
        this.tier = tier;
        this.material = material;
        this.maxPurchases = maxPurchases;
        this.baseCost = baseCost;
        this.growth = growth;
        this.bonusPerPurchase = bonusPerPurchase;
    }

    /** Prix du (purchases + 1)-ième achat pour ce tier. -1 si déjà au maximum de ce tier. */
    public long priceForNextPurchase(int purchases) {
        if (purchases >= maxPurchases) return -1L;
        return Math.round(Math.ceil(baseCost * Math.pow(growth, purchases)));
    }

    /** Bonus de Fric total (additif, avant multiplicateur xp) apporté par ce nombre d'achats dans ce tier. */
    public double totalBonus(int purchases) {
        return purchases * bonusPerPurchase;
    }

    public static ShovelTier fromInt(int tierNumber) {
        if (tierNumber >= 5) return TIER_5;
        if (tierNumber == 4) return TIER_4;
        if (tierNumber == 3) return TIER_3;
        if (tierNumber == 2) return TIER_2;
        return TIER_1;
    }

    /** Tier suivant, ou null si celui-ci est déjà le dernier implémenté. */
    public ShovelTier next() {
        return switch (this) {
            case TIER_1 -> TIER_2;
            case TIER_2 -> TIER_3;
            case TIER_3 -> TIER_4;
            case TIER_4 -> TIER_5;
            case TIER_5 -> null;
        };
    }
}
