package fr.geven.clicker.upgrade;

import fr.geven.clicker.xp.LevelCurve;

/**
 * Amélioration de la fiole d'expérience.
 *
 * Une fois la fiole débloquée (pelle tier 2), chaque clic sur le bloc de terre rapporte
 * de l'xp en plus du Fric : 1 point de base, + un bonus additif par achat effectué ici.
 * Le niveau du joueur (et donc son bonus de Fric via FricBonus) progresse alors naturellement
 * au fil des clics, sans "achat de niveau" direct.
 *
 * Prix de l'amélioration : réutilise la même courbe exponentielle que le niveau d'xp du joueur,
 * mais appliquée au nombre d'ACHATS DE LA FIOLE elle-même (pas au niveau d'xp live du joueur —
 * c'était un bug corrigé précédemment). 300 × l'xp "virtuelle" du niveau suivant, soit $3000
 * pour le 1er achat (augmenté drastiquement sur demande, x25 par rapport à l'ancien x12).
 * Plafonné à 1000 achats (même limite que le niveau max du joueur).
 */
public final class BottleUpgrade {

    /** Xp de base gagnée par clic sur le bloc de terre, une fois la fiole débloquée. */
    public static final double BASE_XP_PER_CLICK = 0.5;

    /** Bonus d'xp additif par clic, par achat effectué. */
    public static final double BONUS_XP_PER_PURCHASE = 0.1;

    /** Niveau maximum de l'amélioration (même plafond que le niveau d'xp du joueur, 1000). */
    public static final int MAX_PURCHASES = 1000;

    private static final long PRICE_MULTIPLIER = 150L;

    private BottleUpgrade() {
    }

    /** Xp gagnée par clic sur le bloc de terre pour ce nombre d'achats et ces améliorations permanentes. */
    public static double xpPerClick(int purchases, StrongUpgrades strongUpgrades) {
        double bonusPerPurchase = BONUS_XP_PER_PURCHASE
                + (strongUpgrades.betterExperience() ? StrongUpgrades.BETTER_EXPERIENCE_BONUS : 0.0);
        double raw = BASE_XP_PER_CLICK + bonusPerPurchase * purchases;
        return raw * strongUpgrades.xpMultiplier();
    }

    /**
     * Prix de la prochaine amélioration, basé sur le nombre d'achats DÉJÀ FAITS pour cette
     * amélioration (pas le niveau d'xp du joueur). 0 si le plafond de 1000 achats est atteint.
     */
    public static long priceForNextPurchase(int purchases) {
        if (purchases >= MAX_PURCHASES) return 0L;
        return Math.round(PRICE_MULTIPLIER * LevelCurve.preciseXpForNextLevel(purchases));
    }
}
