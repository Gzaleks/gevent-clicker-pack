package fr.geven.clicker.upgrade;

/**
 * Formules de prix/effet des améliorations de l'interface Dirtyfy Upgrades.
 * Toutes payées en Grass.
 */
public final class DirtyfyUpgradePricing {

    // --- Base Dirt Booster : 10 niveaux, +1$ de base par clic chacun, $2 -> ~$1000 Grass ---
    private static final double BOOSTER_BASE = 2.0;
    private static final double BOOSTER_GROWTH = 1.9947;
    public static final double BOOSTER_BONUS_PER_LEVEL = 1.5;

    // --- Mardi Grass : 50 niveaux, x0.3 cumulatif au gain de Grass, $2 -> $5000 Grass ---
    private static final double MARDI_BASE = 2.0;
    private static final double MARDI_GROWTH = 1.1731;
    public static final double MARDI_BONUS_PER_LEVEL = 0.5;

    // --- Grass Base Booster : 10 niveaux, +5 Grass de base par Dirtyfy chacun, 8 -> ~1100 Grass ---
    private static final double GRASS_BOOSTER_BASE = 8.0;
    private static final double GRASS_BOOSTER_GROWTH = 1.7281808511278198;
    public static final double GRASS_BOOSTER_BONUS_PER_LEVEL = 5.0;

    public static final long EXPERIENCE_AUTOBUYER_PRICE = 115L;

    // --- Ouverture de Chagrass : 3 achats, prix fixes, x2 cumulatif au Grass gagné par Dirtyfy ---
    public static final long[] CHAGRASS_PRICES = {40L, 200L, 1000L};

    // --- Fenêtre XP : achat unique, x1.5 EN PLUS du bonus de niveau d'xp déjà appliqué au Dirt ---
    public static final long FENETRE_XP_PRICE = 800L;
    public static final double FENETRE_XP_MULTIPLIER = 1.5;

    // --- XP for homeless : 10 niveaux, xp passive/sec, $12 -> ~$4000 Grass sur les 10 niveaux ---
    private static final double HOMELESS_BASE = 12.0;
    private static final double HOMELESS_GROWTH = 1.9069;

    // --- Grassification : achat unique final, débloque le Shovel Coin ---
    public static final long GRASSIFICATION_PRICE = 5000L;

    private DirtyfyUpgradePricing() {
    }

    /** Prix (en Grass) du prochain niveau de Chagrass. -1 si déjà au maximum. */
    public static long chagrassPrice(int currentLevel) {
        if (currentLevel >= fr.geven.clicker.data.DirtyfyUpgradeManager.CHAGRASS_MAX) return -1L;
        return CHAGRASS_PRICES[currentLevel];
    }

    /** Multiplicateur de Grass gagné par Dirtyfy pour ce niveau de Chagrass (cumulatif x2 par niveau). */
    public static double chagrassMultiplier(int level) {
        return Math.pow(2.0, level);
    }

    /** Prix (en Grass) du prochain niveau de XP for homeless. -1 si déjà au maximum. */
    public static long xpForHomelessPrice(int currentLevel) {
        if (currentLevel >= fr.geven.clicker.data.DirtyfyUpgradeManager.XP_FOR_HOMELESS_MAX) return -1L;
        return Math.round(Math.ceil(HOMELESS_BASE * Math.pow(HOMELESS_GROWTH, currentLevel)));
    }

    /** Xp passive générée par seconde pour ce niveau de XP for homeless (courbe triangulaire). */
    public static double xpForHomelessRate(int level) {
        return level * (level + 1) / 2.0;
    }

    /** Prix (en Grass) du prochain niveau de Base Dirt Booster. -1 si déjà au maximum. */
    public static long baseDirtBoosterPrice(int currentLevel) {
        if (currentLevel >= fr.geven.clicker.data.DirtyfyUpgradeManager.BASE_DIRT_BOOSTER_MAX) return -1L;
        return Math.round(Math.ceil(BOOSTER_BASE * Math.pow(BOOSTER_GROWTH, currentLevel)));
    }

    /** Prix (en Grass) du prochain niveau de Mardi Grass. -1 si déjà au maximum. */
    public static long mardiGrassPrice(int currentLevel) {
        if (currentLevel >= fr.geven.clicker.data.DirtyfyUpgradeManager.MARDI_GRASS_MAX) return -1L;
        return Math.round(Math.ceil(MARDI_BASE * Math.pow(MARDI_GROWTH, currentLevel)));
    }

    /** Prix (en Grass) du prochain niveau de Grass Base Booster. -1 si déjà au maximum. */
    public static long grassBaseBoosterPrice(int currentLevel) {
        if (currentLevel >= fr.geven.clicker.data.DirtyfyUpgradeManager.GRASS_BOOSTER_MAX) return -1L;
        return Math.round(Math.ceil(GRASS_BOOSTER_BASE * Math.pow(GRASS_BOOSTER_GROWTH, currentLevel)));
    }

    /** Multiplicateur de Grass gagné par Dirtyfy, pour ce niveau de Mardi Grass. */
    public static double mardiGrassMultiplier(int level) {
        return 1.0 + level * MARDI_BONUS_PER_LEVEL;
    }
}
