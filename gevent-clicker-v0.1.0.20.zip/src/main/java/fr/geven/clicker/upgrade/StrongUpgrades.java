package fr.geven.clicker.upgrade;

/**
 * État des améliorations à achat unique de l'interface "Strong Upgrade".
 * Regroupées ici pour éviter de faire circuler des booléens séparés dans toutes les signatures.
 */
public record StrongUpgrades(boolean fricX2, boolean xpX2, boolean betterShovel, boolean betterExperience,
                              boolean fricX2_5, boolean xpX2_5, boolean autoDirting,
                              boolean autoDirtingMoreInfo, boolean moreAutoDirt) {

    public static final StrongUpgrades NONE =
            new StrongUpgrades(false, false, false, false, false, false, false, false, false);

    /** Prix d'achat de chaque amélioration. */
    public static final long FRIC_X2_PRICE = 17_000L;
    public static final long XP_X2_PRICE = 19_000L;
    public static final long BETTER_SHOVEL_PRICE = 15_500L;
    public static final long BETTER_EXPERIENCE_PRICE = 12_800L;
    public static final long FRIC_X2_5_PRICE = 89_000L;
    public static final long XP_X2_5_PRICE = 180_000L;
    public static final long AUTO_DIRTING_PRICE = 100_001L;
    /** ⚠️ Prix non précisé pour celle-ci, valeur proposée par défaut. */
    public static final long AUTO_DIRTING_MORE_INFO_PRICE = 50_000L;
    public static final long MORE_AUTO_DIRT_PRICE = 120_000L;

    /** Bonus additif apporté par "Better Shovel"/"Better Experience" au taux par achat. */
    public static final double BETTER_SHOVEL_BONUS = 0.1;
    public static final double BETTER_EXPERIENCE_BONUS = 0.1;

    /** Taux de base de l'Auto Dirting (Dirt/seconde), doublé si "More Auto Dirt" est acheté. */
    public static final double AUTO_DIRTING_BASE_RATE = 100.0;

    /** Multiplicateur de Dirt total apporté par les upgrades Fric x2 / x2.5 (cumulables). */
    public double fricMultiplier() {
        double m = 1.0;
        if (fricX2) m *= 2.0;
        if (fricX2_5) m *= 2.5;
        return m;
    }

    /** Multiplicateur d'xp total apporté par les upgrades XP x2 / x2.5 (cumulables). */
    public double xpMultiplier() {
        double m = 1.0;
        if (xpX2) m *= 2.0;
        if (xpX2_5) m *= 2.5;
        return m;
    }

    /** Taux actuel de l'Auto Dirting en Dirt/seconde (0 si pas achetée). */
    public double autoDirtingRatePerSecond() {
        if (!autoDirting) return 0.0;
        return moreAutoDirt ? AUTO_DIRTING_BASE_RATE * 2.0 : AUTO_DIRTING_BASE_RATE;
    }
}
