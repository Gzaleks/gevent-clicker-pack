package fr.geven.clicker.listener;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.gui.InfoGui;
import fr.geven.clicker.gui.InfoHolder;
import fr.geven.clicker.gui.InfoItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Gère le "?" informatif tout à gauche de la hotbar (slot 0) : toujours présent dès la première
 * connexion, indéplaçable, indroppable, ne se perd jamais à la mort. Clic dessus ouvre
 * l'interface "Informations". Même technique de protection que CoinSlotsListener.
 */
public class InfoItemListener implements Listener {

    public static final int HOTBAR_SLOT = 0;

    private final JavaPlugin plugin;
    private final InfoItem infoItem;
    private final UpgradeManager upgradeManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public InfoItemListener(JavaPlugin plugin, InfoItem infoItem, UpgradeManager upgradeManager,
                             DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.plugin = plugin;
        this.infoItem = infoItem;
        this.upgradeManager = upgradeManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    /** S'assure que le slot 0 de la hotbar contient bien le "?" informatif. */
    public void ensurePresent(Player player) {
        PlayerInventory inv = player.getInventory();
        if (!infoItem.matches(inv.getItem(HOTBAR_SLOT))) {
            inv.setItem(HOTBAR_SLOT, infoItem.build());
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        ItemStack item = event.getItem();
        if (!infoItem.matches(item)) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        InfoHolder holder = new InfoHolder();
        player.openInventory(InfoGui.create(holder, upgradeManager, dirtyfyUpgradeManager, player.getUniqueId(), 0));
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        boolean touchesItem = infoItem.matches(event.getCurrentItem()) || infoItem.matches(event.getCursor());
        boolean isProtectedSlot = event.getClickedInventory() instanceof PlayerInventory
                && event.getSlot() == HOTBAR_SLOT;

        if (touchesItem || isProtectedSlot) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        for (ItemStack stack : event.getNewItems().values()) {
            if (infoItem.matches(stack)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (infoItem.matches(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(infoItem::matches);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        ensurePresent(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> ensurePresent(player));
    }
}
