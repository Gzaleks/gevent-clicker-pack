package fr.geven.clicker.listener;

import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.data.GrassManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.xp.XpBarSync;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * À la connexion d'un joueur :
 *  - (re)crée son scoreboard (Dirt + xp + Grass)
 *  - synchronise la barre d'xp vanille avec son XP custom stockée
 */
public class PlayerJoinListener implements Listener {

    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final GrassManager grassManager;
    private final EcusManager ecusManager;
    private final FricScoreboardManager scoreboardManager;

    public PlayerJoinListener(PlayerDataManager dataManager, XpManager xpManager, GrassManager grassManager,
                               EcusManager ecusManager, FricScoreboardManager scoreboardManager) {
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.grassManager = grassManager;
        this.ecusManager = ecusManager;
        this.scoreboardManager = scoreboardManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        double fric = dataManager.getFric(player.getUniqueId());
        long xp = xpManager.getXp(player.getUniqueId());
        double grass = grassManager.getGrass(player.getUniqueId());
        long ecus = ecusManager.getEcus(player.getUniqueId());
        scoreboardManager.setup(player, fric, xp, grass, ecus);

        XpBarSync.sync(player, xp);
    }
}
