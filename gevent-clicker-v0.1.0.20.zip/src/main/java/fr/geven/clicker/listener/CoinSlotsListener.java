package fr.geven.clicker.listener;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.gui.ShovelCoinItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Gère les 4 emplacements "pièce" (bulle texturée en haut à gauche de l'inventaire du joueur,
 * slots bruts 9 à 12 de PlayerInventory = ligne du haut du stockage principal, juste au-dessus
 * de la hotbar) :
 *  - slot 9 (SHOVEL) : le vrai "Shovel Coin" une fois Grassification achetée, sinon un
 *    placeholder grisé qui préfigure l'emplacement.
 *  - slots 10/11/12 (PICKAXE/AXE/HOE) : toujours un placeholder grisé pour l'instant, en
 *    attente des futures améliorations finales de Pioche/Hache/Houe.
 * Les 4 slots (pièce réelle OU placeholder) sont protégés : indéplaçables, indroppables, ne se
 * perdent jamais à la mort, cliquer dessus ne fait rien.
 */
public class CoinSlotsListener implements Listener {

    public static final int SHOVEL_SLOT = 9;
    public static final int PICKAXE_SLOT = 10;
    public static final int AXE_SLOT = 11;
    public static final int HOE_SLOT = 12;
    private static final int[] PROTECTED_SLOTS = {SHOVEL_SLOT, PICKAXE_SLOT, AXE_SLOT, HOE_SLOT};

    private final JavaPlugin plugin;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final ShovelCoinItem shovelCoinItem;
    private final NamespacedKey placeholderKey;

    public CoinSlotsListener(JavaPlugin plugin, DirtyfyUpgradeManager dirtyfyUpgradeManager,
                              ShovelCoinItem shovelCoinItem) {
        this.plugin = plugin;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.shovelCoinItem = shovelCoinItem;
        this.placeholderKey = new NamespacedKey(plugin, "coin_placeholder");
    }

    /** S'assure que les 4 slots contiennent le bon item (vrai Shovel Coin ou placeholder grisé). */
    public void ensurePresent(Player player) {
        PlayerInventory inv = player.getInventory();
        boolean grassificationBought = dirtyfyUpgradeManager.getState(player.getUniqueId()).grassificationBought;

        if (grassificationBought) {
            if (!shovelCoinItem.matches(inv.getItem(SHOVEL_SLOT))) {
                inv.setItem(SHOVEL_SLOT, shovelCoinItem.build());
            }
        } else if (!isPlaceholder(inv.getItem(SHOVEL_SLOT))) {
            inv.setItem(SHOVEL_SLOT, buildPlaceholder("gevent_coin_shovel_grayed", "Shovel Coin"));
        }

        if (!isPlaceholder(inv.getItem(PICKAXE_SLOT)) && !shovelCoinItem.matches(inv.getItem(PICKAXE_SLOT))) {
            inv.setItem(PICKAXE_SLOT, buildPlaceholder("gevent_coin_pickaxe_grayed", "Pickaxe Coin"));
        }
        if (!isPlaceholder(inv.getItem(AXE_SLOT)) && !shovelCoinItem.matches(inv.getItem(AXE_SLOT))) {
            inv.setItem(AXE_SLOT, buildPlaceholder("gevent_coin_axe_grayed", "Axe Coin"));
        }
        if (!isPlaceholder(inv.getItem(HOE_SLOT)) && !shovelCoinItem.matches(inv.getItem(HOE_SLOT))) {
            inv.setItem(HOE_SLOT, buildPlaceholder("gevent_coin_hoe_grayed", "Hoe Coin"));
        }
    }

    private ItemStack buildPlaceholder(String modelTag, String displayName) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(displayName, NamedTextColor.DARK_GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Amélioration finale à venir.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(placeholderKey, PersistentDataType.BYTE, (byte) 1);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(modelTag));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isPlaceholder(ItemStack item) {
        if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(placeholderKey, PersistentDataType.BYTE);
    }

    private boolean isProtected(ItemStack item) {
        return shovelCoinItem.matches(item) || isPlaceholder(item);
    }

    private boolean isProtectedSlot(int slot) {
        for (int s : PROTECTED_SLOTS) {
            if (s == slot) return true;
        }
        return false;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        boolean touchesItem = isProtected(event.getCurrentItem()) || isProtected(event.getCursor());
        boolean isProtectedRawSlot = event.getClickedInventory() instanceof PlayerInventory
                && isProtectedSlot(event.getSlot());

        if (touchesItem || isProtectedRawSlot) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        for (ItemStack stack : event.getNewItems().values()) {
            if (isProtected(stack)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (isProtected(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(this::isProtected);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        ensurePresent(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> ensurePresent(player));
    }
}
