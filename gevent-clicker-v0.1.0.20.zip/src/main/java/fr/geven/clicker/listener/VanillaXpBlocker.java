package fr.geven.clicker.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerExpChangeEvent;

/**
 * Empêche tout gain (ou perte) d'expérience vanille : monstres tués, minage,
 * fours, pêche, élevage, etc. Toute l'XP du serveur passe désormais uniquement
 * par le plugin Gevent_Clicker.
 */
public class VanillaXpBlocker implements Listener {

    @EventHandler(ignoreCancelled = false)
    public void onVanillaExpChange(PlayerExpChangeEvent event) {
        // Cet évènement n'est pas "Cancellable" : on neutralise le gain en mettant le montant à 0.
        event.setAmount(0);
    }
}
