package fr.geven.clicker.listener;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.ClickerHolder;
import fr.geven.clicker.gui.GuiOpener;
import fr.geven.clicker.gui.LauncherItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gère le bloc de terre "raccourci" placé au slot 4 (milieu) de la hotbar de chaque joueur :
 *  - toujours présent (donné à la connexion / au respawn)
 *  - impossible à déplacer, drop, ou perdre à la mort
 *  - un clic dessus (en main dans le monde, ou dans un inventaire) ouvre le clicker
 */
public class LauncherItemListener implements Listener {

    /** Slot du milieu de la hotbar (0-8 = hotbar, donc 4 = centre). */
    private static final int HOTBAR_SLOT = 4;

    private static final long MIN_INTERVAL_NANOS = 300_000_000L; // 300 ms
    private final Map<UUID, Long> lastOpenNanos = new ConcurrentHashMap<>();

    private final JavaPlugin plugin;
    private final LauncherItem launcherItem;
    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final UpgradeManager upgradeManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public LauncherItemListener(JavaPlugin plugin, LauncherItem launcherItem, PlayerDataManager dataManager,
                                 XpManager xpManager, UpgradeManager upgradeManager,
                                 DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.plugin = plugin;
        this.launcherItem = launcherItem;
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    /** S'assure que le joueur a bien le raccourci dans sa hotbar (à appeler à la connexion). */
    public void ensurePresent(Player player) {
        ItemStack current = player.getInventory().getItem(HOTBAR_SLOT);
        if (!launcherItem.matches(current)) {
            player.getInventory().setItem(HOTBAR_SLOT, launcherItem.build());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        ensurePresent(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> ensurePresent(player));
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(launcherItem::matches);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (launcherItem.matches(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        boolean touchesLauncher = launcherItem.matches(current) || launcherItem.matches(cursor);

        boolean isHotbarSlot = event.getClickedInventory() instanceof PlayerInventory
                && event.getSlot() == HOTBAR_SLOT;

        if (touchesLauncher || isHotbarSlot) {
            event.setCancelled(true);
        }

        if (!launcherItem.matches(current)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getView().getTopInventory().getHolder() instanceof ClickerHolder) {
            return;
        }

        tryOpen(player);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        for (ItemStack item : event.getNewItems().values()) {
            if (launcherItem.matches(item)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (!launcherItem.matches(event.getItem())) {
            return;
        }

        Action action = event.getAction();
        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK
                || action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            tryOpen(event.getPlayer());
        }
    }

    private void tryOpen(Player player) {
        long now = System.nanoTime();
        Long last = lastOpenNanos.put(player.getUniqueId(), now);
        if (last != null && (now - last) < MIN_INTERVAL_NANOS) {
            return;
        }
        GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
    }
}
