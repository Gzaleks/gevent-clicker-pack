package fr.geven.clicker.listener;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.gui.AutomaterSettingsGui;
import fr.geven.clicker.gui.AutomaterSettingsHolder;
import fr.geven.clicker.gui.AutomaterSettingsLauncherItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gère l'item "Automater Settings" placé au 9ème slot (index 8, dernier de la hotbar) :
 *  - n'apparaît qu'une fois l'Experience Autobuyer acheté (voir ensurePresent, appelé à la
 *    connexion ET immédiatement après l'achat)
 *  - une fois présent : impossible à déplacer, drop, ou perdre à la mort
 *  - un clic dessus (en main dans le monde, ou dans un inventaire) ouvre Automater Settings
 */
public class AutomaterSettingsLauncherItemListener implements Listener {

    /** Dernier slot de la hotbar (0-8 = hotbar, donc 8 = 9ème/dernier). */
    private static final int HOTBAR_SLOT = 8;

    private static final long MIN_INTERVAL_NANOS = 300_000_000L; // 300 ms
    private final Map<UUID, Long> lastOpenNanos = new ConcurrentHashMap<>();

    private final JavaPlugin plugin;
    private final AutomaterSettingsLauncherItem item;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public AutomaterSettingsLauncherItemListener(JavaPlugin plugin, AutomaterSettingsLauncherItem item,
                                                  DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.plugin = plugin;
        this.item = item;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    /** S'assure que le joueur a bien le raccourci dans sa hotbar, SI l'Experience Autobuyer est acheté. */
    public void ensurePresent(Player player) {
        if (!dirtyfyUpgradeManager.getState(player.getUniqueId()).experienceAutobuyerBought) {
            return;
        }
        ItemStack current = player.getInventory().getItem(HOTBAR_SLOT);
        if (!item.matches(current)) {
            player.getInventory().setItem(HOTBAR_SLOT, item.build());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        ensurePresent(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> ensurePresent(player));
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(item::matches);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (item.matches(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        boolean touchesItem = item.matches(current) || item.matches(cursor);

        boolean isHotbarSlot = event.getClickedInventory() instanceof PlayerInventory
                && event.getSlot() == HOTBAR_SLOT;

        if (touchesItem || isHotbarSlot) {
            event.setCancelled(true);
        }

        if (!item.matches(current)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getView().getTopInventory().getHolder() instanceof AutomaterSettingsHolder) {
            return;
        }

        tryOpen(player);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        for (ItemStack stack : event.getNewItems().values()) {
            if (item.matches(stack)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (!item.matches(event.getItem())) {
            return;
        }

        Action action = event.getAction();
        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK
                || action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            tryOpen(event.getPlayer());
        }
    }

    private void tryOpen(Player player) {
        long now = System.nanoTime();
        Long last = lastOpenNanos.put(player.getUniqueId(), now);
        if (last != null && (now - last) < MIN_INTERVAL_NANOS) {
            return;
        }
        AutomaterSettingsHolder holder = new AutomaterSettingsHolder();
        boolean enabled = dirtyfyUpgradeManager.getState(player.getUniqueId()).experienceAutobuyerEnabled;
        player.openInventory(AutomaterSettingsGui.create(holder, enabled));
    }
}
