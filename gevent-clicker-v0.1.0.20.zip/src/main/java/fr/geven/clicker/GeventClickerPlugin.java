package fr.geven.clicker;

import fr.geven.clicker.command.ClCommand;
import fr.geven.clicker.command.ClickerCommand;
import fr.geven.clicker.command.PackReloadCommand;
import fr.geven.clicker.command.SetRankCommand;
import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.data.GrassManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.AutomaterSettingsGuiListener;
import fr.geven.clicker.gui.AutomaterSettingsLauncherItem;
import fr.geven.clicker.gui.ClickerGuiListener;
import fr.geven.clicker.gui.DirtyfyUpgradeGuiListener;
import fr.geven.clicker.gui.LauncherItem;
import fr.geven.clicker.gui.ShovelCoinItem;
import fr.geven.clicker.gui.StrongUpgradeGuiListener;
import fr.geven.clicker.listener.AutomaterSettingsLauncherItemListener;
import fr.geven.clicker.listener.CoinSlotsListener;
import fr.geven.clicker.listener.LauncherItemListener;
import fr.geven.clicker.listener.PlayerJoinListener;
import fr.geven.clicker.listener.VanillaXpBlocker;
import fr.geven.clicker.rank.RankJoinListener;
import fr.geven.clicker.rank.RankManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.task.AutoDirtingTask;
import fr.geven.clicker.task.ExperienceAutobuyerTask;
import fr.geven.clicker.task.XpForHomelessTask;
import fr.geven.clicker.xp.XpBarSync;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Plugin "Gevent_Clicker" — voir README.md pour le détail complet des fonctionnalités.
 */
public final class GeventClickerPlugin extends JavaPlugin {

    private PlayerDataManager dataManager;
    private GrassManager grassManager;
    private XpManager xpManager;
    private UpgradeManager upgradeManager;
    private DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private FricScoreboardManager scoreboardManager;
    private LauncherItem launcherItem;
    private LauncherItemListener launcherItemListener;
    private AutomaterSettingsLauncherItem automaterSettingsLauncherItem;
    private AutomaterSettingsLauncherItemListener automaterSettingsLauncherItemListener;
    private ShovelCoinItem shovelCoinItem;
    private CoinSlotsListener coinSlotsListener;
    private fr.geven.clicker.world.CoinDoorWorldManager coinDoorWorldManager;
    private fr.geven.clicker.world.CoinDoorListener coinDoorListener;
    private org.bukkit.scheduler.BukkitTask coinDoorTask;
    private org.bukkit.scheduler.BukkitTask structureIntegrityTask;
    private org.bukkit.scheduler.BukkitTask farmlandMoistureTask;
    private EcusManager ecusManager;
    private fr.geven.clicker.world.WheatFarmManager wheatFarmManager;
    private fr.geven.clicker.world.PotatoFarmManager potatoFarmManager;
    private fr.geven.clicker.world.VoidComposterManager voidComposterManager;
    private java.util.List<org.bukkit.scheduler.BukkitTask> wheatFarmTasks;
    private java.util.List<org.bukkit.scheduler.BukkitTask> potatoFarmTasks;
    private RankManager rankManager;
    private AutoDirtingTask autoDirtingTask;
    private ExperienceAutobuyerTask experienceAutobuyerTask;
    private XpForHomelessTask xpForHomelessTask;

    @Override
    public void onEnable() {
        // Chargement des données persistantes
        this.dataManager = new PlayerDataManager(this);
        this.dataManager.load();

        this.grassManager = new GrassManager(this);
        this.grassManager.load();

        this.xpManager = new XpManager(this);
        this.xpManager.load();

        this.upgradeManager = new UpgradeManager(this);
        this.upgradeManager.load();

        this.dirtyfyUpgradeManager = new DirtyfyUpgradeManager(this);
        this.dirtyfyUpgradeManager.load();

        this.rankManager = new RankManager(this);
        this.rankManager.load();

        this.ecusManager = new EcusManager(this);
        this.ecusManager.load();

        saveDefaultConfig();
        // Fusionne les nouvelles clés par défaut (ex: door.x/y/z/axis) dans un config.yml déjà
        // existant sur le serveur, sans écraser les valeurs déjà personnalisées par l'admin.
        getConfig().options().copyDefaults(true);
        // Migration one-shot : les anciennes clés npc.name="Marchand" / npc.y=2 (avant le
        // renommage en "Seed Seller" et le déplacement en y=1) restent bloquées sur un config.yml
        // déjà existant car copyDefaults() n'écrase jamais une clé déjà présente. On corrige donc
        // explicitement ce cas précis une seule fois, sans toucher à une valeur que l'admin aurait
        // personnalisée différemment.
        if ("Marchand".equals(getConfig().getString("npc.name"))) {
            getConfig().set("npc.name", "Seed Seller");
        }
        if (getConfig().getInt("npc.y", 1) == 2) {
            getConfig().set("npc.y", 1);
        }
        // Idem pour l'ancien nom du composter "NàC" -> "Void Composter".
        if ("NàC".equals(getConfig().getString("composter.name"))) {
            getConfig().set("composter.name", "Void Composter");
        }
        saveConfig();

        this.scoreboardManager = new FricScoreboardManager();
        this.launcherItem = new LauncherItem(this);
        this.launcherItemListener = new LauncherItemListener(this, launcherItem, dataManager, xpManager,
                upgradeManager, dirtyfyUpgradeManager);
        this.automaterSettingsLauncherItem = new AutomaterSettingsLauncherItem(this);
        this.automaterSettingsLauncherItemListener = new AutomaterSettingsLauncherItemListener(this,
                automaterSettingsLauncherItem, dirtyfyUpgradeManager);
        this.shovelCoinItem = new ShovelCoinItem(this);
        this.coinSlotsListener = new CoinSlotsListener(this, dirtyfyUpgradeManager, shovelCoinItem);
        fr.geven.clicker.gui.InfoItem infoItem = new fr.geven.clicker.gui.InfoItem(this);
        fr.geven.clicker.listener.InfoItemListener infoItemListener =
                new fr.geven.clicker.listener.InfoItemListener(this, infoItem, upgradeManager, dirtyfyUpgradeManager);

        this.coinDoorWorldManager = new fr.geven.clicker.world.CoinDoorWorldManager(this);
        this.coinDoorWorldManager.setup();
        this.coinDoorListener = new fr.geven.clicker.world.CoinDoorListener(this, coinDoorWorldManager, shovelCoinItem);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.SpawnWorldListener(coinDoorWorldManager), this);
        this.getServer().getPluginManager().registerEvents(new fr.geven.clicker.world.AdventureModeListener(), this);
        fr.geven.clicker.world.WorldStructuresManager structuresManager = new fr.geven.clicker.world.WorldStructuresManager(this);
        this.voidComposterManager = new fr.geven.clicker.world.VoidComposterManager(this);
        this.voidComposterManager.load();
        boolean farmExpanded = voidComposterManager.getTier() >= 2;
        structuresManager.applyAll(coinDoorWorldManager.getWorld(), farmExpanded);
        this.voidComposterManager.applyBlockLevel(coinDoorWorldManager.getWorld(),
                getConfig().getInt("composter.x", 10), getConfig().getInt("composter.y", 1),
                getConfig().getInt("composter.z", 10));
        this.structureIntegrityTask = new fr.geven.clicker.world.StructureIntegrityTask(this, structuresManager, coinDoorWorldManager, voidComposterManager).start();
        fr.geven.clicker.world.FarmPatchListener farmPatchListener =
                new fr.geven.clicker.world.FarmPatchListener(this, coinDoorWorldManager);
        this.getServer().getPluginManager().registerEvents(farmPatchListener, this);
        this.farmlandMoistureTask = farmPatchListener.start();
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.ProtectedStructuresListener(this), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.LecternInfoListener(this), this);

        // PNJ marchand + farm de blé (Ecus)
        this.wheatFarmManager = new fr.geven.clicker.world.WheatFarmManager(this);
        this.wheatFarmManager.setup(coinDoorWorldManager.getWorld());
        this.wheatFarmManager.setYieldMultiplier(farmExpanded ? 2 : 1);
        this.wheatFarmTasks = new fr.geven.clicker.world.WheatFarmTask(this, wheatFarmManager, coinDoorWorldManager).start();
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.WheatFarmListener(wheatFarmManager, dirtyfyUpgradeManager), this);

        // Farm de patates (débloquée à partir du Void Composter Tier 2) : 2e moitié du champ,
        // dupliquée juste après la bordure partagée avec la moitié blé.
        this.potatoFarmManager = new fr.geven.clicker.world.PotatoFarmManager(this);
        int farmX0 = getConfig().getInt("farm_patch.x", 30);
        int farmY = getConfig().getInt("farm_patch.y", 1);
        int farmZ0 = getConfig().getInt("farm_patch.z", 30);
        this.potatoFarmManager.setup(coinDoorWorldManager.getWorld(), farmX0, farmY,
                fr.geven.clicker.world.WorldStructuresManager.secondPatchZ(farmZ0));
        this.potatoFarmTasks = new fr.geven.clicker.world.PotatoFarmTask(this, potatoFarmManager, coinDoorWorldManager).start();
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.PotatoFarmListener(this, potatoFarmManager, dirtyfyUpgradeManager), this);

        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.ShopNpcListener(structuresManager, wheatFarmManager, potatoFarmManager,
                        voidComposterManager, dirtyfyUpgradeManager),
                this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.BarrelInteractListener(this, wheatFarmManager, potatoFarmManager,
                        voidComposterManager, dirtyfyUpgradeManager), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.gui.ShopGuiListener(ecusManager, wheatFarmManager, potatoFarmManager,
                        voidComposterManager, scoreboardManager), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.gui.SellGuiListener(ecusManager, wheatFarmManager, potatoFarmManager,
                        voidComposterManager, scoreboardManager), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.gui.FarmerInventoryGuiListener(), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.world.VoidComposterInteractListener(this, ecusManager, wheatFarmManager,
                        potatoFarmManager, voidComposterManager, dirtyfyUpgradeManager), this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.gui.VoidComposterGuiListener(this, voidComposterManager, wheatFarmManager,
                        potatoFarmManager, structuresManager, ecusManager, coinDoorWorldManager), this);

        fr.geven.clicker.command.WorldChangeCommand worldChangeCommand = new fr.geven.clicker.command.WorldChangeCommand();
        this.getCommand("wc").setExecutor(worldChangeCommand);
        this.getCommand("wc").setTabCompleter(worldChangeCommand);
        this.getCommand("spawn").setExecutor(new fr.geven.clicker.command.SpawnCommand(this, coinDoorWorldManager));
        this.getCommand("fi").setExecutor(new fr.geven.clicker.command.FarmerInventoryCommand(wheatFarmManager,
                potatoFarmManager, voidComposterManager, dirtyfyUpgradeManager));

        // Commandes
        this.getCommand("clicker").setExecutor(
                new ClickerCommand(dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager));
        ClCommand clCommand = new ClCommand(this, dataManager, xpManager, upgradeManager, grassManager,
                dirtyfyUpgradeManager, scoreboardManager, coinSlotsListener, structuresManager, coinDoorWorldManager,
                ecusManager, wheatFarmManager, potatoFarmManager, voidComposterManager);
        this.getCommand("cl").setExecutor(clCommand);
        this.getCommand("cl").setTabCompleter(clCommand);
        SetRankCommand setRankCommand = new SetRankCommand(rankManager);
        this.getCommand("setrank").setExecutor(setRankCommand);
        this.getCommand("setrank").setTabCompleter(setRankCommand);
        this.getCommand("packreload").setExecutor(new PackReloadCommand(this));

        // Écouteurs
        this.getServer().getPluginManager().registerEvents(
                new ClickerGuiListener(dataManager, xpManager, upgradeManager, grassManager, dirtyfyUpgradeManager,
                        scoreboardManager), this);
        this.getServer().getPluginManager().registerEvents(
                new StrongUpgradeGuiListener(dataManager, upgradeManager, scoreboardManager, xpManager,
                        dirtyfyUpgradeManager), this);
        this.getServer().getPluginManager().registerEvents(
                new DirtyfyUpgradeGuiListener(grassManager, dirtyfyUpgradeManager, scoreboardManager,
                        automaterSettingsLauncherItemListener, coinSlotsListener,
                        dataManager, xpManager, upgradeManager), this);
        this.getServer().getPluginManager().registerEvents(
                new AutomaterSettingsGuiListener(dirtyfyUpgradeManager), this);
        this.getServer().getPluginManager().registerEvents(automaterSettingsLauncherItemListener, this);
        this.getServer().getPluginManager().registerEvents(coinSlotsListener, this);
        this.getServer().getPluginManager().registerEvents(infoItemListener, this);
        this.getServer().getPluginManager().registerEvents(
                new fr.geven.clicker.gui.InfoGuiListener(upgradeManager, dirtyfyUpgradeManager), this);
        this.getServer().getPluginManager().registerEvents(coinDoorListener, this);
        this.coinDoorTask = coinDoorListener.startTicking();
        this.getServer().getPluginManager().registerEvents(
                new PlayerJoinListener(dataManager, xpManager, grassManager, ecusManager, scoreboardManager), this);
        this.getServer().getPluginManager().registerEvents(new VanillaXpBlocker(), this);
        this.getServer().getPluginManager().registerEvents(launcherItemListener, this);
        this.getServer().getPluginManager().registerEvents(new RankJoinListener(rankManager), this);

        // Cas d'un /reload : les joueurs déjà connectés n'ont pas de PlayerJoinEvent
        for (Player online : this.getServer().getOnlinePlayers()) {
            double fric = dataManager.getFric(online.getUniqueId());
            long xp = xpManager.getXp(online.getUniqueId());
            double grass = grassManager.getGrass(online.getUniqueId());
            long ecus = ecusManager.getEcus(online.getUniqueId());
            scoreboardManager.setup(online, fric, xp, grass, ecus);
            XpBarSync.sync(online, xp);
            launcherItemListener.ensurePresent(online);
            automaterSettingsLauncherItemListener.ensurePresent(online);
            coinSlotsListener.ensurePresent(online);
            infoItemListener.ensurePresent(online);
            rankManager.applyListName(online);
        }

        // Tâche Auto Dirting : ajoute le Dirt passif toutes les 20 ticks (1 seconde)
        this.autoDirtingTask = new AutoDirtingTask(dataManager, upgradeManager, xpManager, dirtyfyUpgradeManager,
                scoreboardManager);
        this.autoDirtingTask.runTaskTimer(this, 20L, 20L);

        // Tâche Experience Autobuyer : tente un achat automatique toutes les 40 ticks (2 secondes)
        this.experienceAutobuyerTask = new ExperienceAutobuyerTask(dataManager, xpManager, upgradeManager,
                dirtyfyUpgradeManager, scoreboardManager);
        this.experienceAutobuyerTask.runTaskTimer(this, 40L, 40L);

        // Tâche XP for homeless : ajoute l'xp passive toutes les 20 ticks (1 seconde)
        this.xpForHomelessTask = new XpForHomelessTask(xpManager, dirtyfyUpgradeManager);
        this.xpForHomelessTask.runTaskTimer(this, 20L, 20L);

        getLogger().info("Gevent_Clicker activé !");
    }

    @Override
    public void onDisable() {
        if (autoDirtingTask != null) {
            autoDirtingTask.cancel();
        }
        if (experienceAutobuyerTask != null) {
            experienceAutobuyerTask.cancel();
        }
        if (xpForHomelessTask != null) {
            xpForHomelessTask.cancel();
        }
        if (coinDoorTask != null) {
            coinDoorTask.cancel();
        }
        if (structureIntegrityTask != null) {
            structureIntegrityTask.cancel();
        }
        if (farmlandMoistureTask != null) {
            farmlandMoistureTask.cancel();
        }
        if (wheatFarmTasks != null) {
            wheatFarmTasks.forEach(org.bukkit.scheduler.BukkitTask::cancel);
        }
        if (potatoFarmTasks != null) {
            potatoFarmTasks.forEach(org.bukkit.scheduler.BukkitTask::cancel);
        }
        if (ecusManager != null) {
            ecusManager.saveSync();
        }
        if (wheatFarmManager != null) {
            wheatFarmManager.saveSync();
        }
        if (potatoFarmManager != null) {
            potatoFarmManager.saveSync();
        }
        if (voidComposterManager != null) {
            voidComposterManager.saveSync();
        }
        if (dataManager != null) {
            dataManager.saveSync();
        }
        if (xpManager != null) {
            xpManager.saveSync();
        }
        if (upgradeManager != null) {
            upgradeManager.saveSync();
        }
        if (dirtyfyUpgradeManager != null) {
            dirtyfyUpgradeManager.saveSync();
        }
        if (rankManager != null) {
            rankManager.saveSync();
        }
        if (grassManager != null) {
            grassManager.saveSync();
        }

        HandlerList.unregisterAll(this);

        getLogger().info("Gevent_Clicker désactivé, données sauvegardées.");
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    public XpManager getXpManager() {
        return xpManager;
    }

    public UpgradeManager getUpgradeManager() {
        return upgradeManager;
    }

    public DirtyfyUpgradeManager getDirtyfyUpgradeManager() {
        return dirtyfyUpgradeManager;
    }

    public FricScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public GrassManager getGrassManager() {
        return grassManager;
    }
}
