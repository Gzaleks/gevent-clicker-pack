package fr.geven.clicker.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Holder de l'écran de choix de quantité (vente de blé au "Farm Buyer"). */
public class SellQuantityHolder implements InventoryHolder {

    private Inventory inventory;

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
