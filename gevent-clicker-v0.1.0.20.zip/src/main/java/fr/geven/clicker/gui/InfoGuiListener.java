package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.UpgradeManager;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Gère la pagination de l'interface "Informations" ; tout le reste (bloc de phase, features)
 *  n'est pas cliquable/déplaçable. */
public class InfoGuiListener implements Listener {

    private final UpgradeManager upgradeManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public InfoGuiListener(UpgradeManager upgradeManager, DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.upgradeManager = upgradeManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof InfoHolder holder)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof InfoHolder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        int page = holder.getPage();
        if (slot == InfoGui.PREV_SLOT && page > 0) {
            holder.setPage(page - 1);
            InfoGui.render(event.getClickedInventory(), upgradeManager, dirtyfyUpgradeManager, player.getUniqueId(), page - 1);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        } else if (slot == InfoGui.NEXT_SLOT && page < InfoGui.PAGE_COUNT - 1) {
            holder.setPage(page + 1);
            InfoGui.render(event.getClickedInventory(), upgradeManager, dirtyfyUpgradeManager, player.getUniqueId(), page + 1);
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof InfoHolder) {
            event.setCancelled(true);
        }
    }
}
