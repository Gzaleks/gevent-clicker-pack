package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import org.bukkit.entity.Player;

import java.util.UUID;

public final class GuiOpener {

    private GuiOpener() {
    }

    public static void open(Player player, PlayerDataManager dataManager, XpManager xpManager,
                             UpgradeManager upgradeManager, DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        UUID uuid = player.getUniqueId();
        double fric = dataManager.getFric(uuid);
        long xp = xpManager.getXp(uuid);
        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        DirtyfyUpgradeManager.State dirtyfyUpgrades = dirtyfyUpgradeManager.getState(uuid);

        ClickerHolder holder = new ClickerHolder();
        player.openInventory(ClickerGui.create(holder, fric, xp,
                shovelUnlocked, upgradeManager.getShovelTier(uuid), upgradeManager.getPurchases(uuid),
                bottleUnlocked, upgradeManager.getBottlePurchases(uuid),
                upgradeManager.isStrongUpgradeUnlocked(uuid), upgradeManager.getStrongUpgrades(uuid),
                upgradeManager.getDirtyfyCount(uuid),
                dirtyfyUpgrades.baseDirtBoosterLevel, dirtyfyUpgrades.mardiGrassLevel,
                dirtyfyUpgrades.fenetreXpBought, dirtyfyUpgrades.chagrassLevel));
    }
}
