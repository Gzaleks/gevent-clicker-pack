package fr.geven.clicker.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Holder vide utilisé pour identifier de façon fiable l'inventaire du shop du PNJ marchand. */
public class ShopHolder implements InventoryHolder {

    private Inventory inventory;

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
