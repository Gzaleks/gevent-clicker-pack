package fr.geven.clicker.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Identifie l'inventaire "Automater Settings". */
public class AutomaterSettingsHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    @NotNull
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
