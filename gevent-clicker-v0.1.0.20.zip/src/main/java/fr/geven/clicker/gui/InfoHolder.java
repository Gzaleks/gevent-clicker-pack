package fr.geven.clicker.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Marqueur pour l'inventaire de l'interface "Informations". */
public class InfoHolder implements InventoryHolder {

    private Inventory inventory;
    private int page = 0;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    @Override
    @NotNull
    public Inventory getInventory() {
        return inventory;
    }
}
