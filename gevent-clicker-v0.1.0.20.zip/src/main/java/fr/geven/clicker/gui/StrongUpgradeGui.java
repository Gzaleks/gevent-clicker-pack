package fr.geven.clicker.gui;

import fr.geven.clicker.upgrade.StrongUpgrades;
import fr.geven.clicker.util.NumberFormatting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.key.Key;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.ArrayList;
import java.util.List;

/**
 * Interface "Strong Upgrade", ouverte en cliquant sur l'item du même nom dans le clicker
 * principal. Même technique de fond custom que le clicker (police bitmap sur le titre), mais
 * en vert (entre clair et foncé) au lieu du bleu clair — mêmes liserés gris.
 *
 * Contient 4 améliorations à achat unique, permanentes, réinitialisées par /cl reset :
 *  - Fric x2 : double le gain de Fric par clic
 *  - XP x2 : double l'xp gagnée par clic
 *  - Better Shovel : +0.1$/clic à tous les achats d'amélioration de la pelle (rétroactif)
 *  - Better Experience : +0.1xp/clic à tous les achats d'amélioration de la fiole (rétroactif)
 */
public class StrongUpgradeGui {

    public static final int SIZE = 54;

    public static final int FRIC_X2_SLOT = 11;
    public static final int XP_X2_SLOT = 15;
    public static final int BETTER_SHOVEL_SLOT = 20;
    public static final int BETTER_EXPERIENCE_SLOT = 24;
    public static final int FRIC_X2_5_SLOT = 29;
    public static final int XP_X2_5_SLOT = 33;
    public static final int AUTO_DIRTING_SLOT = 38;
    public static final int AUTO_DIRTING_MORE_INFO_SLOT = 40;
    public static final int MORE_AUTO_DIRT_SLOT = 42;
    public static final int BACK_SLOT = 45; // ligne 6 (dernière), colonne 1 -> tout en bas à gauche

    private static final Component TIER4_CONDITION =
            Component.text("pelle tier 4", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);
    private static final Component AUTO_DIRTING_BOUGHT_CONDITION =
            Component.text("acheter Auto Dirting", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);

    /** Même technique que ClickerGui.TITLE, mais sur la police "strongbg" (panneau vert). */
    public static final Component TITLE = Component.text("\uE010\uE011")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "strongbg"));

    private StrongUpgradeGui() {
    }

    public static Inventory create(StrongUpgradeHolder holder, StrongUpgrades strongUpgrades, int shovelTierNumber) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);

        inventory.setItem(FRIC_X2_SLOT, buildFricX2Item(strongUpgrades.fricX2()));
        inventory.setItem(XP_X2_SLOT, buildXpX2Item(strongUpgrades.xpX2()));
        inventory.setItem(BETTER_SHOVEL_SLOT, buildBetterShovelItem(strongUpgrades.betterShovel()));
        inventory.setItem(BETTER_EXPERIENCE_SLOT, buildBetterExperienceItem(strongUpgrades.betterExperience()));

        boolean tier4 = shovelTierNumber >= 4;
        inventory.setItem(FRIC_X2_5_SLOT, tier4
                ? buildFricX2_5Item(strongUpgrades.fricX2_5())
                : buildLockedItem("Dirt x2,5", TIER4_CONDITION));
        inventory.setItem(XP_X2_5_SLOT, tier4
                ? buildXpX2_5Item(strongUpgrades.xpX2_5())
                : buildLockedItem("XP x2,5", TIER4_CONDITION));
        inventory.setItem(AUTO_DIRTING_SLOT, tier4
                ? buildAutoDirtingPurchaseItem(strongUpgrades.autoDirting())
                : buildLockedItem("Auto Dirting", TIER4_CONDITION));

        boolean autoDirtingBought = strongUpgrades.autoDirting();
        inventory.setItem(AUTO_DIRTING_MORE_INFO_SLOT, autoDirtingBought
                ? buildAutoDirtingMoreInfoItem(strongUpgrades.autoDirtingMoreInfo())
                : buildLockedItem("Auto Dirting More Infos", AUTO_DIRTING_BOUGHT_CONDITION));
        inventory.setItem(MORE_AUTO_DIRT_SLOT, autoDirtingBought
                ? buildMoreAutoDirtItem(strongUpgrades.moreAutoDirt())
                : buildLockedItem("More Auto Dirt", AUTO_DIRTING_BOUGHT_CONDITION));

        inventory.setItem(BACK_SLOT, buildBackItem());

        return inventory;
    }

    /** Item générique "verrouillé" (bedrock) pour une amélioration pas encore débloquée. */
    public static ItemStack buildLockedItem(String upgradeName, Component unlockCondition) {
        ItemStack item = new ItemStack(Material.BEDROCK);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(upgradeName, NamedTextColor.DARK_GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Non débloqué", NamedTextColor.RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Conditions de déblocage : ", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)
                .append(unlockCondition));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildBackItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Retour", NamedTextColor.WHITE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour revenir au Clicker", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_back_arrow"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildFricX2Item(boolean bought) {
        return buildItem("gevent_fric_x2", "Dirt x2", NumberFormatting.DIRT_COLOR,
                List.of("Double le gain de Dirt par clic", "sur le bloc de terre."),
                StrongUpgrades.FRIC_X2_PRICE, bought);
    }

    public static ItemStack buildXpX2Item(boolean bought) {
        return buildItem("gevent_xp_x2", "XP x2", NamedTextColor.AQUA,
                List.of("Double l'xp gagnée par clic", "sur le bloc de terre."),
                StrongUpgrades.XP_X2_PRICE, bought);
    }

    public static ItemStack buildBetterShovelItem(boolean bought) {
        return buildItem("gevent_better_shovel", "Better Shovel", NamedTextColor.GOLD,
                List.of("+" + NumberFormatting.money(StrongUpgrades.BETTER_SHOVEL_BONUS)
                        + "/clic à TOUS les achats", "de la pelle (rétroactif)."),
                StrongUpgrades.BETTER_SHOVEL_PRICE, bought);
    }

    public static ItemStack buildBetterExperienceItem(boolean bought) {
        return buildItem("gevent_better_experience", "Better Experience", NamedTextColor.LIGHT_PURPLE,
                List.of("+0.1 xp/clic à TOUS les achats", "de la fiole (rétroactif)."),
                StrongUpgrades.BETTER_EXPERIENCE_PRICE, bought);
    }

    public static ItemStack buildFricX2_5Item(boolean bought) {
        return buildItem("gevent_fric_x2_5", "Dirt x2,5", NumberFormatting.DIRT_COLOR,
                List.of("Multiplie le gain de Dirt par clic", "par 2,5 (cumulable avec Dirt x2)."),
                StrongUpgrades.FRIC_X2_5_PRICE, bought);
    }

    public static ItemStack buildXpX2_5Item(boolean bought) {
        return buildItem("gevent_xp_x2_5", "XP x2,5", NamedTextColor.AQUA,
                List.of("Multiplie l'xp gagnée par clic", "par 2,5 (cumulable avec XP x2)."),
                StrongUpgrades.XP_X2_5_PRICE, bought);
    }

    public static ItemStack buildAutoDirtingPurchaseItem(boolean bought) {
        return buildItem("gevent_auto_dirting", "Auto Dirting", NamedTextColor.GOLD,
                List.of("Simule des clics automatiques sur", "le bloc de terre, en plus des tiens.",
                        "Génère " + NumberFormatting.money(StrongUpgrades.AUTO_DIRTING_BASE_RATE) + "/sec à l'achat."),
                StrongUpgrades.AUTO_DIRTING_PRICE, bought);
    }

    public static ItemStack buildAutoDirtingMoreInfoItem(boolean bought) {
        return buildItem("gevent_auto_dirting_more_info", "Auto Dirting More Infos", NamedTextColor.AQUA,
                List.of("Affiche plus de détails sur l'Auto", "Dirting dans l'interface Clicker",
                        "(Dirt/min)."),
                StrongUpgrades.AUTO_DIRTING_MORE_INFO_PRICE, bought);
    }

    public static ItemStack buildMoreAutoDirtItem(boolean bought) {
        return buildItem("gevent_more_auto_dirt", "More Auto Dirt", NamedTextColor.GOLD,
                List.of("Double la production de l'Auto", "Dirting (Dirt/sec)."),
                StrongUpgrades.MORE_AUTO_DIRT_PRICE, bought);
    }

    private static ItemStack buildItem(String modelTag, String name, net.kyori.adventure.text.format.TextColor color,
                                        List<String> description, long price, boolean bought) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color, TextDecoration.BOLD).decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        for (String line : description) {
            lore.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        }
        if (bought) {
            lore.add(Component.text("Acheté", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Non acheté", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Prix : " + NumberFormatting.money(price), NumberFormatting.DIRT_COLOR)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(modelTag));
        meta.setCustomModelDataComponent(cmd);

        if (bought) {
            // Effet "enchanté" (lueur), sans afficher d'enchantement réel dans le tooltip
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        item.setItemMeta(meta);
        return item;
    }
}
