package fr.geven.clicker.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Le raccourci placé dans la hotbar du joueur, qui ouvre le clicker.
 *
 * Item de base : minecraft:paper (item "neutre" sans comportement vanille gênant,
 * contrairement à un bloc plaçable). Son apparence par défaut est du papier classique ;
 * avec le resource pack "Gevent Clicker Pack" installé, il prend l'apparence d'un
 * pointeur de souris (grâce au tag custom_model_data "gevent_pointer").
 *
 * Il est identifié de façon fiable via une clé PersistentDataContainer, indépendamment
 * de son apparence, pour ne jamais être confondu avec un vrai papier du joueur.
 */
public class LauncherItem {

    private static final String MODEL_TAG = "gevent_pointer";

    private final NamespacedKey key;

    public LauncherItem(JavaPlugin plugin) {
        this.key = new NamespacedKey(plugin, "clicker_launcher");
    }

    /** Construit un nouvel exemplaire de l'item raccourci. */
    public ItemStack build() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Gevent Clicker", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Clique pour ouvrir le clicker !", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);

        // Tag pour le resource pack : sélectionne la texture "pointeur de souris"
        // (voir assets/minecraft/items/paper.json dans Gevent Clicker Pack)
        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(MODEL_TAG));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        return item;
    }

    /** Indique si un ItemStack donné est bien ce raccourci (et pas un simple papier). */
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }
}
