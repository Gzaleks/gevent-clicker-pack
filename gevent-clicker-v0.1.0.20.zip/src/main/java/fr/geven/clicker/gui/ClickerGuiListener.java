package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.GrassManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.DirtyfyUpgradePricing;
import fr.geven.clicker.upgrade.ShovelTier;
import fr.geven.clicker.util.NumberFormatting;
import fr.geven.clicker.xp.LevelCurve;
import fr.geven.clicker.xp.XpBarSync;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gère les clics dans l'interface Gevent Clicker, y compris toute la logique de
 * déblocage progressif :
 *  - le bloc de terre est toujours actif
 *  - la pelle démarre verrouillée (bedrock), débloquée dès que le joueur possède 1$
 *  - une fois la pelle au tier 1 maximum (20/20), un item d'amélioration (gabarit netherite)
 *    apparaît sous la pelle ; le cliquer fait passer la pelle au tier 2 (gratuit, instantané)
 *  - la fiole d'xp n'apparaît (verrouillée, bedrock) qu'une fois la pelle débloquée, et ne
 *    devient achetable qu'une fois la pelle au tier 2
 */
public class ClickerGuiListener implements Listener {

    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final UpgradeManager upgradeManager;
    private final GrassManager grassManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final FricScoreboardManager scoreboardManager;

    // Anti double-comptage / anti-spam : intervalle minimum entre deux clics pris en compte,
    // par joueur ET par slot (pour ne pas bloquer un clic sur un autre item juste après).
    private static final long MIN_INTERVAL_NANOS = 40_000_000L; // 40 ms
    private final Map<String, Long> lastClickNanos = new ConcurrentHashMap<>();

    /** Grass gagné par Dirtyfy effectué (avant multiplicateur de Mardi Grass). */
    private static final double GRASS_PER_DIRTYFY = 10.0;

    public ClickerGuiListener(PlayerDataManager dataManager, XpManager xpManager, UpgradeManager upgradeManager,
                               GrassManager grassManager, DirtyfyUpgradeManager dirtyfyUpgradeManager,
                               FricScoreboardManager scoreboardManager) {
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
        this.grassManager = grassManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.scoreboardManager = scoreboardManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof ClickerHolder)) {
            return;
        }

        // Empêche systématiquement de déplacer/prendre un item du GUI
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof ClickerHolder)) {
            return; // clic dans l'inventaire du joueur, pas dans le GUI
        }

        // FIX du bug de double-comptage : un clic rapide double envoie en plus du clic normal
        // un évènement de type DOUBLE_CLICK. On l'ignore pour ne pas compter un clic fantôme.
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            return;
        }

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        if (!debounceOk(player, slot)) {
            return;
        }

        Inventory inv = event.getClickedInventory();
        if (slot == ClickerGui.DIRT_SLOT) {
            handleDirtClick(player, inv);
        } else if (slot == ClickerGui.XP_BOTTLE_SLOT) {
            handleXpBottleClick(player, inv);
        } else if (slot == ClickerGui.SHOVEL_SLOT) {
            handleShovelClick(player, inv);
        } else if (slot == ClickerGui.SHOVEL_TIER_UP_SLOT) {
            handleShovelTierUpClick(player, inv);
        } else if (slot == ClickerGui.STRONG_UPGRADE_SLOT) {
            handleStrongUpgradeClick(player);
        } else if (slot == ClickerGui.DIRTYFY_UPGRADES_SLOT) {
            handleDirtyfyUpgradesClick(player);
        } else if (isDirtyfySlot(slot)) {
            handleDirtyfyClick(player);
        }
    }

    private boolean isDirtyfySlot(int slot) {
        for (int s : ClickerGui.DIRTYFY_SLOTS) {
            if (s == slot) return true;
        }
        return false;
    }

    private boolean debounceOk(Player player, int slot) {
        String key = player.getUniqueId() + ":" + slot;
        long now = System.nanoTime();
        Long last = lastClickNanos.put(key, now);
        return last == null || (now - last) >= MIN_INTERVAL_NANOS;
    }

    private void handleDirtClick(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        int xpLevel = xpManager.getLevel(uuid);
        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);
        int baseDirtBoosterLevel = dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel;
        boolean fenetreXpBought = dirtyfyUpgradeManager.getState(uuid).fenetreXpBought;

        double gain = ClickerGui.effectiveClickGain(xpLevel, shovelUnlocked, tier, purchases, strongUpgrades,
                baseDirtBoosterLevel, fenetreXpBought);
        double newFric = dataManager.addFric(uuid, gain);
        dataManager.saveAsync();
        scoreboardManager.updateFric(player, newFric);

        // Déblocage de la pelle : dès que le joueur possède au moins 1$, une fois pour toutes
        boolean justUnlockedShovel = false;
        if (!shovelUnlocked && newFric >= ClickerGui.SHOVEL_UNLOCK_FRIC) {
            upgradeManager.unlockShovel(uuid);
            justUnlockedShovel = true;
        }

        // Une fois la fiole débloquée, chaque clic sur le bloc de terre rapporte aussi de l'xp
        long newXp = xpManager.getXp(uuid);
        int newXpLevel = xpLevel;
        if (bottleUnlocked) {
            long xpGain = Math.round(fr.geven.clicker.upgrade.BottleUpgrade.xpPerClick(bottlePurchases, strongUpgrades));
            newXp = xpManager.addXp(uuid, xpGain);
            newXpLevel = LevelCurve.levelForXp(newXp);
            xpManager.saveAsync();
            scoreboardManager.updateXp(player, newXp);
            XpBarSync.sync(player, newXp);
        }
        if (justUnlockedShovel || bottleUnlocked) {
            upgradeManager.saveAsync();
        }

        boolean shovelNowUnlocked = shovelUnlocked || justUnlockedShovel;
        inv.setItem(ClickerGui.DIRT_SLOT,
                ClickerGui.buildDirtItem(newFric, newXpLevel, shovelNowUnlocked, tier, purchases,
                        bottleUnlocked, bottlePurchases, strongUpgrades, baseDirtBoosterLevel, fenetreXpBought));
        if (bottleUnlocked) {
            inv.setItem(ClickerGui.XP_BOTTLE_SLOT, ClickerGui.buildXpBottleItem(newXp, bottlePurchases, strongUpgrades));
        }

        if (justUnlockedShovel) {
            inv.setItem(ClickerGui.SHOVEL_SLOT, ClickerGui.buildShovelItem(tier, purchases));
            // La fiole doit apparaître en bedrock (verrouillée) dès l'instant où la pelle se
            // débloque — c'était le bug : ce slot n'était jamais touché ici.
            if (!bottleUnlocked) {
                inv.setItem(ClickerGui.XP_BOTTLE_SLOT,
                        ClickerGui.buildLockedItem("Amélioration : Expérience", ClickerGui.TIER2_UNLOCK_CONDITION));
            }
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.6f);
            player.sendActionBar(Component.text("Pelle débloquée !", NamedTextColor.LIGHT_PURPLE));
        } else {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.4f);
        }
    }

    /** Achat d'une amélioration de la fiole : augmente l'xp gagnée par clic, ne donne pas de niveau directement. */
    private void handleXpBottleClick(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        if (!upgradeManager.isBottleUnlocked(uuid)) {
            deny(player, "Fiole verrouillée — améliore la pelle jusqu'au tier 2 !");
            return;
        }

        int xpLevel = xpManager.getLevel(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        if (bottlePurchases >= fr.geven.clicker.upgrade.BottleUpgrade.MAX_PURCHASES) {
            deny(player, "Amélioration de la fiole déjà au maximum !");
            return;
        }

        long price = fr.geven.clicker.upgrade.BottleUpgrade.priceForNextPurchase(bottlePurchases);
        double currentFric = dataManager.getFric(uuid);
        if (currentFric < price) {
            deny(player, "Pas assez de Dirt ! (" + price + "ɗ requis)");
            return;
        }

        double newFric = dataManager.addFric(uuid, -price);
        int newBottlePurchases = upgradeManager.addBottlePurchase(uuid);
        dataManager.saveAsync();
        upgradeManager.saveAsync();

        scoreboardManager.updateFric(player, newFric);

        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        long xp = xpManager.getXp(uuid);
        fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);

        inv.setItem(ClickerGui.XP_BOTTLE_SLOT, ClickerGui.buildXpBottleItem(xp, newBottlePurchases, strongUpgrades));
        inv.setItem(ClickerGui.DIRT_SLOT,
                ClickerGui.buildDirtItem(newFric, xpLevel, shovelUnlocked, tier, purchases, true, newBottlePurchases,
                        strongUpgrades, dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel,
                        dirtyfyUpgradeManager.getState(uuid).fenetreXpBought));

        // Premier achat de fiole : le Strong Upgrade apparaît maintenant (bedrock si pas encore
        // débloqué via la pelle tier 3, ou directement débloqué si le tier 3 est déjà atteint)
        if (newBottlePurchases == 1) {
            boolean strongUpgradeUnlocked = upgradeManager.isStrongUpgradeUnlocked(uuid);
            if (strongUpgradeUnlocked) {
                inv.setItem(ClickerGui.STRONG_UPGRADE_SLOT, ClickerGui.buildStrongUpgradeItem());
            } else {
                inv.setItem(ClickerGui.STRONG_UPGRADE_SLOT,
                        ClickerGui.buildLockedItem("Strong Upgrades", ClickerGui.TIER3_UNLOCK_CONDITION));
            }
        }

        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        player.sendActionBar(Component.text("Amélioration Expérience achetée ! (" + newBottlePurchases + " au total)",
                NamedTextColor.AQUA));
    }

    private void handleShovelClick(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        if (!upgradeManager.isShovelUnlocked(uuid)) {
            deny(player, "Verrouillé — possède " + NumberFormatting.money(ClickerGui.SHOVEL_UNLOCK_FRIC) + " pour débloquer !");
            return;
        }

        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);

        long price = tier.priceForNextPurchase(purchases);
        if (price < 0) {
            deny(player, "Pelle Tier " + tier.tier + " déjà au maximum !");
            return;
        }

        double currentFric = dataManager.getFric(uuid);
        if (currentFric < price) {
            deny(player, "Pas assez de Dirt ! (" + price + "ɗ requis)");
            return;
        }

        double newFric = dataManager.addFric(uuid, -price);
        int newPurchases = upgradeManager.addPurchase(uuid);
        dataManager.saveAsync();
        upgradeManager.saveAsync();

        scoreboardManager.updateFric(player, newFric);

        int xpLevel = xpManager.getLevel(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);
        inv.setItem(ClickerGui.SHOVEL_SLOT, ClickerGui.buildShovelItem(tier, newPurchases));
        inv.setItem(ClickerGui.DIRT_SLOT,
                ClickerGui.buildDirtItem(newFric, xpLevel, true, tier, newPurchases, bottleUnlocked, bottlePurchases,
                        strongUpgrades, dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel,
                        dirtyfyUpgradeManager.getState(uuid).fenetreXpBought));

        // Le tier actuel vient d'atteindre son maximum : fait apparaître le bouton d'amélioration
        if (tier.next() != null && newPurchases >= tier.maxPurchases) {
            inv.setItem(ClickerGui.SHOVEL_TIER_UP_SLOT, ClickerGui.buildShovelTierUpItem(tier));
        }
        // La pelle tier 5 vient d'atteindre son maximum : le fond change (trou noir peint dedans)
        // -> le titre/fond d'un inventaire Bukkit ne peut pas changer après sa création, donc on
        // ferme et rouvre l'interface fraîche plutôt que de patcher les slots un par un
        if (tier == ShovelTier.TIER_5 && newPurchases >= ShovelTier.TIER_5.maxPurchases) {
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
            player.sendActionBar(Component.text("Dirtyfy débloqué !", NamedTextColor.DARK_PURPLE));
            GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
            return;
        }

        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        player.sendActionBar(Component.text("Pelle Tier " + tier.tier + " : " + newPurchases + " / "
                + tier.maxPurchases, NamedTextColor.LIGHT_PURPLE));
    }

    /** Passage d'un tier au suivant (gratuit, instantané) : gère tier 1->2 (débloque la fiole)
     *  et tier 2->3 (débloque le Strong Upgrade), de façon générique. */
    private void handleShovelTierUpClick(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        ShovelTier currentTier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        ShovelTier nextTier = currentTier.next();

        // Sécurité : le bouton ne doit être cliquable que si le tier actuel est bien maxé
        if (nextTier == null || purchases < currentTier.maxPurchases) {
            return;
        }

        upgradeManager.upgradeTier(uuid);
        if (nextTier == ShovelTier.TIER_2) {
            upgradeManager.unlockBottle(uuid);
        } else if (nextTier == ShovelTier.TIER_3) {
            upgradeManager.unlockStrongUpgrade(uuid);
        }
        upgradeManager.saveAsync();

        ShovelTier newTier = upgradeManager.getShovelTier(uuid);
        int newPurchases = upgradeManager.getPurchases(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        boolean strongUpgradeUnlocked = upgradeManager.isStrongUpgradeUnlocked(uuid);

        double fric = dataManager.getFric(uuid);
        int xpLevel = xpManager.getLevel(uuid);
        long xp = xpManager.getXp(uuid);
        fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);

        inv.setItem(ClickerGui.SHOVEL_SLOT, ClickerGui.buildShovelItem(newTier, newPurchases));
        inv.setItem(ClickerGui.SHOVEL_TIER_UP_SLOT, null); // consommé, disparaît
        inv.setItem(ClickerGui.DIRT_SLOT, ClickerGui.buildDirtItem(fric, xpLevel, true, newTier, newPurchases,
                bottleUnlocked, bottlePurchases, strongUpgrades, dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel,
                dirtyfyUpgradeManager.getState(uuid).fenetreXpBought));

        if (nextTier == ShovelTier.TIER_2) {
            // La fiole se débloque en même temps que le tier 2 : elle apparaît désormais achetable
            inv.setItem(ClickerGui.XP_BOTTLE_SLOT, ClickerGui.buildXpBottleItem(xp, 0, strongUpgrades));
        }
        if (nextTier == ShovelTier.TIER_3 && bottlePurchases >= 1) {
            // Le Strong Upgrade se débloque en même temps que le tier 3, mais ne devient visible
            // que si le premier achat de fiole a déjà été fait (sinon il reste tout simplement
            // absent, comme avant — il apparaîtra directement débloqué au premier achat de fiole)
            inv.setItem(ClickerGui.STRONG_UPGRADE_SLOT, ClickerGui.buildStrongUpgradeItem());
        }
        if (nextTier == ShovelTier.TIER_4) {
            // "Auto Dirting" apparaît en bedrock dès le tier 4 (débloqué séparément via un
            // achat dans Strong Upgrade, pas automatiquement)
            inv.setItem(ClickerGui.AUTO_DIRTING_SLOT,
                    ClickerGui.buildLockedItem("Auto Dirting", ClickerGui.AUTO_DIRTING_UNLOCK_CONDITION));
        }
        if (nextTier == ShovelTier.TIER_5) {
            // Le Dirtyfy apparaît en UN SEUL bedrock (au centre) dès le tier 5, il ne passe au
            // bloc complet de 9 tuiles qu'une fois ce tier maxé (géré dans handleShovelClick)
            inv.setItem(ClickerGui.DIRTYFY_SLOTS[4],
                    ClickerGui.buildLockedItem("Dirtyfy", ClickerGui.DIRTYFY_UNLOCK_CONDITION));
        }

        player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.7f, 1.3f);
        player.sendActionBar(Component.text("Pelle améliorée au tier " + newTier.tier + " !",
                NamedTextColor.LIGHT_PURPLE));
    }

    /** Clic sur l'item "Strong Upgrades" : ouvre sa propre interface (vide pour l'instant). */
    private void handleStrongUpgradeClick(Player player) {
        UUID uuid = player.getUniqueId();
        if (!upgradeManager.isStrongUpgradeUnlocked(uuid)) {
            deny(player, "Verrouillé — passe la pelle au tier 3 pour débloquer !");
            return;
        }

        StrongUpgradeHolder holder = new StrongUpgradeHolder();
        player.openInventory(StrongUpgradeGui.create(holder, upgradeManager.getStrongUpgrades(uuid),
                upgradeManager.getShovelTier(uuid).tier));
        player.playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.6f, 1.3f);
    }

    /**
     * Clic sur n'importe laquelle des 9 tuiles du bloc Dirtyfy : effectue le Dirtyfy
     * (irréversible). Remet TOUT à zéro (Dirt, xp, pelle, toutes les améliorations) sauf le
     * compteur de Dirtyfy lui-même (incrémenté), débloque définitivement "Dirtyfy Upgrades",
     * puis rouvre l'interface fraîche (plus simple et plus sûr que de corriger chaque slot
     * individuellement vu l'ampleur du changement d'état).
     */
    private void handleDirtyfyClick(Player player) {
        UUID uuid = player.getUniqueId();
        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        if (tier != ShovelTier.TIER_5 || purchases < ShovelTier.TIER_5.maxPurchases) {
            return; // sécurité : ne devrait pas être cliquable avant d'être débloqué
        }

        dataManager.resetFric(uuid);
        xpManager.resetXp(uuid);
        upgradeManager.performDirtyfy(uuid);
        int mardiGrassLevel = dirtyfyUpgradeManager.getState(uuid).mardiGrassLevel;
        int chagrassLevel = dirtyfyUpgradeManager.getState(uuid).chagrassLevel;
        int grassBaseBoosterLevel = dirtyfyUpgradeManager.getState(uuid).grassBaseBoosterLevel;
        double grassBase = GRASS_PER_DIRTYFY
                + grassBaseBoosterLevel * DirtyfyUpgradePricing.GRASS_BOOSTER_BONUS_PER_LEVEL;
        double grassReward = grassBase * DirtyfyUpgradePricing.mardiGrassMultiplier(mardiGrassLevel)
                * DirtyfyUpgradePricing.chagrassMultiplier(chagrassLevel);
        double newGrass = grassManager.addGrass(uuid, grassReward);
        dataManager.saveAsync();
        xpManager.saveAsync();
        upgradeManager.saveAsync();
        grassManager.saveAsync();

        scoreboardManager.updateFric(player, 0.0);
        scoreboardManager.updateXp(player, 0L);
        scoreboardManager.updateGrass(player, newGrass);
        XpBarSync.sync(player, 0L);

        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.7f, 1.2f);
        player.sendActionBar(Component.text("Dirtyfy effectué ! +" + NumberFormatting.frenchLong(Math.round(grassReward))
                + " Grass. Tout est remis à zéro — \"Dirtyfy Upgrades\" est débloqué.", NamedTextColor.DARK_PURPLE));

        // Réouvre l'interface fraîche (tout l'état a changé d'un coup)
        GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
    }

    /** Clic sur "Dirtyfy Upgrades" : ouvre sa propre interface (Base Dirt Booster, Mardi Grass, Experience Autobuyer). */
    private void handleDirtyfyUpgradesClick(Player player) {
        UUID uuid = player.getUniqueId();
        if (upgradeManager.getDirtyfyCount(uuid) < 1) {
            deny(player, "Verrouillé — effectue un Dirtyfy pour débloquer !");
            return;
        }

        DirtyfyUpgradeHolder holder = new DirtyfyUpgradeHolder();
        player.openInventory(DirtyfyUpgradeGui.create(holder, dirtyfyUpgradeManager.getState(uuid)));
        player.playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.6f, 1.3f);
    }

    private void deny(Player player, String message) {
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
        player.sendActionBar(Component.text(message, NamedTextColor.RED));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof ClickerHolder) {
            event.setCancelled(true);
        }
    }
}
