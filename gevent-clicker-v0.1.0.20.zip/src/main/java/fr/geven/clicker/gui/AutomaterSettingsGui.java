package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.key.Key;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.List;

/**
 * Interface "Automater Settings" (fond gris moyen), regroupe toutes les automatisations
 * provenant d'améliorations. Pour l'instant, uniquement l'Experience Autobuyer (débloqué en
 * l'achetant dans Dirtyfy Upgrades). Un clic active/désactive l'automatisation.
 */
public class AutomaterSettingsGui {

    public static final int SIZE = 54;
    public static final int EXPERIENCE_AUTOBUYER_SLOT = 22;

    public static final Component TITLE = Component.text("\uE010\uE011")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "automaterbg"));

    private AutomaterSettingsGui() {
    }

    public static Inventory create(AutomaterSettingsHolder holder, boolean enabled) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(EXPERIENCE_AUTOBUYER_SLOT, buildToggleItem(enabled));
        return inventory;
    }

    public static ItemStack buildToggleItem(boolean enabled) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Experience Autobuyer", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(List.of(
                Component.text("Achète automatiquement la fiole d'xp", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("dès que tu as assez de Dirt.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                enabled
                        ? Component.text("Activé", NamedTextColor.GREEN, TextDecoration.BOLD)
                                .decoration(TextDecoration.ITALIC, false)
                        : Component.text("Désactivé", NamedTextColor.RED, TextDecoration.BOLD)
                                .decoration(TextDecoration.ITALIC, false),
                Component.text("Clique pour " + (enabled ? "désactiver" : "activer"), NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_experience_autobuyer"));
        meta.setCustomModelDataComponent(cmd);

        if (enabled) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }
}
