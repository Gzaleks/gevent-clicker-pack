package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.UpgradeManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Interface "Informations" : ouverte via le "?" de la hotbar. Une page par "phase" du jeu :
 * page 1 = Dirt (pelle en netherite), page 2 = Houe (houe en netherite), chaque page montre le
 * bloc/outil de la phase en haut, et les features débloquées de cette phase à partir de la 3e
 * ligne, toujours dans le même ordre. Pagination par flèches en bas (masquées si la page n'existe
 * pas).
 */
public final class InfoGui {

    public static final int SIZE = 54;
    public static final int PHASE_SLOT = 4;
    public static final int[] FEATURE_SLOTS = {20, 21, 22, 23, 24};
    public static final int PREV_SLOT = 48;
    public static final int NEXT_SLOT = 50;
    public static final int PAGE_COUNT = 2;

    /** Largeur (en caractères) au-delà de laquelle une ligne de description est coupée. */
    private static final int WRAP_WIDTH = 38;

    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "infobg"));

    /** Vert clair pour le titre de la phase Houe (page 2), distinct du DIRT_COLOR de la page 1. */
    private static final TextColor HOE_TITLE_COLOR = TextColor.color(0x90EE90);

    private InfoGui() {
    }

    public static Inventory create(InfoHolder holder, UpgradeManager upgradeManager,
                                    DirtyfyUpgradeManager dirtyfyUpgradeManager, UUID uuid, int page) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        render(inventory, upgradeManager, dirtyfyUpgradeManager, uuid, page);
        return inventory;
    }

    public static void render(Inventory inventory, UpgradeManager upgradeManager,
                               DirtyfyUpgradeManager dirtyfyUpgradeManager, UUID uuid, int page) {
        for (int slot = 0; slot < SIZE; slot++) {
            inventory.setItem(slot, null);
        }

        if (page == 0) {
            renderDirtPage(inventory, upgradeManager, uuid);
        } else if (page == 1) {
            renderHoePage(inventory, dirtyfyUpgradeManager, uuid);
        }

        if (page > 0) {
            inventory.setItem(PREV_SLOT, buildArrowItem(false));
        }
        if (page < PAGE_COUNT - 1) {
            inventory.setItem(NEXT_SLOT, buildArrowItem(true));
        }
    }

    private static void renderDirtPage(Inventory inventory, UpgradeManager upgradeManager, UUID uuid) {
        inventory.setItem(PHASE_SLOT, buildPhaseItem("Dirt", Material.NETHERITE_SHOVEL,
                fr.geven.clicker.util.NumberFormatting.DIRT_COLOR));

        UpgradeManager.ShovelState state = upgradeManager.getState(uuid);
        boolean shovelUnlocked = state.infoDiscoveredShovel;
        boolean bottleUnlocked = state.infoDiscoveredBottle;
        boolean strongUpgradeUnlocked = state.infoDiscoveredStrongUpgrade;
        boolean autoDirtingUnlocked = state.infoDiscoveredAutoDirting;
        boolean dirtyfyUpgradesUnlocked = state.infoDiscoveredDirtyfyUpgrades;

        if (shovelUnlocked) {
            inventory.setItem(FEATURE_SLOTS[0], buildFeatureItem(Material.DIAMOND_SHOVEL, "Pelle",
                    NamedTextColor.LIGHT_PURPLE, "Améliore la pelle pour avoir + de Dirt par clic", null));
        }
        if (bottleUnlocked) {
            inventory.setItem(FEATURE_SLOTS[1], buildFeatureItem(Material.EXPERIENCE_BOTTLE, "Amélioration : Expérience",
                    NamedTextColor.AQUA,
                    "Chaque clic te rapportera de l'xp, ce qui te donnera + de Dirt par clic en fonction de ton niveau",
                    null));
        }
        if (strongUpgradeUnlocked) {
            inventory.setItem(FEATURE_SLOTS[2], buildFeatureItem(Material.PAPER, "Strong Upgrades",
                    NamedTextColor.GOLD, "Rends-toi plus puissant avec ces améliorations", "gevent_strong_upgrade"));
        }
        if (autoDirtingUnlocked) {
            inventory.setItem(FEATURE_SLOTS[3], buildFeatureItem(Material.HOPPER, "Auto Dirting",
                    NamedTextColor.GOLD,
                    "Génère de la Dirt automatiquement sans que t'ai besoin de faire quoi que ce soit... Gros flemmard",
                    null));
        }
        if (dirtyfyUpgradesUnlocked) {
            inventory.setItem(FEATURE_SLOTS[4], buildFeatureItem(Material.PAPER, "Dirtyfy Upgrades",
                    NamedTextColor.DARK_PURPLE, "Rends-toi ENCORE plus puissant avec ces améliorations :)",
                    "gevent_dirtyfy_upgrades_icon"));
        }
    }

    private static void renderHoePage(Inventory inventory, DirtyfyUpgradeManager dirtyfyUpgradeManager, UUID uuid) {
        inventory.setItem(PHASE_SLOT, buildPhaseItem("Houe", Material.NETHERITE_HOE, HOE_TITLE_COLOR));

        boolean grassificationDone = dirtyfyUpgradeManager.getState(uuid).grassificationBought;
        if (!grassificationDone) {
            return;
        }

        inventory.setItem(FEATURE_SLOTS[0], buildFeatureItemMultiLore(Material.PAPER, "Marchands",
                NamedTextColor.GREEN, "gevent_seed_seller_icon", List.of(
                        line(NamedTextColor.GRAY, "Seed Seller", NamedTextColor.WHITE,
                                ": Te vend des graines pour faire pousser tes plantations."),
                        line(NamedTextColor.GRAY, "Farm Buyer", NamedTextColor.WHITE,
                                ": T'achète tes récoltes contre des ", NamedTextColor.GOLD, "Ecus")));

        // Tonneau et Composter : icône vanilla telle quelle, pas de texture custom (demande explicite).
        inventory.setItem(FEATURE_SLOTS[1], buildFeatureItemMultiLore(Material.BARREL, "Farmer's Inventory",
                NamedTextColor.GOLD, null, wrapWithHighlight(
                        "Farmer's Inventory : Inventaire de tes plantations, fais la commande %s pour l'ouvrir directement",
                        "/fi", NamedTextColor.AQUA)));

        inventory.setItem(FEATURE_SLOTS[2], buildFeatureItemMultiLore(Material.COMPOSTER, "Void Composter",
                NamedTextColor.LIGHT_PURPLE, null, wrapPlain(
                        "Void Composter : Le passer au Tier suivant te débloquera des améliorations indispensables "
                                + "pour avancer")));
    }

    private static ItemStack buildPhaseItem(String phaseName, Material material, TextColor color) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(phaseName, color, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildFeatureItem(Material material, String name, NamedTextColor color, String info,
                                               String modelTag) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(wrapPlain(info));

        if (modelTag != null) {
            CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
            cmd.setStrings(List.of(modelTag));
            meta.setCustomModelDataComponent(cmd);
        }

        item.setItemMeta(meta);
        return item;
    }

    /** Variante pour un lore déjà construit ligne par ligne (texte multi-couleur ou multi-paragraphe). */
    private static ItemStack buildFeatureItemMultiLore(Material material, String name, NamedTextColor color,
                                                         String modelTag, List<Component> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        if (modelTag != null) {
            CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
            cmd.setStrings(List.of(modelTag));
            meta.setCustomModelDataComponent(cmd);
        }

        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildArrowItem(boolean next) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(next ? "Page suivante" : "Page précédente", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(next ? "gevent_info_arrow_right" : "gevent_info_arrow_left"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    // ----- Helpers texte -----

    /** Découpe un texte gris uni en plusieurs lignes de lore si besoin (mot par mot, sans couper un mot). */
    private static List<Component> wrapPlain(String text) {
        List<Component> lines = new ArrayList<>();
        for (String rawLine : wrapToStrings(text)) {
            lines.add(Component.text(rawLine, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        }
        return lines;
    }

    /** Comme wrapPlain, mais avec un "%s" remplacé par un segment mis en évidence dans une autre couleur. */
    private static List<Component> wrapWithHighlight(String template, String highlight, NamedTextColor highlightColor) {
        String full = template.replace("%s", highlight);
        List<Component> lines = new ArrayList<>();
        for (String rawLine : wrapToStrings(full)) {
            int idx = rawLine.indexOf(highlight);
            if (idx < 0) {
                lines.add(Component.text(rawLine, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            } else {
                Component comp = Component.text(rawLine.substring(0, idx), NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(highlight, highlightColor).decoration(TextDecoration.ITALIC, false))
                        .append(Component.text(rawLine.substring(idx + highlight.length()), NamedTextColor.GRAY)
                                .decoration(TextDecoration.ITALIC, false));
                lines.add(comp);
            }
        }
        return lines;
    }

    /** Construit une ligne "label : reste", avec le label et un segment optionnel mis en évidence.
     *  Seul le TITRE de l'item (displayName) est en gras ; le lore (y compris ces labels) ne l'est jamais. */
    private static Component line(NamedTextColor labelColor, String label, NamedTextColor restColor, String rest) {
        return Component.text(label, labelColor).decoration(TextDecoration.ITALIC, false)
                .decoration(TextDecoration.BOLD, false)
                .append(Component.text(rest, restColor).decoration(TextDecoration.ITALIC, false)
                        .decoration(TextDecoration.BOLD, false));
    }

    private static Component line(NamedTextColor labelColor, String label, NamedTextColor restColor, String rest,
                                   NamedTextColor highlightColor, String highlight) {
        return Component.text(label, labelColor).decoration(TextDecoration.ITALIC, false)
                .decoration(TextDecoration.BOLD, false)
                .append(Component.text(rest, restColor).decoration(TextDecoration.ITALIC, false)
                        .decoration(TextDecoration.BOLD, false))
                .append(Component.text(highlight, highlightColor).decoration(TextDecoration.ITALIC, false)
                        .decoration(TextDecoration.BOLD, false));
    }

    /** Découpage mot par mot en lignes d'au plus WRAP_WIDTH caractères. */
    private static List<String> wrapToStrings(String text) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : text.split(" ")) {
            if (current.length() > 0 && current.length() + 1 + word.length() > WRAP_WIDTH) {
                lines.add(current.toString());
                current = new StringBuilder();
            }
            if (current.length() > 0) {
                current.append(' ');
            }
            current.append(word);
        }
        if (current.length() > 0) {
            lines.add(current.toString());
        }
        return lines.isEmpty() ? List.of(text) : lines;
    }
}
