package fr.geven.clicker.gui;

import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.List;

/** Écran de choix de quantité avant de vendre du blé au "Farm Buyer". */
public final class SellQuantityGui {

    /** Fond custom (panneau vert clair avec "Farm Buyer" peint dedans), même technique que ClickerGui. */
    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "sellbg"));

    public static final int SIZE = 54;
    public static final int INFO_SLOT = 13;
    public static final int BUTTON_1_SLOT = 29;
    public static final int BUTTON_10_SLOT = 31;
    public static final int BUTTON_100_SLOT = 33;
    public static final int SELL_SLOT = 40;
    public static final int BACK_SLOT = 45;

    private SellQuantityGui() {
    }

    public static Inventory create(SellQuantityHolder holder, WheatFarmManager farmManager, long selected) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(INFO_SLOT, buildInfoItem(farmManager, selected));
        inventory.setItem(BUTTON_1_SLOT, buildDigitButton("gevent_digit_1", 1));
        inventory.setItem(BUTTON_10_SLOT, buildDigitButton("gevent_digit_10", 10));
        inventory.setItem(BUTTON_100_SLOT, buildDigitButton("gevent_digit_100", 100));
        inventory.setItem(SELL_SLOT, buildSellButton());
        inventory.setItem(BACK_SLOT, buildBackButton());
        return inventory;
    }

    public static ItemStack buildInfoItem(WheatFarmManager farmManager, long selected) {
        long capped = Math.min(selected, farmManager.getWheatCount());
        long price = farmManager.getSellPricePerUnit();

        ItemStack item = new ItemStack(Material.WHEAT, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Blé", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Sélectionné : " + capped + " blé", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Tu recevras : " + (capped * price) + " Ecus", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildDigitButton(String modelTag, int amount) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Sélectionner " + amount, NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour présélectionner " + amount + " blé", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(modelTag));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildSellButton() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Vendre", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour vendre la quantité sélectionnée", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_coin_pouch"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack buildBackButton() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Retour", NamedTextColor.GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_back_arrow"));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
        return item;
    }
}
