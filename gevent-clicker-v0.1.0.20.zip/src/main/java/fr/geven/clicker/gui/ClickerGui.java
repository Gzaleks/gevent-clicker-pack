package fr.geven.clicker.gui;

import fr.geven.clicker.util.NumberFormatting;
import fr.geven.clicker.upgrade.ShovelTier;
import fr.geven.clicker.xp.FricBonus;
import fr.geven.clicker.xp.LevelCurve;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Construit et met à jour l'interface graphique du clicker.
 * 6 lignes (54 slots) :
 *  - bloc de terre "Fric" cliquable (slot 22), toujours disponible dès le départ
 *  - pelle "Clicker Upgrader" (slot 20) : verrouillée (bedrock) tant que le joueur n'a pas 1$,
 *    puis pelle en bois (tier 1), puis pelle en pierre (tier 2) une fois améliorée
 *  - bouton d'amélioration de tier (slot 29, sous la pelle) : visible seulement quand le
 *    tier 1 est au niveau maximum
 *  - fiole d'xp (slot 4) : absente tant que la pelle n'est pas débloquée, puis verrouillée
 *    (bedrock) tant que la pelle n'est pas au tier 2, puis achetable normalement
 */
public final class ClickerGui {

    /** Titre/fond "normal" (Dirtyfy pas encore débloqué, ou pas encore atteint). */
    public static final Component TITLE = Component.text("\uE010\uE011")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "clickerbg"));

    /**
     * Titre/fond avec le trou noir du Dirtyfy peint DIRECTEMENT dans l'image de fond (donc à
     * l'endroit exact des 9 slots, sans AUCUNE démarcation possible entre eux — contrairement
     * à 9 textures d'item séparées, où Minecraft dessine toujours une grille de slots visible
     * par-dessus peu importe le contenu). Seule façon de vraiment lier les 9 cases.
     */
    public static final Component TITLE_DIRTYFY = Component.text("\uE010\uE012")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "clickerbg"));

    /** 6 lignes de 9 colonnes = 54 slots. */
    public static final int SIZE = 54;

    /** Bloc de terre : ligne 3 sur 6 (index 2), colonne 5 sur 9 (index 4) -> 2*9+4 = 22. */
    public static final int DIRT_SLOT = 22;

    /** Fiole d'expérience : tout en haut, au milieu -> ligne 1 (index 0), colonne 5 (index 4) = 4. */
    public static final int XP_BOTTLE_SLOT = 4;

    /** Pelle "Clicker Upgrader" : même ligne que le bloc de terre, 2 slots à sa gauche -> 22 - 2 = 20. */
    public static final int SHOVEL_SLOT = 20;

    /** Bouton d'amélioration de tier de la pelle : juste en dessous -> 20 + 9 = 29. */
    public static final int SHOVEL_TIER_UP_SLOT = 29;

    /** "Strong Upgrades" : même ligne que le bloc de terre, 2 slots à sa droite -> 22 + 2 = 24. */
    public static final int STRONG_UPGRADE_SLOT = 24;

    /** "Auto Dirting" : juste en dessous de "Strong Upgrades" -> 24 + 9 = 33. */
    public static final int AUTO_DIRTING_SLOT = 33;

    /** "Dirtyfy Upgrades" : juste au-dessus de "Strong Upgrades" -> 24 - 9 = 15. */
    public static final int DIRTYFY_UPGRADES_SLOT = 15;

    /** Les 9 slots du bloc Dirtyfy (3x3), centré 2 lignes sous le bloc de terre (slot 22+9+9=40). */
    public static final int[] DIRTYFY_SLOTS = {30, 31, 32, 39, 40, 41, 48, 49, 50};

    /** Item d'info (pas cliquable) juste à droite du bloc Dirtyfy, pour expliquer ce qu'il fait
     *  vu que les 9 slots eux-mêmes n'ont plus d'item (donc plus de tooltip) depuis qu'ils sont
     *  vides pour éviter la grille de surbrillance visible par-dessus le fond. */
    public static final int DIRTYFY_INFO_SLOT = 42;

    /** "Automater Settings" est désormais un item de hotbar, voir AutomaterSettingsLauncherItem. */

    /** Gain de base en Fric par clic, avant amélioration et bonus de niveau d'xp. */
    public static final double BASE_CLICK_GAIN = 0.1;

    /** Fric minimum à posséder pour débloquer la pelle. */
    public static final double SHOVEL_UNLOCK_FRIC = 1.0;

    /** Multiplicateur de difficulté du prix d'amélioration d'xp par rapport à la courbe d'xp elle-même. */

    private static final String FILLER_MODEL_TAG = "gevent_filler";

    /** Condition de déblocage textuelle de la fiole (pas un montant Fric, réutilisée par ClCommand). */
    public static final Component TIER2_UNLOCK_CONDITION =
            Component.text("pelle tier 2", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);

    /** Condition de déblocage textuelle du "Strong Upgrades" (réutilisée par ClCommand). */
    public static final Component TIER3_UNLOCK_CONDITION =
            Component.text("pelle tier 3", NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false);

    /** Condition de déblocage textuelle de l'"Auto Dirting" (réutilisée par ClCommand). */
    public static final Component AUTO_DIRTING_UNLOCK_CONDITION =
            Component.text("acheter Auto Dirting dans Strong Upgrades", NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false);

    /** Condition de déblocage textuelle du Dirtyfy (réutilisée par ClCommand). */
    public static final Component DIRTYFY_UNLOCK_CONDITION =
            Component.text("pelle tier 5 au niveau maximum", NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false);

    /** Condition de déblocage textuelle de "Dirtyfy Upgrades" (réutilisée par ClCommand). */
    public static final Component DIRTYFY_UPGRADES_UNLOCK_CONDITION =
            Component.text("effectuer un Dirtyfy", NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false);

    private ClickerGui() {
    }

    /** Crée un nouvel inventaire clicker avec tout l'état de progression du joueur reflété. */
    public static Inventory create(ClickerHolder holder, double currentFric, long currentXp,
                                    boolean shovelUnlocked, ShovelTier shovelTier, int shovelPurchases,
                                    boolean bottleUnlocked, int bottlePurchases,
                                    boolean strongUpgradeUnlocked, fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades,
                                    int dirtyfyCount, int baseDirtBoosterLevel, int mardiGrassLevel,
                                    boolean fenetreXpBought, int chagrassLevel) {
        boolean tier5MaxedForTitle = shovelTier == ShovelTier.TIER_5 && shovelPurchases >= ShovelTier.TIER_5.maxPurchases;
        Inventory inventory = Bukkit.createInventory(holder, SIZE, tier5MaxedForTitle ? TITLE_DIRTYFY : TITLE);
        holder.setInventory(inventory);
        int xpLevel = LevelCurve.levelForXp(currentXp);

        inventory.setItem(DIRT_SLOT, buildDirtItem(currentFric, xpLevel, shovelUnlocked, shovelTier, shovelPurchases,
                bottleUnlocked, bottlePurchases, strongUpgrades, baseDirtBoosterLevel, fenetreXpBought));

        // "Automater Settings" a été déplacé en item de hotbar (voir AutomaterSettingsLauncherItem)

        if (!shovelUnlocked) {
            inventory.setItem(SHOVEL_SLOT, buildLockedItem("Pelle", fricUnlockCondition(SHOVEL_UNLOCK_FRIC)));
        } else {
            inventory.setItem(SHOVEL_SLOT, buildShovelItem(shovelTier, shovelPurchases));
            if (shovelTier.next() != null && shovelPurchases >= shovelTier.maxPurchases) {
                inventory.setItem(SHOVEL_TIER_UP_SLOT, buildShovelTierUpItem(shovelTier));
            }
        }

        if (!shovelUnlocked) {
            // La fiole n'est même pas affichée tant que la pelle n'est pas débloquée
            inventory.setItem(XP_BOTTLE_SLOT, null);
        } else if (!bottleUnlocked) {
            inventory.setItem(XP_BOTTLE_SLOT, buildLockedItem("Amélioration : Expérience", TIER2_UNLOCK_CONDITION));
        } else {
            inventory.setItem(XP_BOTTLE_SLOT, buildXpBottleItem(currentXp, bottlePurchases, strongUpgrades));
        }

        if (bottlePurchases < 1) {
            // "Strong Upgrades" n'apparaît même pas tant que le premier achat de fiole n'est pas fait
            inventory.setItem(STRONG_UPGRADE_SLOT, null);
        } else if (!strongUpgradeUnlocked) {
            inventory.setItem(STRONG_UPGRADE_SLOT, buildLockedItem("Strong Upgrades", TIER3_UNLOCK_CONDITION));
        } else {
            inventory.setItem(STRONG_UPGRADE_SLOT, buildStrongUpgradeItem());
        }

        if (shovelTier.tier < 4) {
            // "Auto Dirting" n'apparaît même pas tant que la pelle n'est pas tier 4
            inventory.setItem(AUTO_DIRTING_SLOT, null);
        } else if (!strongUpgrades.autoDirting()) {
            inventory.setItem(AUTO_DIRTING_SLOT, buildLockedItem("Auto Dirting", AUTO_DIRTING_UNLOCK_CONDITION));
        } else {
            inventory.setItem(AUTO_DIRTING_SLOT, buildAutoDirtingItem(strongUpgrades, xpLevel, shovelUnlocked, shovelTier, shovelPurchases));
        }

        boolean tier5Maxed = shovelTier == ShovelTier.TIER_5 && shovelPurchases >= ShovelTier.TIER_5.maxPurchases;
        if (shovelTier.tier < 5) {
            // Le Dirtyfy n'apparaît même pas tant que la pelle n'est pas tier 5
            for (int slot : DIRTYFY_SLOTS) {
                inventory.setItem(slot, null);
            }
            inventory.setItem(DIRTYFY_INFO_SLOT, null);
        } else if (!tier5Maxed) {
            // Encore verrouillé : un seul bedrock au centre, pas les 9 tuiles
            for (int slot : DIRTYFY_SLOTS) {
                inventory.setItem(slot, null);
            }
            inventory.setItem(DIRTYFY_SLOTS[4], buildLockedItem("Dirtyfy", DIRTYFY_UNLOCK_CONDITION));
            inventory.setItem(DIRTYFY_INFO_SLOT, null);
        } else {
            // Débloqué : les 9 slots restent VIDES (pas d'item du tout, même invisible).
            // Le clic fonctionne quand même sur un slot vide (pas besoin d'item pour détecter
            // le clic) — c'est ce qui a réglé la grille de contour visible par-dessus le fond,
            // qui venait du fait que chaque slot contenait un item (même transparent).
            for (int slot : DIRTYFY_SLOTS) {
                inventory.setItem(slot, null);
            }
            inventory.setItem(DIRTYFY_INFO_SLOT, buildDirtyfyInfoItem(mardiGrassLevel, chagrassLevel));
        }

        if (dirtyfyCount >= 1) {
            // Une fois au moins un Dirtyfy effectué, reste visible en PERMANENCE, même si le
            // tier de la pelle vient de redescendre à 1 à cause du reset complet du Dirtyfy
            // (c'était le bug : la condition dépendait à tort du tier ACTUEL de la pelle)
            inventory.setItem(DIRTYFY_UPGRADES_SLOT, buildDirtyfyUpgradesItem());
        } else if (tier5Maxed) {
            inventory.setItem(DIRTYFY_UPGRADES_SLOT,
                    buildLockedItem("Dirtyfy Upgrades", DIRTYFY_UPGRADES_UNLOCK_CONDITION));
        } else {
            inventory.setItem(DIRTYFY_UPGRADES_SLOT, null);
        }

        return inventory;
    }

    public static ItemStack buildFillerItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(FILLER_MODEL_TAG));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
        return item;
    }

    /** Gain effectif en Fric par clic, amélioration (si débloquée) + bonus de niveau d'xp inclus. */
    public static double effectiveClickGain(int xpLevel, boolean shovelUnlocked, ShovelTier tier, int shovelPurchases,
                                             fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades,
                                             int baseDirtBoosterLevel, boolean fenetreXpBought) {
        double bonusPerPurchase = tier.bonusPerPurchase
                + (strongUpgrades.betterShovel() ? fr.geven.clicker.upgrade.StrongUpgrades.BETTER_SHOVEL_BONUS : 0.0);
        double shovelBonus = shovelUnlocked ? shovelPurchases * bonusPerPurchase : 0.0;
        double boosterBonus = baseDirtBoosterLevel
                * fr.geven.clicker.upgrade.DirtyfyUpgradePricing.BOOSTER_BONUS_PER_LEVEL;
        double base = BASE_CLICK_GAIN + boosterBonus + shovelBonus;
        double withLevelBonus = FricBonus.applyBonus(base, xpLevel);
        if (fenetreXpBought) {
            withLevelBonus *= fr.geven.clicker.upgrade.DirtyfyUpgradePricing.FENETRE_XP_MULTIPLIER;
        }
        return withLevelBonus * strongUpgrades.fricMultiplier();
    }

    /** Reconstruit l'item du bloc de terre avec le Fric à jour (lore live). */
    public static ItemStack buildDirtItem(double currentFric, int xpLevel,
                                           boolean shovelUnlocked, ShovelTier tier, int shovelPurchases,
                                           boolean bottleUnlocked, int bottlePurchases,
                                           fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades,
                                           int baseDirtBoosterLevel, boolean fenetreXpBought) {
        double clickGain = effectiveClickGain(xpLevel, shovelUnlocked, tier, shovelPurchases, strongUpgrades,
                baseDirtBoosterLevel, fenetreXpBought);

        ItemStack item = new ItemStack(Material.DIRT);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Clique pour gagner du Dirt !", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Chaque clic : +" + NumberFormatting.money(clickGain), NumberFormatting.DIRT_COLOR)
                .decoration(TextDecoration.ITALIC, false));
        if (bottleUnlocked) {
            long xpGain = Math.round(fr.geven.clicker.upgrade.BottleUpgrade.xpPerClick(bottlePurchases, strongUpgrades));
            lore.add(Component.text("Chaque clic : +" + xpGain + " xp", NamedTextColor.AQUA)
                    .decoration(TextDecoration.ITALIC, false));
        }
        if (xpLevel > 0) {
            String multiplierStr = String.format(Locale.US, "x%.1f", FricBonus.multiplierForLevel(xpLevel));
            lore.add(Component.text("Bonus Dirt (niveau " + xpLevel + ") : " + multiplierStr, NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.text("Dirt actuel : " + NumberFormatting.money(currentFric), NumberFormatting.DIRT_COLOR)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Item générique "verrouillé" (bedrock) pour un emplacement pas encore débloqué.
     * Tooltip : nom de l'amélioration verrouillée + condition de déblocage. La valeur Fric
     * de la condition (si présente) est passée déjà formatée "X$" en vert clair.
     */
    public static ItemStack buildLockedItem(String upgradeName, Component unlockCondition) {
        ItemStack item = new ItemStack(Material.BEDROCK);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(upgradeName, NamedTextColor.DARK_GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Non débloqué", NamedTextColor.RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Conditions de déblocage : ", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)
                .append(unlockCondition));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    /** Condition de déblocage "posséder X.Yɗ" avec la valeur en marron, symbole en suffixe. */
    public static Component fricUnlockCondition(double amount) {
        return Component.text("posséder ", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)
                .append(Component.text(String.format(java.util.Locale.US, "%.1fɗ", amount), NumberFormatting.DIRT_COLOR)
                        .decoration(TextDecoration.ITALIC, false));
    }

    /**
     * Construit la fiole d'expérience : amélioration achetable qui augmente l'xp gagnée par
     * clic sur le bloc de terre. Tooltip centré uniquement sur l'amélioration elle-même
     * (son niveau = nombre d'achats, son effet, son prix) — le niveau d'xp du JOUEUR reste
     * l'affaire du scoreboard, pas de cette fiole.
     */
    public static ItemStack buildXpBottleItem(long totalXp, int bottlePurchases,
                                               fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades) {
        int playerLevel = LevelCurve.levelForXp(totalXp);

        ItemStack item = new ItemStack(Material.EXPERIENCE_BOTTLE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Amélioration : Expérience", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + bottlePurchases + " / " + fr.geven.clicker.upgrade.BottleUpgrade.MAX_PURCHASES,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));

        double xpPerClick = fr.geven.clicker.upgrade.BottleUpgrade.xpPerClick(bottlePurchases, strongUpgrades);
        double bonusRate = fr.geven.clicker.upgrade.BottleUpgrade.BONUS_XP_PER_PURCHASE
                + (strongUpgrades.betterExperience() ? fr.geven.clicker.upgrade.StrongUpgrades.BETTER_EXPERIENCE_BONUS : 0.0);
        double xpMult = strongUpgrades.xpMultiplier();
        lore.add(Component.text("Xp par clic : " + String.format(Locale.US, "%.1f", xpPerClick)
                        + " (1 de base + " + String.format(Locale.US, "%.1f", bottlePurchases * bonusRate) + " d'achats"
                        + (xpMult > 1.0 ? String.format(Locale.US, ", x%.1f", xpMult) : "") + ")",
                        NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));

        if (bottlePurchases >= fr.geven.clicker.upgrade.BottleUpgrade.MAX_PURCHASES) {
            lore.add(Component.text("Amélioration maximale atteinte !", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            long price = fr.geven.clicker.upgrade.BottleUpgrade.priceForNextPurchase(bottlePurchases);
            lore.add(Component.text("Prix prochaine amélioration : " + NumberFormatting.money(price), NumberFormatting.DIRT_COLOR)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Construit la pelle (bois = tier 1, pierre = tier 2) : +Fric/clic par achat.
     * Tooltip : titre avec le tier, achats actuels / max de ce tier, prix du prochain achat.
     */
    public static ItemStack buildShovelItem(ShovelTier tier, int purchases) {
        ItemStack item = new ItemStack(tier.material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Pelle Tier " + tier.tier, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Amélioration : " + purchases + " / " + tier.maxPurchases, NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Effet : +" + NumberFormatting.money(tier.bonusPerPurchase) + "/clic par achat",
                        NumberFormatting.DIRT_COLOR)
                .decoration(TextDecoration.ITALIC, false));

        long price = tier.priceForNextPurchase(purchases);
        if (price < 0) {
            lore.add(Component.text("Amélioration maximale atteinte !", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Prix prochaine amélioration : " + NumberFormatting.money(price), NumberFormatting.DIRT_COLOR)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        // Masque les infos vanille additionnelles (attaque/vitesse d'outil, etc.)
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Bouton d'amélioration tier 1 -> tier 2 de la pelle (gabarit de forge en netherite).
     * Visible uniquement quand le tier 1 est au niveau maximum. Gratuit : un simple clic
     * fait passer la pelle au tier 2 instantanément.
     */
    /**
     * Bouton d'amélioration de tier de la pelle (tête custom, ou lingot de netherite en repli).
     * Visible uniquement quand le tier actuel est au niveau maximum. Gratuit : un simple clic
     * fait passer la pelle au tier suivant instantanément.
     */
    public static ItemStack buildShovelTierUpItem(ShovelTier currentTier) {
        ShovelTier nextTier = currentTier.next();
        ItemStack item = new ItemStack(Material.PAPER);

        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Améliorer la pelle : Tier " + nextTier.tier,
                        NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Pelle tier " + currentTier.tier + " > tier " + nextTier.tier, NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Avantage : +"
                        + NumberFormatting.money(currentTier.bonusPerPurchase) + "/clic > +"
                        + NumberFormatting.money(nextTier.bonusPerPurchase) + "/clic",
                        NumberFormatting.DIRT_COLOR)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Clique pour améliorer (gratuit)", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_tier_upgrade_anvil"));
        meta.setCustomModelDataComponent(cmd);

        // Effet "enchanté" (lueur), sans afficher d'enchantement réel dans le tooltip
        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ADDITIONAL_TOOLTIP,
                ItemFlag.HIDE_ENCHANTS);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Construit l'item "Strong Upgrades" (papier avec texture custom via le resource pack :
     * flèche verte vers le haut, aura jaune). Ouvre une nouvelle interface au clic (vide pour
     * l'instant).
     */
    public static ItemStack buildStrongUpgradeItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Strong Upgrades", NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Clique pour ouvrir", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_strong_upgrade"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Construit l'item d'information "Auto Dirting" (purement informatif, pas de clic possible).
     * Tooltip minimal (Dirt/seconde) par défaut, enrichi (clics simulés/seconde, Dirt/minute)
     * une fois "Auto Dirting More Infos" achetée.
     */
    public static ItemStack buildAutoDirtingItem(fr.geven.clicker.upgrade.StrongUpgrades strongUpgrades,
                                                   int xpLevel, boolean shovelUnlocked, ShovelTier shovelTier,
                                                   int shovelPurchases) {
        ItemStack item = new ItemStack(Material.HOPPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Auto Dirting", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        double perSecond = strongUpgrades.autoDirtingRatePerSecond();

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Génère : " + NumberFormatting.money(perSecond) + "/sec",
                        NumberFormatting.DIRT_COLOR)
                .decoration(TextDecoration.ITALIC, false));

        if (strongUpgrades.autoDirtingMoreInfo()) {
            lore.add(Component.text("Génère : " + NumberFormatting.money(perSecond * 60) + "/min",
                            NumberFormatting.DIRT_COLOR)
                    .decoration(TextDecoration.ITALIC, false));
        }

        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * Construit une des 9 tuiles du bloc Dirtyfy (3x3). Si verrouillé, bedrock générique comme
     * les autres améliorations. Sinon, la tuile correspondante de la texture "trou noir" custom
     * (chaque tuile est cliquable et déclenche le même Dirtyfy).
     */
    public static ItemStack buildDirtyfyTileItem(int index, boolean unlocked) {
        if (!unlocked) {
            return buildLockedItem("Dirtyfy", DIRTYFY_UNLOCK_CONDITION);
        }

        // Le rendu visuel vient du fond peint directement dans l'image du panneau (aucune
        // démarcation possible) ; l'item lui-même reste cliquable mais invisible.
        String modelTag = "gevent_filler";

        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Dirtyfy", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Premier layer de prestige.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Remet TOUT à zéro (Dirt, xp, pelle,", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("améliorations...) et débloque", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("définitivement \"Dirtyfy Upgrades\".", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Clique pour Dirtyfy (irréversible)", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(modelTag));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Item purement informatif (pas de clic, juste un tooltip) placé à côté du bloc Dirtyfy
     * une fois débloqué, pour expliquer ce qu'il fait — vu que les 9 slots eux-mêmes n'ont
     * plus d'item (donc plus de tooltip) depuis qu'ils sont vides.
     */
    public static ItemStack buildDirtyfyInfoItem(int mardiGrassLevel, int chagrassLevel) {
        ItemStack item = new ItemStack(Material.KNOWLEDGE_BOOK);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Dirtyfy", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        double grassReward = 10.0 * fr.geven.clicker.upgrade.DirtyfyUpgradePricing.mardiGrassMultiplier(mardiGrassLevel)
                * fr.geven.clicker.upgrade.DirtyfyUpgradePricing.chagrassMultiplier(chagrassLevel);

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Premier layer de prestige.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Récompense : " + Math.round(grassReward) + " Grass", NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Cliquer sur le trou noir remet TOUT à", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("zéro (Dirt, xp, pelle, améliorations...)", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("et débloque définitivement", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("\"Dirtyfy Upgrades\".", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Irréversible !", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
        return item;
    }

    /** Construit l'item "Dirtyfy Upgrades" (débloqué après le premier Dirtyfy). Ouvre sa propre interface. */
    public static ItemStack buildDirtyfyUpgradesItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Dirtyfy Upgrades", net.kyori.adventure.text.format.TextColor.color(0xBD6E60),
                        TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour ouvrir", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_dirtyfy_upgrades_icon"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    /** Construit l'item "Automater Settings" (débloqué en achetant l'Experience Autobuyer). */
    public static ItemStack buildAutomaterSettingsItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Automater Settings", NamedTextColor.GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour ouvrir", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_automater_settings"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }
}
