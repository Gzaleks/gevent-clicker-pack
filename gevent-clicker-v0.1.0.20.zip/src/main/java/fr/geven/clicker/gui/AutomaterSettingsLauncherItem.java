package fr.geven.clicker.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Le raccourci "Automater Settings" placé dans la hotbar du joueur (9ème slot), qui ouvre
 * l'interface Automater Settings. N'apparaît qu'une fois l'Experience Autobuyer acheté.
 *
 * Même technique que {@link LauncherItem} : identifié par une clé PersistentDataContainer,
 * indépendamment de son apparence (papier avec le tag custom "gevent_automater_settings").
 */
public class AutomaterSettingsLauncherItem {

    private static final String MODEL_TAG = "gevent_automater_settings";

    private final NamespacedKey key;

    public AutomaterSettingsLauncherItem(JavaPlugin plugin) {
        this.key = new NamespacedKey(plugin, "automater_settings_launcher");
    }

    /** Construit un nouvel exemplaire de l'item raccourci. */
    public ItemStack build() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Automater Settings", NamedTextColor.GRAY, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Clique pour gérer tes automatisations !", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(MODEL_TAG));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        return item;
    }

    /** Indique si un ItemStack donné est bien ce raccourci (et pas un simple papier). */
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }
}
