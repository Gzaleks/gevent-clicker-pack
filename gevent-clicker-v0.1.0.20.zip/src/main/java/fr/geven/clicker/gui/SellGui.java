package fr.geven.clicker.gui;

import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Interface principale du PNJ "Farm Buyer" : fond vert clair (même que le shop du Seed Seller).
 *  Clic droit sur le blé = vend tout instantanément. Clic gauche = ouvre le choix de quantité. */
public final class SellGui {

    /** Fond custom (panneau vert clair avec "Farm Buyer" peint dedans), même technique que ClickerGui. */
    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "sellbg"));

    public static final int SIZE = 54;
    public static final int WHEAT_SLOT = 22;
    /** Débloqué à partir du Void Composter Tier 2. Vente simplifiée : clic droit = tout vendre. */
    public static final int POTATO_SLOT = 24;

    private SellGui() {
    }

    public static Inventory create(SellHolder holder, WheatFarmManager farmManager, PotatoFarmManager potatoFarmManager,
                                    boolean potatoUnlocked) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(WHEAT_SLOT, buildWheatItem(farmManager));
        if (potatoUnlocked) {
            inventory.setItem(POTATO_SLOT, buildPotatoItem(potatoFarmManager));
        }
        return inventory;
    }

    public static ItemStack buildWheatItem(WheatFarmManager farmManager) {
        ItemStack item = new ItemStack(Material.WHEAT, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Blé", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        long price = farmManager.getSellPricePerUnit();
        long total = farmManager.getWheatCount() * price;

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Prix unitaire : " + price + " Ecus", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Tout vendre (" + farmManager.getWheatCount() + ") : " + total + " Ecus",
                        NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Clic droit : tout vendre", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Clic gauche : choisir une quantité", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildPotatoItem(PotatoFarmManager potatoFarmManager) {
        ItemStack item = new ItemStack(Material.POTATO, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Patate", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        long price = potatoFarmManager.getSellPricePerUnit();
        long total = potatoFarmManager.getPotatoCount() * price;

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Prix unitaire : " + price + " Ecus", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Tout vendre (" + potatoFarmManager.getPotatoCount() + ") : " + total + " Ecus",
                        NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Clic droit : tout vendre", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        item.setItemMeta(meta);
        return item;
    }
}
