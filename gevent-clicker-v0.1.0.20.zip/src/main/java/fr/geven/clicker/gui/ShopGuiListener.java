package fr.geven.clicker.gui;

import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.VoidComposterManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

/** Gère les clics dans le shop du PNJ marchand (achat de graines de blé, et de patates à partir
 *  du Void Composter Tier 2). */
public class ShopGuiListener implements Listener {

    private final EcusManager ecusManager;
    private final WheatFarmManager farmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final FricScoreboardManager scoreboardManager;

    public ShopGuiListener(EcusManager ecusManager, WheatFarmManager farmManager, PotatoFarmManager potatoFarmManager,
                            VoidComposterManager voidComposterManager, FricScoreboardManager scoreboardManager) {
        this.ecusManager = ecusManager;
        this.farmManager = farmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.scoreboardManager = scoreboardManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof ShopHolder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot == ShopGui.SEED_SLOT) {
            handleSeedPurchase(event, player);
        } else if (slot == ShopGui.POTATO_SLOT && voidComposterManager.getTier() >= 2) {
            handlePotatoPurchase(event, player);
        }
    }

    private void handleSeedPurchase(InventoryClickEvent event, Player player) {
        if (farmManager.isSoldOut()) {
            player.sendMessage(Component.text("Toutes les graines disponibles ont déjà été achetées (10/10).",
                    NamedTextColor.RED));
            return;
        }

        long price = farmManager.priceForNextPurchase();
        if (price > 0 && ecusManager.getEcus(player.getUniqueId()) < price) {
            player.sendMessage(Component.text("Pas assez d'Ecus (besoin de " + price + ").", NamedTextColor.RED));
            return;
        }

        if (farmManager.purchaseSeed(player, ecusManager)) {
            player.sendMessage(Component.text("Graine de blé achetée et plantée !", NamedTextColor.GREEN));
            event.getInventory().setItem(ShopGui.SEED_SLOT, ShopGui.buildSeedItem(farmManager));
            scoreboardManager.updateEcus(player, ecusManager.getEcus(player.getUniqueId()));
        }
    }

    private void handlePotatoPurchase(InventoryClickEvent event, Player player) {
        if (potatoFarmManager.isSoldOut()) {
            player.sendMessage(Component.text("Toutes les patates disponibles ont déjà été achetées (10/10).",
                    NamedTextColor.RED));
            return;
        }

        long price = potatoFarmManager.priceForNextPurchase();
        if (price > 0 && ecusManager.getEcus(player.getUniqueId()) < price) {
            player.sendMessage(Component.text("Pas assez d'Ecus (besoin de " + price + ").", NamedTextColor.RED));
            return;
        }

        if (potatoFarmManager.purchaseSeed(player, ecusManager)) {
            player.sendMessage(Component.text("Patate achetée et plantée !", NamedTextColor.GREEN));
            event.getInventory().setItem(ShopGui.POTATO_SLOT, ShopGui.buildPotatoItem(potatoFarmManager));
            scoreboardManager.updateEcus(player, ecusManager.getEcus(player.getUniqueId()));
        }
    }
}
