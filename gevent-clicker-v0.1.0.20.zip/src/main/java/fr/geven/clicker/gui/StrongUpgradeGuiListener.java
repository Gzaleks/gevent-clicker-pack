package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.StrongUpgrades;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gère les achats des 4 améliorations permanentes de l'interface "Strong Upgrade"
 * (Fric x2, XP x2, Better Shovel, Better Experience). Toutes à achat unique.
 */
public class StrongUpgradeGuiListener implements Listener {

    private final PlayerDataManager dataManager;
    private final UpgradeManager upgradeManager;
    private final FricScoreboardManager scoreboardManager;
    private final XpManager xpManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    private static final long MIN_INTERVAL_NANOS = 40_000_000L;
    private final Map<String, Long> lastClickNanos = new ConcurrentHashMap<>();

    public StrongUpgradeGuiListener(PlayerDataManager dataManager, UpgradeManager upgradeManager,
                                     FricScoreboardManager scoreboardManager, XpManager xpManager,
                                     DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.dataManager = dataManager;
        this.upgradeManager = upgradeManager;
        this.scoreboardManager = scoreboardManager;
        this.xpManager = xpManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof StrongUpgradeHolder)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof StrongUpgradeHolder)) {
            return;
        }
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        if (!debounceOk(player, slot)) {
            return;
        }

        Inventory inv = event.getClickedInventory();
        if (slot == StrongUpgradeGui.FRIC_X2_SLOT) {
            buy(player, inv, slot, "fricX2Bought", StrongUpgrades.FRIC_X2_PRICE,
                    UpgradeManager::buyFricX2, StrongUpgradeGui::buildFricX2Item, "Dirt x2 acheté !");
        } else if (slot == StrongUpgradeGui.XP_X2_SLOT) {
            buy(player, inv, slot, "xpX2Bought", StrongUpgrades.XP_X2_PRICE,
                    UpgradeManager::buyXpX2, StrongUpgradeGui::buildXpX2Item, "XP x2 acheté !");
        } else if (slot == StrongUpgradeGui.BETTER_SHOVEL_SLOT) {
            buy(player, inv, slot, "betterShovelBought", StrongUpgrades.BETTER_SHOVEL_PRICE,
                    UpgradeManager::buyBetterShovel, StrongUpgradeGui::buildBetterShovelItem, "Better Shovel acheté !");
        } else if (slot == StrongUpgradeGui.BETTER_EXPERIENCE_SLOT) {
            buy(player, inv, slot, "betterExperienceBought", StrongUpgrades.BETTER_EXPERIENCE_PRICE,
                    UpgradeManager::buyBetterExperience, StrongUpgradeGui::buildBetterExperienceItem, "Better Experience acheté !");
        } else if (slot == StrongUpgradeGui.FRIC_X2_5_SLOT) {
            buyIfTier4(player, inv, slot, "fricX2_5Bought", StrongUpgrades.FRIC_X2_5_PRICE,
                    UpgradeManager::buyFricX2_5, StrongUpgradeGui::buildFricX2_5Item, "Dirt x2,5 acheté !");
        } else if (slot == StrongUpgradeGui.XP_X2_5_SLOT) {
            buyIfTier4(player, inv, slot, "xpX2_5Bought", StrongUpgrades.XP_X2_5_PRICE,
                    UpgradeManager::buyXpX2_5, StrongUpgradeGui::buildXpX2_5Item, "XP x2,5 acheté !");
        } else if (slot == StrongUpgradeGui.AUTO_DIRTING_SLOT) {
            buyAutoDirting(player, inv, slot);
        } else if (slot == StrongUpgradeGui.AUTO_DIRTING_MORE_INFO_SLOT) {
            buyIfAutoDirtingOwned(player, inv, slot, "autoDirtingMoreInfoBought", StrongUpgrades.AUTO_DIRTING_MORE_INFO_PRICE,
                    UpgradeManager::buyAutoDirtingMoreInfo, StrongUpgradeGui::buildAutoDirtingMoreInfoItem,
                    "Auto Dirting More Infos acheté !");
        } else if (slot == StrongUpgradeGui.MORE_AUTO_DIRT_SLOT) {
            buyIfAutoDirtingOwned(player, inv, slot, "moreAutoDirtBought", StrongUpgrades.MORE_AUTO_DIRT_PRICE,
                    UpgradeManager::buyMoreAutoDirt, StrongUpgradeGui::buildMoreAutoDirtItem, "More Auto Dirt acheté !");
        } else if (slot == StrongUpgradeGui.BACK_SLOT) {
            goBack(player);
        }
    }

    @FunctionalInterface
    private interface Purchaser {
        void purchase(UpgradeManager manager, UUID uuid);
    }

    @FunctionalInterface
    private interface ItemBuilder {
        org.bukkit.inventory.ItemStack build(boolean bought);
    }

    private void buy(Player player, Inventory inv, int slot, String fieldName, long price,
                      Purchaser purchaser, ItemBuilder itemBuilder, String successMessage) {
        UUID uuid = player.getUniqueId();
        StrongUpgrades current = upgradeManager.getStrongUpgrades(uuid);

        boolean alreadyBought = switch (fieldName) {
            case "fricX2Bought" -> current.fricX2();
            case "xpX2Bought" -> current.xpX2();
            case "betterShovelBought" -> current.betterShovel();
            case "betterExperienceBought" -> current.betterExperience();
            case "fricX2_5Bought" -> current.fricX2_5();
            case "xpX2_5Bought" -> current.xpX2_5();
            case "autoDirtingMoreInfoBought" -> current.autoDirtingMoreInfo();
            case "moreAutoDirtBought" -> current.moreAutoDirt();
            default -> current.autoDirting();
        };
        if (alreadyBought) {
            deny(player, "Déjà acheté !");
            return;
        }

        double fric = dataManager.getFric(uuid);
        if (fric < price) {
            deny(player, "Pas assez de Dirt ! (" + price + "ɗ requis)");
            return;
        }

        double newFric = dataManager.addFric(uuid, -price);
        dataManager.saveAsync();
        purchaser.purchase(upgradeManager, uuid);
        upgradeManager.saveAsync();
        scoreboardManager.updateFric(player, newFric);

        inv.setItem(slot, itemBuilder.build(true));

        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text(successMessage, NamedTextColor.GOLD));
    }

    /** Comme {@link #buy}, mais vérifie d'abord que la pelle est bien au tier 4 (sécurité,
     *  le slot ne devrait déjà plus être cliquable comme "verrouillé" sinon). */
    private void buyIfTier4(Player player, Inventory inv, int slot, String fieldName, long price,
                             Purchaser purchaser, ItemBuilder itemBuilder, String successMessage) {
        UUID uuid = player.getUniqueId();
        if (upgradeManager.getShovelTier(uuid).tier < 4) {
            deny(player, "Verrouillé — passe la pelle au tier 4 !");
            return;
        }
        buy(player, inv, slot, fieldName, price, purchaser, itemBuilder, successMessage);
    }

    /** Comme {@link #buy}, mais vérifie d'abord qu'"Auto Dirting" est bien acheté. */
    private void buyIfAutoDirtingOwned(Player player, Inventory inv, int slot, String fieldName, long price,
                                        Purchaser purchaser, ItemBuilder itemBuilder, String successMessage) {
        UUID uuid = player.getUniqueId();
        if (!upgradeManager.getStrongUpgrades(uuid).autoDirting()) {
            deny(player, "Verrouillé — achète d'abord Auto Dirting !");
            return;
        }
        buy(player, inv, slot, fieldName, price, purchaser, itemBuilder, successMessage);
    }

    /** Achat spécial d'"Auto Dirting" : débloque en cascade les 2 améliorations qui en dépendent
     *  (jusque-là en bedrock), en plus de son propre item. */
    private void buyAutoDirting(Player player, Inventory inv, int slot) {
        UUID uuid = player.getUniqueId();
        if (upgradeManager.getShovelTier(uuid).tier < 4) {
            deny(player, "Verrouillé — passe la pelle au tier 4 !");
            return;
        }
        if (upgradeManager.getStrongUpgrades(uuid).autoDirting()) {
            deny(player, "Déjà acheté !");
            return;
        }

        double fric = dataManager.getFric(uuid);
        if (fric < StrongUpgrades.AUTO_DIRTING_PRICE) {
            deny(player, "Pas assez de Dirt ! (" + StrongUpgrades.AUTO_DIRTING_PRICE + "ɗ requis)");
            return;
        }

        double newFric = dataManager.addFric(uuid, -StrongUpgrades.AUTO_DIRTING_PRICE);
        dataManager.saveAsync();
        upgradeManager.buyAutoDirting(uuid);
        upgradeManager.saveAsync();
        scoreboardManager.updateFric(player, newFric);

        inv.setItem(slot, StrongUpgradeGui.buildAutoDirtingPurchaseItem(true));
        // Débloque l'affichage (encore en bedrock jusque-là) des 2 améliorations dépendantes
        inv.setItem(StrongUpgradeGui.AUTO_DIRTING_MORE_INFO_SLOT, StrongUpgradeGui.buildAutoDirtingMoreInfoItem(false));
        inv.setItem(StrongUpgradeGui.MORE_AUTO_DIRT_SLOT, StrongUpgradeGui.buildMoreAutoDirtItem(false));

        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Auto Dirting acheté !", NamedTextColor.GOLD));
    }

    private void goBack(Player player) {
        player.closeInventory();
        GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
    }

    private void deny(Player player, String message) {
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
        player.sendActionBar(Component.text(message, NamedTextColor.RED));
    }

    private boolean debounceOk(Player player, int slot) {
        String key = player.getUniqueId() + ":su:" + slot;
        long now = System.nanoTime();
        Long last = lastClickNanos.put(key, now);
        return last == null || (now - last) >= MIN_INTERVAL_NANOS;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof StrongUpgradeHolder) {
            event.setCancelled(true);
        }
    }
}
