package fr.geven.clicker.gui;

import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** Interface custom du tonneau "Farmer's Inventory" : fond gris foncé, 6 lignes. Affiche les
 *  ressources récoltées par la farm (pour l'instant, uniquement le blé). Le nombre affiché
 *  n'est PAS la taille du stack (toujours 1) mais une donnée dans le tooltip. */
public final class FarmerInventoryGui {

    /** Fond custom (panneau gris foncé avec "Farmer's Inventory" peint dedans), même technique que ClickerGui. */
    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "farmerbg"));

    public static final int SIZE = 54;
    public static final int WHEAT_SLOT = 22;
    public static final int POTATO_SLOT = 24;

    private FarmerInventoryGui() {
    }

    public static Inventory create(FarmerInventoryHolder holder, WheatFarmManager farmManager,
                                    PotatoFarmManager potatoFarmManager, boolean potatoUnlocked) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(WHEAT_SLOT, buildWheatItem(farmManager));
        if (potatoUnlocked) {
            inventory.setItem(POTATO_SLOT, buildPotatoItem(potatoFarmManager));
        }
        return inventory;
    }

    public static ItemStack buildWheatItem(WheatFarmManager farmManager) {
        ItemStack item = new ItemStack(Material.WHEAT, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Blé", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Blé récolté : " + farmManager.getWheatCount(), NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Graines plantées : " + farmManager.getTotalPurchased() + " / 10", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildPotatoItem(PotatoFarmManager potatoFarmManager) {
        ItemStack item = new ItemStack(Material.POTATO, 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Patate", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Patates récoltées : " + potatoFarmManager.getPotatoCount(), NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Patates plantées : " + potatoFarmManager.getTotalPurchased() + " / 10", NamedTextColor.GREEN)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        item.setItemMeta(meta);
        return item;
    }
}
