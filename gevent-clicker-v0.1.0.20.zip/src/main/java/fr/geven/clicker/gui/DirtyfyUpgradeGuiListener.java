package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.GrassManager;
import fr.geven.clicker.listener.AutomaterSettingsLauncherItemListener;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.DirtyfyUpgradePricing;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Gère les achats des 3 premières améliorations de l'interface "Dirtyfy Upgrades", payées en Grass. */
public class DirtyfyUpgradeGuiListener implements Listener {

    private final GrassManager grassManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final FricScoreboardManager scoreboardManager;
    private final AutomaterSettingsLauncherItemListener automaterSettingsLauncherItemListener;
    private final fr.geven.clicker.listener.CoinSlotsListener coinSlotsListener;
    private final fr.geven.clicker.data.PlayerDataManager dataManager;
    private final fr.geven.clicker.data.XpManager xpManager;
    private final fr.geven.clicker.data.UpgradeManager upgradeManager;

    private static final long MIN_INTERVAL_NANOS = 40_000_000L;
    private final Map<String, Long> lastClickNanos = new ConcurrentHashMap<>();

    public DirtyfyUpgradeGuiListener(GrassManager grassManager, DirtyfyUpgradeManager dirtyfyUpgradeManager,
                                      FricScoreboardManager scoreboardManager,
                                      AutomaterSettingsLauncherItemListener automaterSettingsLauncherItemListener,
                                      fr.geven.clicker.listener.CoinSlotsListener coinSlotsListener,
                                      fr.geven.clicker.data.PlayerDataManager dataManager,
                                      fr.geven.clicker.data.XpManager xpManager,
                                      fr.geven.clicker.data.UpgradeManager upgradeManager) {
        this.grassManager = grassManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.scoreboardManager = scoreboardManager;
        this.automaterSettingsLauncherItemListener = automaterSettingsLauncherItemListener;
        this.coinSlotsListener = coinSlotsListener;
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof DirtyfyUpgradeHolder)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof DirtyfyUpgradeHolder)) {
            return;
        }
        if (event.getClick() == ClickType.DOUBLE_CLICK) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        if (!debounceOk(player, slot)) {
            return;
        }

        Inventory inv = event.getClickedInventory();
        if (slot == DirtyfyUpgradeGui.BASE_DIRT_BOOSTER_SLOT) {
            handleBaseDirtBooster(player, inv);
        } else if (slot == DirtyfyUpgradeGui.GRASS_BASE_BOOSTER_SLOT) {
            handleGrassBaseBooster(player, inv);
        } else if (slot == DirtyfyUpgradeGui.MARDI_GRASS_SLOT) {
            handleMardiGrass(player, inv);
        } else if (slot == DirtyfyUpgradeGui.EXPERIENCE_AUTOBUYER_SLOT) {
            handleExperienceAutobuyer(player, inv);
        } else if (slot == DirtyfyUpgradeGui.CHAGRASS_SLOT) {
            handleChagrass(player, inv);
        } else if (slot == DirtyfyUpgradeGui.FENETRE_XP_SLOT) {
            handleFenetreXp(player, inv);
        } else if (slot == DirtyfyUpgradeGui.XP_FOR_HOMELESS_SLOT) {
            handleXpForHomeless(player, inv);
        } else if (slot == DirtyfyUpgradeGui.GRASSIFICATION_SLOT) {
            handleGrassification(player, inv);
        } else if (slot == DirtyfyUpgradeGui.BACK_SLOT) {
            goBack(player);
        }
    }

    private void goBack(Player player) {
        player.closeInventory();
        GuiOpener.open(player, dataManager, xpManager, upgradeManager, dirtyfyUpgradeManager);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
    }

    private void handleChagrass(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        long price = DirtyfyUpgradePricing.chagrassPrice(state.chagrassLevel);
        if (price < 0) {
            deny(player, "Ouverture de Chagrass déjà au maximum !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < price) {
            deny(player, "Pas assez de Grass ! (" + price + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -price);
        grassManager.saveAsync();
        int newLevel = dirtyfyUpgradeManager.addChagrassLevel(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.CHAGRASS_SLOT, DirtyfyUpgradeGui.buildChagrassItem(newLevel));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Ouverture de Chagrass : " + newLevel + " / "
                + DirtyfyUpgradeManager.CHAGRASS_MAX, NamedTextColor.DARK_GREEN));
    }

    private void handleFenetreXp(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        if (state.fenetreXpBought) {
            deny(player, "Déjà acheté !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < DirtyfyUpgradePricing.FENETRE_XP_PRICE) {
            deny(player, "Pas assez de Grass ! (" + DirtyfyUpgradePricing.FENETRE_XP_PRICE + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -DirtyfyUpgradePricing.FENETRE_XP_PRICE);
        grassManager.saveAsync();
        dirtyfyUpgradeManager.buyFenetreXp(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.FENETRE_XP_SLOT, DirtyfyUpgradeGui.buildFenetreXpItem(true));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Fenêtre XP achetée !", NamedTextColor.AQUA));
    }

    private void handleXpForHomeless(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        long price = DirtyfyUpgradePricing.xpForHomelessPrice(state.xpForHomelessLevel);
        if (price < 0) {
            deny(player, "XP for homeless déjà au maximum !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < price) {
            deny(player, "Pas assez de Grass ! (" + price + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -price);
        grassManager.saveAsync();
        int newLevel = dirtyfyUpgradeManager.addXpForHomelessLevel(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.XP_FOR_HOMELESS_SLOT, DirtyfyUpgradeGui.buildXpForHomelessItem(newLevel));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("XP for homeless : " + newLevel + " / "
                + DirtyfyUpgradeManager.XP_FOR_HOMELESS_MAX, NamedTextColor.AQUA));
    }

    private void handleGrassification(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        if (state.grassificationBought) {
            deny(player, "Déjà acheté !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < DirtyfyUpgradePricing.GRASSIFICATION_PRICE) {
            deny(player, "Pas assez de Grass ! (" + DirtyfyUpgradePricing.GRASSIFICATION_PRICE + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -DirtyfyUpgradePricing.GRASSIFICATION_PRICE);
        grassManager.saveAsync();
        dirtyfyUpgradeManager.buyGrassification(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        // Fait apparaître immédiatement le vrai Shovel Coin (sinon il faudrait se reconnecter)
        coinSlotsListener.ensurePresent(player);

        inv.setItem(DirtyfyUpgradeGui.GRASSIFICATION_SLOT, DirtyfyUpgradeGui.buildGrassificationItem(true));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
        player.sendActionBar(Component.text("Grassification effectuée ! Le Shovel Coin est dans ton inventaire.",
                NamedTextColor.GOLD));
    }

    private void handleBaseDirtBooster(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        long price = DirtyfyUpgradePricing.baseDirtBoosterPrice(state.baseDirtBoosterLevel);
        if (price < 0) {
            deny(player, "Base Dirt Booster déjà au maximum !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < price) {
            deny(player, "Pas assez de Grass ! (" + price + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -price);
        grassManager.saveAsync();
        int newLevel = dirtyfyUpgradeManager.addBaseDirtBoosterLevel(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.BASE_DIRT_BOOSTER_SLOT, DirtyfyUpgradeGui.buildBaseDirtBoosterItem(newLevel));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Base Dirt Booster : " + newLevel + " / "
                + DirtyfyUpgradeManager.BASE_DIRT_BOOSTER_MAX, fr.geven.clicker.util.NumberFormatting.DIRT_COLOR));
    }

    private void handleGrassBaseBooster(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        long price = DirtyfyUpgradePricing.grassBaseBoosterPrice(state.grassBaseBoosterLevel);
        if (price < 0) {
            deny(player, "Grass Base Booster déjà au maximum !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < price) {
            deny(player, "Pas assez de Grass ! (" + price + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -price);
        grassManager.saveAsync();
        int newLevel = dirtyfyUpgradeManager.addGrassBaseBoosterLevel(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.GRASS_BASE_BOOSTER_SLOT, DirtyfyUpgradeGui.buildGrassBaseBoosterItem(newLevel));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Grass Base Booster : " + newLevel + " / "
                + DirtyfyUpgradeManager.GRASS_BOOSTER_MAX, NamedTextColor.GREEN));
    }

    private void handleMardiGrass(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        long price = DirtyfyUpgradePricing.mardiGrassPrice(state.mardiGrassLevel);
        if (price < 0) {
            deny(player, "Mardi Grass déjà au maximum !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < price) {
            deny(player, "Pas assez de Grass ! (" + price + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -price);
        grassManager.saveAsync();
        int newLevel = dirtyfyUpgradeManager.addMardiGrassLevel(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        inv.setItem(DirtyfyUpgradeGui.MARDI_GRASS_SLOT, DirtyfyUpgradeGui.buildMardiGrassItem(newLevel));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Mardi Grass : " + newLevel + " / "
                + DirtyfyUpgradeManager.MARDI_GRASS_MAX, NamedTextColor.GREEN));
    }

    private void handleExperienceAutobuyer(Player player, Inventory inv) {
        UUID uuid = player.getUniqueId();
        DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
        if (state.experienceAutobuyerBought) {
            deny(player, "Déjà acheté !");
            return;
        }
        double grass = grassManager.getGrass(uuid);
        if (grass < DirtyfyUpgradePricing.EXPERIENCE_AUTOBUYER_PRICE) {
            deny(player, "Pas assez de Grass ! (" + DirtyfyUpgradePricing.EXPERIENCE_AUTOBUYER_PRICE + " requis)");
            return;
        }

        double newGrass = grassManager.addGrass(uuid, -DirtyfyUpgradePricing.EXPERIENCE_AUTOBUYER_PRICE);
        grassManager.saveAsync();
        dirtyfyUpgradeManager.buyExperienceAutobuyer(uuid);
        dirtyfyUpgradeManager.saveAsync();
        scoreboardManager.updateGrass(player, newGrass);

        // Donne immédiatement l'item raccourci dans la hotbar (sinon il faudrait se reconnecter)
        automaterSettingsLauncherItemListener.ensurePresent(player);

        inv.setItem(DirtyfyUpgradeGui.EXPERIENCE_AUTOBUYER_SLOT, DirtyfyUpgradeGui.buildExperienceAutobuyerItem(true));
        player.playSound(player.getLocation(), Sound.UI_TOTEM_USE, 0.8f, 1.4f);
        player.sendActionBar(Component.text("Experience Autobuyer acheté ! Utilise l'item dans ta hotbar pour l'activer.",
                NamedTextColor.AQUA));
    }

    private void deny(Player player, String message) {
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
        player.sendActionBar(Component.text(message, NamedTextColor.RED));
    }

    private boolean debounceOk(Player player, int slot) {
        String key = player.getUniqueId() + ":du:" + slot;
        long now = System.nanoTime();
        Long last = lastClickNanos.put(key, now);
        return last == null || (now - last) >= MIN_INTERVAL_NANOS;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof DirtyfyUpgradeHolder) {
            event.setCancelled(true);
        }
    }
}
