package fr.geven.clicker.gui;

import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.world.VoidComposterManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.List;
import java.util.UUID;

/** Interface de tier up du Void Composter : fond custom (thème End/Void), item info en haut,
 *  portail 3x3 entouré de son cadre en dessous (21 slots cliquables, sans item, texture peinte
 *  dans le fond, même technique que le "trou noir" du Dirtyfy). */
public final class VoidComposterGui {

    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "voidbg"));

    public static final int SIZE = 54;
    public static final int INFO_SLOT = 4;

    /** Cadre du portail (12 slots, coins retirés) + coeur 3x3 (9 slots) = 21 slots cliquables. */
    public static final int[] FRAME_SLOTS = {12, 13, 14, 20, 24, 29, 33, 38, 42, 48, 49, 50};
    public static final int[] PORTAL_SLOTS = {21, 22, 23, 30, 31, 32, 39, 40, 41};

    private VoidComposterGui() {
    }

    public static Inventory create(VoidComposterHolder holder, VoidComposterManager voidComposterManager,
                                    WheatFarmManager wheatFarmManager,
                                    fr.geven.clicker.world.PotatoFarmManager potatoFarmManager,
                                    EcusManager ecusManager, UUID uuid) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(INFO_SLOT, buildInfoItem(voidComposterManager, wheatFarmManager, potatoFarmManager, ecusManager, uuid));
        // Les 21 slots du portail restent volontairement sans item : le dessin est peint dans le
        // fond custom, et un clic est détecté par son index de slot brut (voir le listener).
        return inventory;
    }

    public static ItemStack buildInfoItem(VoidComposterManager voidComposterManager, WheatFarmManager wheatFarmManager,
                                           fr.geven.clicker.world.PotatoFarmManager potatoFarmManager,
                                           EcusManager ecusManager, UUID uuid) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_void_info"));
        meta.setCustomModelDataComponent(cmd);

        int tier = voidComposterManager.getTier();
        if (voidComposterManager.isMaxTier()) {
            meta.displayName(Component.text("Void Composter — Tier " + tier + " (maximum)", NamedTextColor.AQUA, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Déjà au niveau maximum.", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
        } else {
            long[] cost = voidComposterManager.nextCost();
            long wheatCost = cost[0];
            long ecusCost = cost[1];
            long potatoCost = cost[2];
            long wheatOwned = wheatFarmManager.getWheatCount();
            long ecusOwned = ecusManager.getEcus(uuid);
            long potatoOwned = potatoFarmManager != null ? potatoFarmManager.getPotatoCount() : 0L;

            meta.displayName(Component.text("Void Composter Tier " + tier + " >> Tier " + (tier + 1),
                            NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));

            List<Component> lore = new java.util.ArrayList<>();
            String costLine = "Coût : " + wheatCost + " Blé + " + ecusCost + " Ecus";
            if (potatoCost > 0) {
                costLine += " + " + potatoCost + " Patates";
            }
            lore.add(Component.text(costLine, NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Blé : " + Math.min(wheatOwned, wheatCost) + " / " + wheatCost,
                            wheatOwned >= wheatCost ? NamedTextColor.GREEN : NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Ecus : " + Math.min(ecusOwned, ecusCost) + " / " + ecusCost,
                            ecusOwned >= ecusCost ? NamedTextColor.GREEN : NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
            if (potatoCost > 0) {
                lore.add(Component.text("Patates : " + Math.min(potatoOwned, potatoCost) + " / " + potatoCost,
                                potatoOwned >= potatoCost ? NamedTextColor.GREEN : NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("100 patates !! 100 patates !!", NamedTextColor.DARK_GRAY, TextDecoration.ITALIC));
            }
            lore.add(Component.empty());
            if (tier == 1) {
                lore.add(Component.text("Débloque : la Patate (Seed Seller), le champ agrandi,",
                                NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
                lore.add(Component.text("et un bonus x2 au blé récolté", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false));
            } else {
                lore.add(Component.text("Débloque : l'évolution finale du Void Composter", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lore);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
        return item;
    }
}
