package fr.geven.clicker.gui;

import fr.geven.clicker.util.NumberFormatting;
import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Interface du shop du PNJ marchand : fond vert clair, 6 lignes. Pour l'instant, un seul
 *  article : les graines de blé (limitées à 10, prix x10 à chaque achat, premier gratuit). */
public final class ShopGui {

    /** Fond custom (panneau vert clair avec "Seed Seller" peint dedans), même technique que ClickerGui. */
    public static final Component TITLE = Component.text("")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "shopbg"));

    public static final int SIZE = 54;
    public static final int SEED_SLOT = 22;
    /** Débloqué à partir du Void Composter Tier 2. */
    public static final int POTATO_SLOT = 24;

    private ShopGui() {
    }

    public static Inventory create(ShopHolder holder, WheatFarmManager farmManager, PotatoFarmManager potatoFarmManager,
                                    boolean potatoUnlocked) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);
        inventory.setItem(SEED_SLOT, buildSeedItem(farmManager));
        if (potatoUnlocked) {
            inventory.setItem(POTATO_SLOT, buildPotatoItem(potatoFarmManager));
        }
        return inventory;
    }

    public static ItemStack buildSeedItem(WheatFarmManager farmManager) {
        ItemStack item = new ItemStack(Material.WHEAT_SEEDS);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Graines de blé", NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Achats : " + farmManager.getTotalPurchased() + " / 10", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        if (farmManager.isSoldOut()) {
            lore.add(Component.text("Épuisé (farm complète)", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            long price = farmManager.priceForNextPurchase();
            if (price == 0) {
                lore.add(Component.text("Prix : GRATOOOOS", NamedTextColor.GOLD, TextDecoration.BOLD)
                        .decoration(TextDecoration.ITALIC, false));
            } else {
                lore.add(Component.text("Prix : " + NumberFormatting.ecus(price) + " Ecus", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
            }
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildPotatoItem(PotatoFarmManager potatoFarmManager) {
        ItemStack item = new ItemStack(Material.POTATO);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Patate", NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Achats : " + potatoFarmManager.getTotalPurchased() + " / 10", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        if (potatoFarmManager.isSoldOut()) {
            lore.add(Component.text("Épuisé (farm complète)", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            long price = potatoFarmManager.priceForNextPurchase();
            if (price == 0) {
                lore.add(Component.text("Prix : GRATOOOOS", NamedTextColor.GOLD, TextDecoration.BOLD)
                        .decoration(TextDecoration.ITALIC, false));
            } else {
                lore.add(Component.text("Prix : " + NumberFormatting.ecus(price) + " Ecus", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false));
            }
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
