package fr.geven.clicker.gui;

import fr.geven.clicker.util.NumberFormatting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Le "Shovel Coin" : trophée permanent obtenu en achetant "Grassification" dans les Dirtyfy
 * Upgrades. Placé dans un des 4 emplacements "pièce" en haut à gauche de l'inventaire du
 * joueur (voir CoinSlotsListener). Indéplaçable, indroppable, ne se perd jamais à la mort.
 * Cliquer dessus ne fait rien (pur trophée).
 *
 * Même technique que {@link AutomaterSettingsLauncherItem} : identifié par une clé
 * PersistentDataContainer, indépendamment de son apparence (papier + texture custom).
 */
public class ShovelCoinItem {

    private static final String MODEL_TAG = "gevent_shovel_coin";

    private final NamespacedKey key;

    public ShovelCoinItem(JavaPlugin plugin) {
        this.key = new NamespacedKey(plugin, "shovel_coin");
    }

    public ItemStack build() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Shovel Coin", NumberFormatting.DIRT_COLOR, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Trophée de Grassification.", net.kyori.adventure.text.format.NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of(MODEL_TAG));
        meta.setCustomModelDataComponent(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        return item;
    }

    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.PAPER || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }
}
