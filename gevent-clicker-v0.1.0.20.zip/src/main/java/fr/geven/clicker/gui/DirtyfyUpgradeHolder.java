package fr.geven.clicker.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Identifie l'inventaire "Dirtyfy Upgrades" (pour le distinguer des autres dans les écouteurs). */
public class DirtyfyUpgradeHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    @NotNull
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
