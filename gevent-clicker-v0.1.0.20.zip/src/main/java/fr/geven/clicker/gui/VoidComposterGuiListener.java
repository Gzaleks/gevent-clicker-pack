package fr.geven.clicker.gui;

import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.world.CoinDoorWorldManager;
import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.VoidComposterManager;
import fr.geven.clicker.world.WheatFarmManager;
import fr.geven.clicker.world.WorldStructuresManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;
import java.util.UUID;

/** Gère les clics dans l'interface du Void Composter : seuls les 21 slots du portail (cadre +
 *  coeur) tentent un tier up ; l'item info n'est pas cliquable. */
public class VoidComposterGuiListener implements Listener {

    private final JavaPlugin plugin;
    private final VoidComposterManager voidComposterManager;
    private final WheatFarmManager wheatFarmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final WorldStructuresManager structuresManager;
    private final EcusManager ecusManager;
    private final CoinDoorWorldManager worldManager;
    private final int composterX;
    private final int composterY;
    private final int composterZ;

    public VoidComposterGuiListener(JavaPlugin plugin, VoidComposterManager voidComposterManager,
                                     WheatFarmManager wheatFarmManager, PotatoFarmManager potatoFarmManager,
                                     WorldStructuresManager structuresManager, EcusManager ecusManager,
                                     CoinDoorWorldManager worldManager) {
        this.plugin = plugin;
        this.voidComposterManager = voidComposterManager;
        this.wheatFarmManager = wheatFarmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.structuresManager = structuresManager;
        this.ecusManager = ecusManager;
        this.worldManager = worldManager;
        var config = plugin.getConfig();
        this.composterX = config.getInt("composter.x", 10);
        this.composterY = config.getInt("composter.y", 1);
        this.composterZ = config.getInt("composter.z", 10);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof VoidComposterHolder)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof VoidComposterHolder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        boolean isPortalSlot = contains(VoidComposterGui.FRAME_SLOTS, slot) || contains(VoidComposterGui.PORTAL_SLOTS, slot);
        if (!isPortalSlot) {
            return;
        }

        attemptTierUp(player, event.getClickedInventory());
    }

    private void attemptTierUp(Player player, org.bukkit.inventory.Inventory inv) {
        UUID uuid = player.getUniqueId();
        if (voidComposterManager.isMaxTier()) {
            return;
        }
        boolean success = voidComposterManager.tryTierUp(uuid, wheatFarmManager, potatoFarmManager, ecusManager,
                worldManager.getWorld(), composterX, composterY, composterZ);
        if (!success) {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.6f, 1.0f);
            return;
        }

        wheatFarmManager.saveSync();
        ecusManager.saveAsync();
        if (potatoFarmManager != null) {
            potatoFarmManager.saveSync();
        }

        // Effets du tier up : champ agrandi + bonus de récolte à partir du tier 2.
        boolean expanded = voidComposterManager.getTier() >= 2;
        structuresManager.refreshFarmPatch(worldManager.getWorld(), expanded);
        wheatFarmManager.setYieldMultiplier(expanded ? 2 : 1);
        if (potatoFarmManager != null) {
            potatoFarmManager.reapplyAll();
        }

        inv.setItem(VoidComposterGui.INFO_SLOT,
                VoidComposterGui.buildInfoItem(voidComposterManager, wheatFarmManager, potatoFarmManager, ecusManager, uuid));
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.6f);
        player.sendActionBar(Component.text("Void Composter : Tier " + voidComposterManager.getTier() + " !",
                NamedTextColor.LIGHT_PURPLE));

        spawnTierUpFirework();
    }

    /** Feu d'artifice multicolore, explosion instantanée, aucun dégât (voir onFireworkDamage). */
    private void spawnTierUpFirework() {
        World world = worldManager.getWorld();
        if (world == null) {
            return;
        }
        Location loc = new Location(world, composterX + 0.5, composterY + 1.3, composterZ + 0.5);
        Firework firework = world.spawn(loc, Firework.class);
        firework.setMetadata("gevent_void_firework", new FixedMetadataValue(plugin, true));
        FireworkMeta meta = firework.getFireworkMeta();
        meta.clearEffects();
        meta.addEffect(FireworkEffect.builder()
                .with(FireworkEffect.Type.BURST)
                .withColor(Color.PURPLE, Color.FUCHSIA, Color.AQUA, Color.YELLOW, Color.LIME, Color.ORANGE)
                .withFade(Color.WHITE)
                .trail(true)
                .flicker(true)
                .build());
        meta.setPower(0);
        firework.setFireworkMeta(meta);
        firework.detonate();
    }

    /** Empêche tout dégât venant spécifiquement du feu d'artifice de tier up (sécurité, au cas où). */
    @EventHandler
    public void onFireworkDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Firework firework && firework.hasMetadata("gevent_void_firework")) {
            event.setCancelled(true);
        }
    }

    private boolean contains(int[] arr, int value) {
        return Arrays.stream(arr).anyMatch(v -> v == value);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof VoidComposterHolder) {
            event.setCancelled(true);
        }
    }
}
