package fr.geven.clicker.gui;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

/** Interface purement informative : aucun clic ne doit pouvoir en retirer l'item. */
public class FarmerInventoryGuiListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof FarmerInventoryHolder) {
            event.setCancelled(true);
        }
    }
}
