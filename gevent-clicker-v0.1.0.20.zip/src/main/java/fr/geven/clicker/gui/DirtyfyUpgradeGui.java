package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.upgrade.DirtyfyUpgradePricing;
import fr.geven.clicker.util.NumberFormatting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.key.Key;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Interface "Dirtyfy Upgrades", débloquée après le tout premier Dirtyfy. Même technique de
 * fond custom que les autres interfaces, en #BD6E60.
 *
 * Contient 3 améliorations permanentes (payées en Grass), toutes débloquées de base (pas de
 * forme bloquée) :
 *  - Base Dirt Booster : +1$ de base au clic par niveau (10 niveaux)
 *  - Mardi Grass : +x0.2 cumulatif au gain de Grass par Dirtyfy (50 niveaux)
 *  - Experience Autobuyer : achat unique, active l'auto-achat de la fiole (via Automater Settings)
 */
public class DirtyfyUpgradeGui {

    public static final int SIZE = 54;

    public static final int BASE_DIRT_BOOSTER_SLOT = 20;
    public static final int GRASS_BASE_BOOSTER_SLOT = 22;
    public static final int MARDI_GRASS_SLOT = 24;
    public static final int EXPERIENCE_AUTOBUYER_SLOT = 31;
    public static final int CHAGRASS_SLOT = 29;
    public static final int FENETRE_XP_SLOT = 33;
    public static final int XP_FOR_HOMELESS_SLOT = 38;
    public static final int GRASSIFICATION_SLOT = 42;
    public static final int BACK_SLOT = 45;

    public static final Component TITLE = Component.text("\uE010\uE011")
            .color(NamedTextColor.WHITE)
            .font(Key.key("gevent_clicker", "dirtyfybg"));

    private DirtyfyUpgradeGui() {
    }

    public static Inventory create(DirtyfyUpgradeHolder holder, DirtyfyUpgradeManager.State state) {
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.setInventory(inventory);

        inventory.setItem(BASE_DIRT_BOOSTER_SLOT, buildBaseDirtBoosterItem(state.baseDirtBoosterLevel));
        inventory.setItem(GRASS_BASE_BOOSTER_SLOT, buildGrassBaseBoosterItem(state.grassBaseBoosterLevel));
        inventory.setItem(MARDI_GRASS_SLOT, buildMardiGrassItem(state.mardiGrassLevel));
        inventory.setItem(EXPERIENCE_AUTOBUYER_SLOT, buildExperienceAutobuyerItem(state.experienceAutobuyerBought));
        inventory.setItem(CHAGRASS_SLOT, buildChagrassItem(state.chagrassLevel));
        inventory.setItem(FENETRE_XP_SLOT, buildFenetreXpItem(state.fenetreXpBought));
        inventory.setItem(XP_FOR_HOMELESS_SLOT, buildXpForHomelessItem(state.xpForHomelessLevel));
        inventory.setItem(GRASSIFICATION_SLOT, buildGrassificationItem(state.grassificationBought));
        inventory.setItem(BACK_SLOT, buildBackItem());

        return inventory;
    }

    public static ItemStack buildBaseDirtBoosterItem(int level) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Base Dirt Booster", NumberFormatting.DIRT_COLOR, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + level + " / " + DirtyfyUpgradeManager.BASE_DIRT_BOOSTER_MAX,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+" + NumberFormatting.money(DirtyfyUpgradePricing.BOOSTER_BONUS_PER_LEVEL)
                        + " de BASE au clic par niveau", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("(les autres multiplicateurs s'appliquent", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("par-dessus ce bonus de base)", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        long price = DirtyfyUpgradePricing.baseDirtBoosterPrice(level);
        appendPriceLines(lore, price);
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_base_dirt_booster"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildGrassBaseBoosterItem(int level) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Grass Base Booster", NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + level + " / " + DirtyfyUpgradeManager.GRASS_BOOSTER_MAX,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("+" + String.format(Locale.US, "%.1f", DirtyfyUpgradePricing.GRASS_BOOSTER_BONUS_PER_LEVEL)
                        + " Grass de BASE par Dirtyfy, par niveau", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("(les autres multiplicateurs s'appliquent", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("par-dessus ce bonus de base)", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        long price = DirtyfyUpgradePricing.grassBaseBoosterPrice(level);
        appendPriceLines(lore, price);
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_grass_base_booster"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildMardiGrassItem(int level) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Mardi Grass", NamedTextColor.GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + level + " / " + DirtyfyUpgradeManager.MARDI_GRASS_MAX,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        String currentMult = String.format(Locale.US, "x%.1f", DirtyfyUpgradePricing.mardiGrassMultiplier(level));
        lore.add(Component.text("Multiplicateur de Grass actuel : " + currentMult, NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        if (level < DirtyfyUpgradeManager.MARDI_GRASS_MAX) {
            String nextMult = String.format(Locale.US, "x%.1f", DirtyfyUpgradePricing.mardiGrassMultiplier(level + 1));
            lore.add(Component.text("Niveau suivant : " + nextMult, NamedTextColor.DARK_GREEN)
                    .decoration(TextDecoration.ITALIC, false));
        }

        long price = DirtyfyUpgradePricing.mardiGrassPrice(level);
        appendPriceLines(lore, price);
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_mardi_grass"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack buildExperienceAutobuyerItem(boolean bought) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Experience Autobuyer", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Achat unique.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Permet d'activer l'achat automatique", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("de la fiole d'xp (via Automater Settings).", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        if (bought) {
            lore.add(Component.text("Acheté", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Non acheté", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Prix : " + DirtyfyUpgradePricing.EXPERIENCE_AUTOBUYER_PRICE + " Grass",
                            NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_experience_autobuyer"));
        meta.setCustomModelDataComponent(cmd);

        if (bought) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    /** "Ouverture de Chagrass" : x2 cumulatif au Grass gagné par Dirtyfy, 3 achats à prix fixes. */
    public static ItemStack buildChagrassItem(int level) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Ouverture de Chagrass", NamedTextColor.DARK_GREEN, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + level + " / " + DirtyfyUpgradeManager.CHAGRASS_MAX,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        String currentMult = String.format(Locale.US, "x%.0f", DirtyfyUpgradePricing.chagrassMultiplier(level));
        lore.add(Component.text("Multiplicateur de Grass (Dirtyfy) actuel : " + currentMult, NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, false));
        if (level < DirtyfyUpgradeManager.CHAGRASS_MAX) {
            String nextMult = String.format(Locale.US, "x%.0f", DirtyfyUpgradePricing.chagrassMultiplier(level + 1));
            lore.add(Component.text("Niveau suivant : " + nextMult, NamedTextColor.DARK_GREEN)
                    .decoration(TextDecoration.ITALIC, false));
        }

        long price = DirtyfyUpgradePricing.chagrassPrice(level);
        appendPriceLines(lore, price);
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_chagrass"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    /** "Fenêtre XP" : achat unique, x1.5 EN PLUS du bonus de niveau d'xp déjà appliqué au Dirt. */
    public static ItemStack buildFenetreXpItem(boolean bought) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Fenêtre XP", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Achat unique.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Ajoute un x" + DirtyfyUpgradePricing.FENETRE_XP_MULTIPLIER
                        + " EN PLUS du bonus de niveau d'xp", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("déjà appliqué au gain de Dirt.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        if (bought) {
            lore.add(Component.text("Acheté", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Non acheté", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Prix : " + DirtyfyUpgradePricing.FENETRE_XP_PRICE + " Grass",
                            NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_fenetre_xp"));
        meta.setCustomModelDataComponent(cmd);

        if (bought) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    /** "XP for homeless" : génère de l'xp passive/sec, 10 niveaux. */
    public static ItemStack buildXpForHomelessItem(int level) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("XP for homeless", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Niveau : " + level + " / " + DirtyfyUpgradeManager.XP_FOR_HOMELESS_MAX,
                        NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        String currentRate = String.format(Locale.US, "%.0f", DirtyfyUpgradePricing.xpForHomelessRate(level));
        lore.add(Component.text("Xp passive actuelle : " + currentRate + "/sec", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        if (level < DirtyfyUpgradeManager.XP_FOR_HOMELESS_MAX) {
            String nextRate = String.format(Locale.US, "%.0f", DirtyfyUpgradePricing.xpForHomelessRate(level + 1));
            lore.add(Component.text("Niveau suivant : " + nextRate + "/sec", NamedTextColor.DARK_AQUA)
                    .decoration(TextDecoration.ITALIC, false));
        }

        long price = DirtyfyUpgradePricing.xpForHomelessPrice(level);
        appendPriceLines(lore, price);
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_xp_for_homeless"));
        meta.setCustomModelDataComponent(cmd);
        item.setItemMeta(meta);
        return item;
    }

    /** "Grassification" : dernière amélioration de ce menu, achat unique, débloque le Shovel Coin. */
    public static ItemStack buildGrassificationItem(boolean bought) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Grassification", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Achat unique. Dernière amélioration", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("de ce menu.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Débloque le \"Shovel Coin\", un trophée", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("permanent dans ton inventaire.", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));

        if (bought) {
            lore.add(Component.text("Acheté", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Non acheté", NamedTextColor.RED, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Prix : " + DirtyfyUpgradePricing.GRASSIFICATION_PRICE + " Grass",
                            NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_grassification"));
        meta.setCustomModelDataComponent(cmd);

        if (bought) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    /** Bouton retour au Clicker, identique (texture/emplacement) à celui de Strong Upgrades. */
    public static ItemStack buildBackItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Retour", NamedTextColor.WHITE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Clique pour revenir au Clicker", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));

        CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
        cmd.setStrings(List.of("gevent_back_arrow"));
        meta.setCustomModelDataComponent(cmd);

        item.setItemMeta(meta);
        return item;
    }

    private static void appendPriceLines(List<Component> lore, long price) {
        if (price < 0) {
            lore.add(Component.text("Amélioration maximale atteinte !", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            lore.add(Component.text("Prix prochain niveau : " + price + " Grass", NamedTextColor.GREEN)
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Clique pour acheter", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
    }
}
