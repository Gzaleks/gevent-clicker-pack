package fr.geven.clicker.gui;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.UUID;

/** Gère le clic de bascule (activer/désactiver) sur les automatisations de Automater Settings. */
public class AutomaterSettingsGuiListener implements Listener {

    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public AutomaterSettingsGuiListener(DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof AutomaterSettingsHolder)) {
            return;
        }
        event.setCancelled(true);

        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof AutomaterSettingsHolder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getSlot();
        if (slot != AutomaterSettingsGui.EXPERIENCE_AUTOBUYER_SLOT) {
            return;
        }

        UUID uuid = player.getUniqueId();
        boolean nowEnabled = dirtyfyUpgradeManager.toggleExperienceAutobuyer(uuid);
        dirtyfyUpgradeManager.saveAsync();

        event.getClickedInventory().setItem(slot, AutomaterSettingsGui.buildToggleItem(nowEnabled));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, nowEnabled ? 1.4f : 0.8f);
        player.sendActionBar(Component.text(
                "Experience Autobuyer " + (nowEnabled ? "activé" : "désactivé") + " !",
                nowEnabled ? NamedTextColor.GREEN : NamedTextColor.RED));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof AutomaterSettingsHolder) {
            event.setCancelled(true);
        }
    }
}
