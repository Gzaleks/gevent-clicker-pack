package fr.geven.clicker.gui;

import fr.geven.clicker.data.EcusManager;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.world.PotatoFarmManager;
import fr.geven.clicker.world.VoidComposterManager;
import fr.geven.clicker.world.WheatFarmManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Gère les clics dans les interfaces du PNJ "Farm Buyer" (vente de blé) : l'écran principal
 *  et l'écran de choix de quantité. */
public class SellGuiListener implements Listener {

    private final EcusManager ecusManager;
    private final WheatFarmManager farmManager;
    private final PotatoFarmManager potatoFarmManager;
    private final VoidComposterManager voidComposterManager;
    private final FricScoreboardManager scoreboardManager;
    /** Quantité présélectionnée par joueur (session en mémoire uniquement, 1 par défaut). */
    private final Map<UUID, Long> selectedAmount = new ConcurrentHashMap<>();

    public SellGuiListener(EcusManager ecusManager, WheatFarmManager farmManager, PotatoFarmManager potatoFarmManager,
                            VoidComposterManager voidComposterManager, FricScoreboardManager scoreboardManager) {
        this.ecusManager = ecusManager;
        this.farmManager = farmManager;
        this.potatoFarmManager = potatoFarmManager;
        this.voidComposterManager = voidComposterManager;
        this.scoreboardManager = scoreboardManager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof SellHolder) {
            handleMainClick(event);
        } else if (event.getInventory().getHolder() instanceof SellQuantityHolder) {
            handleQuantityClick(event);
        }
    }

    private void handleMainClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot == SellGui.WHEAT_SLOT) {
            handleWheatClick(event, player);
        } else if (slot == SellGui.POTATO_SLOT && voidComposterManager.getTier() >= 2 && event.isRightClick()) {
            long sold = potatoFarmManager.sellPotato(player.getUniqueId(), potatoFarmManager.getPotatoCount(), ecusManager);
            if (sold > 0) {
                player.sendMessage(Component.text("Vendu " + sold + " patate(s) pour "
                        + (sold * potatoFarmManager.getSellPricePerUnit()) + " Ecus.", NamedTextColor.GREEN));
                event.getInventory().setItem(SellGui.POTATO_SLOT, SellGui.buildPotatoItem(potatoFarmManager));
                scoreboardManager.updateEcus(player, ecusManager.getEcus(player.getUniqueId()));
            } else {
                player.sendMessage(Component.text("Tu n'as pas de patate à vendre.", NamedTextColor.RED));
            }
        }
    }

    private void handleWheatClick(InventoryClickEvent event, Player player) {
        if (event.isRightClick()) {
            long sold = farmManager.sellWheat(player.getUniqueId(), farmManager.getWheatCount(), ecusManager);
            if (sold > 0) {
                player.sendMessage(Component.text("Vendu " + sold + " blé pour " + (sold * farmManager.getSellPricePerUnit())
                        + " Ecus.", NamedTextColor.GREEN));
                event.getInventory().setItem(SellGui.WHEAT_SLOT, SellGui.buildWheatItem(farmManager));
                scoreboardManager.updateEcus(player, ecusManager.getEcus(player.getUniqueId()));
            } else {
                player.sendMessage(Component.text("Tu n'as pas de blé à vendre.", NamedTextColor.RED));
            }
        } else if (event.isLeftClick()) {
            selectedAmount.putIfAbsent(player.getUniqueId(), 1L);
            SellQuantityHolder holder = new SellQuantityHolder();
            player.openInventory(SellQuantityGui.create(holder, farmManager, selectedAmount.get(player.getUniqueId())));
        }
    }

    private void handleQuantityClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        int slot = event.getRawSlot();

        if (slot == SellQuantityGui.BUTTON_1_SLOT) {
            selectedAmount.put(uuid, 1L);
            refreshQuantityGui(event, player);
        } else if (slot == SellQuantityGui.BUTTON_10_SLOT) {
            selectedAmount.put(uuid, 10L);
            refreshQuantityGui(event, player);
        } else if (slot == SellQuantityGui.BUTTON_100_SLOT) {
            selectedAmount.put(uuid, 100L);
            refreshQuantityGui(event, player);
        } else if (slot == SellQuantityGui.SELL_SLOT) {
            long amount = selectedAmount.getOrDefault(uuid, 1L);
            long sold = farmManager.sellWheat(uuid, amount, ecusManager);
            if (sold > 0) {
                player.sendMessage(Component.text("Vendu " + sold + " blé pour " + (sold * farmManager.getSellPricePerUnit())
                        + " Ecus.", NamedTextColor.GREEN));
                scoreboardManager.updateEcus(player, ecusManager.getEcus(uuid));
            } else {
                player.sendMessage(Component.text("Tu n'as pas de blé à vendre.", NamedTextColor.RED));
            }
            player.closeInventory();
        } else if (slot == SellQuantityGui.BACK_SLOT) {
            SellHolder holder = new SellHolder();
            player.openInventory(SellGui.create(holder, farmManager, potatoFarmManager, voidComposterManager.getTier() >= 2));
        }
    }

    private void refreshQuantityGui(InventoryClickEvent event, Player player) {
        event.getInventory().setItem(SellQuantityGui.INFO_SLOT,
                SellQuantityGui.buildInfoItem(farmManager, selectedAmount.get(player.getUniqueId())));
    }
}
