package fr.geven.clicker.data;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère les Ecus (monnaie du clicker houe, gevent_clicker_world) de chaque joueur.
 * Même schéma de stockage que PlayerDataManager (Fric), fichier séparé : ecusdata.yml.
 */
public class EcusManager {

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, Long> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public EcusManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "ecusdata.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                cache.put(UUID.fromString(key), config.getLong(key, 0L));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans ecusdata.yml : " + key);
            }
        }
    }

    public long getEcus(UUID uuid) {
        return cache.getOrDefault(uuid, 0L);
    }

    public long addEcus(UUID uuid, long amount) {
        long newValue = cache.merge(uuid, amount, Long::sum);
        dirty = true;
        return newValue;
    }

    /** Retire le montant si le joueur en a assez, retourne true si la transaction a réussi. */
    public boolean tryRemoveEcus(UUID uuid, long amount) {
        long current = getEcus(uuid);
        if (current < amount) {
            return false;
        }
        cache.put(uuid, current - amount);
        dirty = true;
        return true;
    }

    public void resetEcus(UUID uuid) {
        cache.put(uuid, 0L);
        dirty = true;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder ecusdata.yml", ex);
        }
    }
}
