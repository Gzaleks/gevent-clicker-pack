package fr.geven.clicker.data;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère le stockage du "Grass" de chaque joueur — la ressource de prestige obtenue en
 * effectuant un Dirtyfy. Contrairement au Dirt/xp/améliorations, le Grass N'EST PAS remis à
 * zéro par un Dirtyfy (c'est justement ce qu'il rapporte) ; il l'est uniquement par un
 * /cl reset complet (pour les tests admin).
 */
public class GrassManager {

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, Double> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public GrassManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playergrass.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                cache.put(uuid, config.getDouble(key, 0.0));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans playergrass.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " joueur(s) chargé(s) (grass).");
    }

    public double getGrass(UUID uuid) {
        return cache.getOrDefault(uuid, 0.0);
    }

    public double addGrass(UUID uuid, double amount) {
        double newValue = cache.merge(uuid, amount, Double::sum);
        newValue = Math.round(newValue * 1000.0) / 1000.0;
        cache.put(uuid, newValue);
        dirty = true;
        return newValue;
    }

    public void resetGrass(UUID uuid) {
        cache.put(uuid, 0.0);
        dirty = true;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder playergrass.yml", ex);
        }
    }
}
