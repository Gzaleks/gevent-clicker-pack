package fr.geven.clicker.data;

import fr.geven.clicker.upgrade.ShovelTier;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère toute la progression de l'amélioration "Clicker Upgrader" par joueur :
 *  - déblocage de la pelle (une fois $1 possédé)
 *  - tier actuel (1 = bois, 2 = pierre, ...)
 *  - nombre d'achats dans le tier actuel
 *  - déblocage de la fiole d'xp (une fois le tier 2 atteint)
 *
 * Cache mémoire + fichier plugins/Gevent_Clicker/playerupgrades.yml (structure imbriquée
 * par UUID, plutôt qu'une valeur plate comme les autres managers).
 */
public class UpgradeManager {

    /** État complet de la progression "Clicker Upgrader" d'un joueur. */
    public static class ShovelState {
        public boolean unlocked = false;
        public int tier = 1;
        public int purchases = 0;
        public boolean bottleUnlocked = false;
        public int bottlePurchases = 0;
        public boolean strongUpgradeUnlocked = false;
        public boolean fricX2Bought = false;
        public boolean xpX2Bought = false;
        public boolean betterShovelBought = false;
        public boolean betterExperienceBought = false;
        public boolean fricX2_5Bought = false;
        public boolean xpX2_5Bought = false;
        public boolean autoDirtingBought = false;
        public boolean autoDirtingMoreInfoBought = false;
        public boolean moreAutoDirtBought = false;
        /** Débloqué dans l'interface Clicker (slot sous Strong Upgrade) une fois Auto Dirting acheté. */
        public boolean autoDirtingSlotUnlocked = false;
        /** Nombre de Dirtyfy effectués (prestige). Jamais réinitialisé par un Dirtyfy lui-même. */
        public int dirtyfyCount = 0;

        // --- Flags "découverte" pour l'interface Informations : passent à true une fois pour
        // toutes à la première apparition de la feature, et ne sont JAMAIS réinitialisés par un
        // Dirtyfy (contrairement à unlocked/bottleUnlocked/...) — seul /cl reset les efface.
        public boolean infoDiscoveredShovel = false;
        public boolean infoDiscoveredBottle = false;
        public boolean infoDiscoveredStrongUpgrade = false;
        public boolean infoDiscoveredAutoDirting = false;
        public boolean infoDiscoveredDirtyfyUpgrades = false;

        ShovelState copy() {
            ShovelState s = new ShovelState();
            s.unlocked = unlocked;
            s.tier = tier;
            s.purchases = purchases;
            s.bottleUnlocked = bottleUnlocked;
            s.bottlePurchases = bottlePurchases;
            s.strongUpgradeUnlocked = strongUpgradeUnlocked;
            s.fricX2Bought = fricX2Bought;
            s.xpX2Bought = xpX2Bought;
            s.betterShovelBought = betterShovelBought;
            s.betterExperienceBought = betterExperienceBought;
            s.fricX2_5Bought = fricX2_5Bought;
            s.xpX2_5Bought = xpX2_5Bought;
            s.autoDirtingBought = autoDirtingBought;
            s.autoDirtingMoreInfoBought = autoDirtingMoreInfoBought;
            s.moreAutoDirtBought = moreAutoDirtBought;
            s.autoDirtingSlotUnlocked = autoDirtingSlotUnlocked;
            s.dirtyfyCount = dirtyfyCount;
            s.infoDiscoveredShovel = infoDiscoveredShovel;
            s.infoDiscoveredBottle = infoDiscoveredBottle;
            s.infoDiscoveredStrongUpgrade = infoDiscoveredStrongUpgrade;
            s.infoDiscoveredAutoDirting = infoDiscoveredAutoDirting;
            s.infoDiscoveredDirtyfyUpgrades = infoDiscoveredDirtyfyUpgrades;
            return s;
        }
    }

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, ShovelState> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public UpgradeManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playerupgrades.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                ShovelState state = new ShovelState();
                state.unlocked = config.getBoolean(key + ".unlocked", false);
                state.tier = config.getInt(key + ".tier", 1);
                state.purchases = config.getInt(key + ".purchases", 0);
                state.bottleUnlocked = config.getBoolean(key + ".bottleUnlocked", false);
                state.bottlePurchases = config.getInt(key + ".bottlePurchases", 0);
                state.strongUpgradeUnlocked = config.getBoolean(key + ".strongUpgradeUnlocked", false);
                state.fricX2Bought = config.getBoolean(key + ".fricX2Bought", false);
                state.xpX2Bought = config.getBoolean(key + ".xpX2Bought", false);
                state.betterShovelBought = config.getBoolean(key + ".betterShovelBought", false);
                state.betterExperienceBought = config.getBoolean(key + ".betterExperienceBought", false);
                state.fricX2_5Bought = config.getBoolean(key + ".fricX2_5Bought", false);
                state.xpX2_5Bought = config.getBoolean(key + ".xpX2_5Bought", false);
                state.autoDirtingBought = config.getBoolean(key + ".autoDirtingBought", false);
                state.autoDirtingMoreInfoBought = config.getBoolean(key + ".autoDirtingMoreInfoBought", false);
                state.moreAutoDirtBought = config.getBoolean(key + ".moreAutoDirtBought", false);
                state.autoDirtingSlotUnlocked = config.getBoolean(key + ".autoDirtingSlotUnlocked", false);
                state.dirtyfyCount = config.getInt(key + ".dirtyfyCount", 0);
                state.infoDiscoveredShovel = config.getBoolean(key + ".infoDiscoveredShovel", false);
                state.infoDiscoveredBottle = config.getBoolean(key + ".infoDiscoveredBottle", false);
                state.infoDiscoveredStrongUpgrade = config.getBoolean(key + ".infoDiscoveredStrongUpgrade", false);
                state.infoDiscoveredAutoDirting = config.getBoolean(key + ".infoDiscoveredAutoDirting", false);
                state.infoDiscoveredDirtyfyUpgrades = config.getBoolean(key + ".infoDiscoveredDirtyfyUpgrades", false);
                cache.put(uuid, state);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans playerupgrades.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " joueur(s) chargé(s) (upgrades).");
    }

    /** Récupère (en la créant si besoin) l'état de progression d'un joueur. Ne pas muter directement. */
    public ShovelState getState(UUID uuid) {
        return cache.computeIfAbsent(uuid, u -> new ShovelState());
    }

    public boolean isShovelUnlocked(UUID uuid) {
        return getState(uuid).unlocked;
    }

    public int getTier(UUID uuid) {
        return getState(uuid).tier;
    }

    /** Tier actuel de la pelle, sous forme d'enum (pratique pour le GUI). */
    public fr.geven.clicker.upgrade.ShovelTier getShovelTier(UUID uuid) {
        return fr.geven.clicker.upgrade.ShovelTier.fromInt(getState(uuid).tier);
    }

    public int getPurchases(UUID uuid) {
        return getState(uuid).purchases;
    }

    public boolean isBottleUnlocked(UUID uuid) {
        return getState(uuid).bottleUnlocked;
    }

    public boolean isStrongUpgradeUnlocked(UUID uuid) {
        return getState(uuid).strongUpgradeUnlocked;
    }

    /** Débloque définitivement l'item "Strong Upgrade" pour ce joueur. */
    public void unlockStrongUpgrade(UUID uuid) {
        ShovelState s = getState(uuid);
        s.strongUpgradeUnlocked = true;
        s.infoDiscoveredStrongUpgrade = true;
        dirty = true;
    }

    public fr.geven.clicker.upgrade.StrongUpgrades getStrongUpgrades(UUID uuid) {
        ShovelState s = getState(uuid);
        return new fr.geven.clicker.upgrade.StrongUpgrades(
                s.fricX2Bought, s.xpX2Bought, s.betterShovelBought, s.betterExperienceBought,
                s.fricX2_5Bought, s.xpX2_5Bought, s.autoDirtingBought,
                s.autoDirtingMoreInfoBought, s.moreAutoDirtBought);
    }

    public void buyFricX2(UUID uuid) {
        getState(uuid).fricX2Bought = true;
        dirty = true;
    }

    public void buyXpX2(UUID uuid) {
        getState(uuid).xpX2Bought = true;
        dirty = true;
    }

    public void buyBetterShovel(UUID uuid) {
        getState(uuid).betterShovelBought = true;
        dirty = true;
    }

    public void buyBetterExperience(UUID uuid) {
        getState(uuid).betterExperienceBought = true;
        dirty = true;
    }

    public void buyFricX2_5(UUID uuid) {
        getState(uuid).fricX2_5Bought = true;
        dirty = true;
    }

    public void buyXpX2_5(UUID uuid) {
        getState(uuid).xpX2_5Bought = true;
        dirty = true;
    }

    public void buyAutoDirting(UUID uuid) {
        ShovelState s = getState(uuid);
        s.autoDirtingBought = true;
        s.infoDiscoveredAutoDirting = true;
        dirty = true;
    }

    public void buyAutoDirtingMoreInfo(UUID uuid) {
        getState(uuid).autoDirtingMoreInfoBought = true;
        dirty = true;
    }

    public void buyMoreAutoDirt(UUID uuid) {
        getState(uuid).moreAutoDirtBought = true;
        dirty = true;
    }

    public int getBottlePurchases(UUID uuid) {
        return getState(uuid).bottlePurchases;
    }

    /** Incrémente le nombre d'achats de la fiole (clampé à 1000) et retourne le nouveau total. */
    public int addBottlePurchase(UUID uuid) {
        ShovelState state = getState(uuid);
        state.bottlePurchases = Math.min(fr.geven.clicker.upgrade.BottleUpgrade.MAX_PURCHASES, state.bottlePurchases + 1);
        dirty = true;
        return state.bottlePurchases;
    }

    /** Débloque définitivement la pelle (tier 1) pour ce joueur. */
    public void unlockShovel(UUID uuid) {
        ShovelState s = getState(uuid);
        s.unlocked = true;
        s.infoDiscoveredShovel = true;
        dirty = true;
    }

    /** Incrémente le nombre d'achats du tier actuel (clampé au max de ce tier) et retourne le nouveau total. */
    public int addPurchase(UUID uuid) {
        ShovelState state = getState(uuid);
        int max = ShovelTier.fromInt(state.tier).maxPurchases;
        state.purchases = Math.min(max, state.purchases + 1);
        dirty = true;
        return state.purchases;
    }

    /** Fait passer la pelle au tier suivant et remet le compteur d'achats à 0 pour ce nouveau tier. */
    public void upgradeTier(UUID uuid) {
        ShovelState state = getState(uuid);
        state.tier += 1;
        state.purchases = 0;
        dirty = true;
    }

    /** Débloque définitivement la fiole d'xp pour ce joueur. */
    public void unlockBottle(UUID uuid) {
        ShovelState s = getState(uuid);
        s.bottleUnlocked = true;
        s.infoDiscoveredBottle = true;
        dirty = true;
    }

    /** Remet toute la progression "Clicker Upgrader" à zéro (utilisé par /cl reset). */
    public void resetAll(UUID uuid) {
        cache.put(uuid, new ShovelState());
        dirty = true;
    }

    public int getDirtyfyCount(UUID uuid) {
        return getState(uuid).dirtyfyCount;
    }

    /**
     * Effectue un Dirtyfy : remet TOUTE la progression "Clicker Upgrader" à zéro (comme
     * resetAll), sauf le compteur de Dirtyfy lui-même, qui est incrémenté. Le Dirt et l'xp
     * (gérés par d'autres managers) doivent être remis à zéro séparément par l'appelant.
     */
    public void performDirtyfy(UUID uuid) {
        ShovelState old = getState(uuid);
        ShovelState fresh = new ShovelState();
        fresh.dirtyfyCount = old.dirtyfyCount + 1;
        // Les flags "découverte" de l'interface Informations survivent au Dirtyfy (seul /cl reset
        // les efface) — contrairement au reste de la progression Dirt, qui repart de zéro.
        fresh.infoDiscoveredShovel = old.infoDiscoveredShovel;
        fresh.infoDiscoveredBottle = old.infoDiscoveredBottle;
        fresh.infoDiscoveredStrongUpgrade = old.infoDiscoveredStrongUpgrade;
        fresh.infoDiscoveredAutoDirting = old.infoDiscoveredAutoDirting;
        fresh.infoDiscoveredDirtyfyUpgrades = true;
        cache.put(uuid, fresh);
        dirty = true;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            String key = entry.getKey().toString();
            ShovelState state = entry.getValue();
            config.set(key + ".unlocked", state.unlocked);
            config.set(key + ".tier", state.tier);
            config.set(key + ".purchases", state.purchases);
            config.set(key + ".bottleUnlocked", state.bottleUnlocked);
            config.set(key + ".bottlePurchases", state.bottlePurchases);
            config.set(key + ".strongUpgradeUnlocked", state.strongUpgradeUnlocked);
            config.set(key + ".fricX2Bought", state.fricX2Bought);
            config.set(key + ".xpX2Bought", state.xpX2Bought);
            config.set(key + ".betterShovelBought", state.betterShovelBought);
            config.set(key + ".betterExperienceBought", state.betterExperienceBought);
            config.set(key + ".fricX2_5Bought", state.fricX2_5Bought);
            config.set(key + ".xpX2_5Bought", state.xpX2_5Bought);
            config.set(key + ".autoDirtingBought", state.autoDirtingBought);
            config.set(key + ".autoDirtingMoreInfoBought", state.autoDirtingMoreInfoBought);
            config.set(key + ".moreAutoDirtBought", state.moreAutoDirtBought);
            config.set(key + ".autoDirtingSlotUnlocked", state.autoDirtingSlotUnlocked);
            config.set(key + ".dirtyfyCount", state.dirtyfyCount);
            config.set(key + ".infoDiscoveredShovel", state.infoDiscoveredShovel);
            config.set(key + ".infoDiscoveredBottle", state.infoDiscoveredBottle);
            config.set(key + ".infoDiscoveredStrongUpgrade", state.infoDiscoveredStrongUpgrade);
            config.set(key + ".infoDiscoveredAutoDirting", state.infoDiscoveredAutoDirting);
            config.set(key + ".infoDiscoveredDirtyfyUpgrades", state.infoDiscoveredDirtyfyUpgrades);
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder playerupgrades.yml", ex);
        }
    }
}
