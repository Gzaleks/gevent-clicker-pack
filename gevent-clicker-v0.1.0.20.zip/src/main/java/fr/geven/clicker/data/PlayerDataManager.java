package fr.geven.clicker.data;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère le stockage du "Fric" de chaque joueur.
 * - Les valeurs sont gardées en cache mémoire (accès instantané pour le GUI / scoreboard)
 * - Elles sont persistées dans plugins/Gevent_Clicker/playerdata.yml
 */
public class PlayerDataManager {

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, Double> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public PlayerDataManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playerdata.yml");
    }

    /** Charge les données depuis le disque (à appeler dans onEnable). */
    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return; // Rien à charger, cache reste vide
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                double fric = config.getDouble(key, 0.0);
                cache.put(uuid, fric);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans playerdata.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " joueur(s) chargé(s).");
    }

    /** Récupère le Fric actuel d'un joueur (0.0 si inconnu). */
    public double getFric(UUID uuid) {
        return cache.getOrDefault(uuid, 0.0);
    }

    /**
     * Ajoute un montant au Fric d'un joueur et retourne le nouveau total.
     * Marque les données comme "à sauvegarder".
     */
    public double addFric(UUID uuid, double amount) {
        double newValue = cache.merge(uuid, amount, Double::sum);
        // Arrondi pour éviter les erreurs de virgule flottante (ex: 0.1 + 0.1 = 0.20000000000000004)
        newValue = Math.round(newValue * 1000.0) / 1000.0;
        cache.put(uuid, newValue);
        dirty = true;
        return newValue;
    }

    /** Remet le Fric à zéro pour ce joueur (utilisé par /cl reset). */
    public void resetFric(UUID uuid) {
        cache.put(uuid, 0.0);
        dirty = true;
    }

    /** Sauvegarde de façon asynchrone (à utiliser pendant que le serveur tourne). */
    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    /** Sauvegarde synchrone (à utiliser dans onDisable, où le scheduler async n'est plus fiable). */
    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder playerdata.yml", ex);
        }
    }
}
