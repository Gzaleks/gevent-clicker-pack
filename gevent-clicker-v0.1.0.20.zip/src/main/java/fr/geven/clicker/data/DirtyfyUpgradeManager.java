package fr.geven.clicker.data;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère les améliorations de l'interface "Dirtyfy Upgrades" (Base Dirt Booster, Mardi Grass,
 * Experience Autobuyer, et l'état d'activation de l'Automater Settings). Contrairement à la
 * progression normale (pelle, Strong Upgrades...), RIEN ici n'est remis à zéro par un
 * Dirtyfy — seul un /cl reset complet le fait.
 */
public class DirtyfyUpgradeManager {

    public static final int BASE_DIRT_BOOSTER_MAX = 10;
    public static final int MARDI_GRASS_MAX = 50;
    public static final int CHAGRASS_MAX = 3;
    public static final int XP_FOR_HOMELESS_MAX = 10;
    public static final int GRASS_BOOSTER_MAX = 10;

    public static class State {
        public int baseDirtBoosterLevel = 0;
        public int mardiGrassLevel = 0;
        public boolean experienceAutobuyerBought = false;
        public boolean experienceAutobuyerEnabled = false;
        public int chagrassLevel = 0;
        public boolean fenetreXpBought = false;
        public int xpForHomelessLevel = 0;
        public boolean grassificationBought = false;
        public int grassBaseBoosterLevel = 0;
    }

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, State> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public DirtyfyUpgradeManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "dirtyfyupgrades.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                State state = new State();
                state.baseDirtBoosterLevel = config.getInt(key + ".baseDirtBoosterLevel", 0);
                state.mardiGrassLevel = config.getInt(key + ".mardiGrassLevel", 0);
                state.experienceAutobuyerBought = config.getBoolean(key + ".experienceAutobuyerBought", false);
                state.experienceAutobuyerEnabled = config.getBoolean(key + ".experienceAutobuyerEnabled", false);
                state.chagrassLevel = config.getInt(key + ".chagrassLevel", 0);
                state.fenetreXpBought = config.getBoolean(key + ".fenetreXpBought", false);
                state.xpForHomelessLevel = config.getInt(key + ".xpForHomelessLevel", 0);
                state.grassificationBought = config.getBoolean(key + ".grassificationBought", false);
                state.grassBaseBoosterLevel = config.getInt(key + ".grassBaseBoosterLevel", 0);
                cache.put(uuid, state);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans dirtyfyupgrades.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " joueur(s) chargé(s) (dirtyfy upgrades).");
    }

    public State getState(UUID uuid) {
        return cache.computeIfAbsent(uuid, u -> new State());
    }

    public int addBaseDirtBoosterLevel(UUID uuid) {
        State s = getState(uuid);
        s.baseDirtBoosterLevel = Math.min(BASE_DIRT_BOOSTER_MAX, s.baseDirtBoosterLevel + 1);
        dirty = true;
        return s.baseDirtBoosterLevel;
    }

    public int addMardiGrassLevel(UUID uuid) {
        State s = getState(uuid);
        s.mardiGrassLevel = Math.min(MARDI_GRASS_MAX, s.mardiGrassLevel + 1);
        dirty = true;
        return s.mardiGrassLevel;
    }

    public void buyExperienceAutobuyer(UUID uuid) {
        getState(uuid).experienceAutobuyerBought = true;
        dirty = true;
    }

    public boolean toggleExperienceAutobuyer(UUID uuid) {
        State s = getState(uuid);
        s.experienceAutobuyerEnabled = !s.experienceAutobuyerEnabled;
        dirty = true;
        return s.experienceAutobuyerEnabled;
    }

    public int addChagrassLevel(UUID uuid) {
        State s = getState(uuid);
        s.chagrassLevel = Math.min(CHAGRASS_MAX, s.chagrassLevel + 1);
        dirty = true;
        return s.chagrassLevel;
    }

    public void buyFenetreXp(UUID uuid) {
        getState(uuid).fenetreXpBought = true;
        dirty = true;
    }

    public int addXpForHomelessLevel(UUID uuid) {
        State s = getState(uuid);
        s.xpForHomelessLevel = Math.min(XP_FOR_HOMELESS_MAX, s.xpForHomelessLevel + 1);
        dirty = true;
        return s.xpForHomelessLevel;
    }

    public int addGrassBaseBoosterLevel(UUID uuid) {
        State s = getState(uuid);
        s.grassBaseBoosterLevel = Math.min(GRASS_BOOSTER_MAX, s.grassBaseBoosterLevel + 1);
        dirty = true;
        return s.grassBaseBoosterLevel;
    }

    public void buyGrassification(UUID uuid) {
        getState(uuid).grassificationBought = true;
        dirty = true;
    }

    public void resetAll(UUID uuid) {
        cache.put(uuid, new State());
        dirty = true;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            String key = entry.getKey().toString();
            State s = entry.getValue();
            config.set(key + ".baseDirtBoosterLevel", s.baseDirtBoosterLevel);
            config.set(key + ".mardiGrassLevel", s.mardiGrassLevel);
            config.set(key + ".experienceAutobuyerBought", s.experienceAutobuyerBought);
            config.set(key + ".experienceAutobuyerEnabled", s.experienceAutobuyerEnabled);
            config.set(key + ".chagrassLevel", s.chagrassLevel);
            config.set(key + ".fenetreXpBought", s.fenetreXpBought);
            config.set(key + ".xpForHomelessLevel", s.xpForHomelessLevel);
            config.set(key + ".grassificationBought", s.grassificationBought);
            config.set(key + ".grassBaseBoosterLevel", s.grassBaseBoosterLevel);
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder dirtyfyupgrades.yml", ex);
        }
    }
}
