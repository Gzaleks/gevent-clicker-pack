package fr.geven.clicker.data;

import fr.geven.clicker.xp.LevelCurve;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gère le stockage de l'XP (custom, indépendante de l'xp vanille) de chaque joueur.
 * Même fonctionnement que PlayerDataManager (Fric) : cache mémoire + fichier yml.
 */
public class XpManager {

    private final JavaPlugin plugin;
    private final File dataFile;
    private final ConcurrentHashMap<UUID, Long> cache = new ConcurrentHashMap<>();
    private volatile boolean dirty = false;

    public XpManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "playerxp.yml");
    }

    public void load() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        if (!dataFile.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                long xp = config.getLong(key, 0L);
                cache.put(uuid, xp);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("UUID invalide dans playerxp.yml : " + key);
            }
        }
        plugin.getLogger().info("Gevent_Clicker : " + cache.size() + " joueur(s) chargé(s) (xp).");
    }

    public long getXp(UUID uuid) {
        return cache.getOrDefault(uuid, 0L);
    }

    public int getLevel(UUID uuid) {
        return LevelCurve.levelForXp(getXp(uuid));
    }

    /** Remet l'xp à zéro pour ce joueur (utilisé par /cl reset). */
    public void resetXp(UUID uuid) {
        cache.put(uuid, 0L);
        dirty = true;
    }

    /**
     * Ajoute (ou retire si négatif) de l'XP à un joueur, avec clamp entre 0 et le maximum
     * atteignable au niveau 1000. Retourne le nouveau total d'XP.
     */
    public long addXp(UUID uuid, long amount) {
        long current = cache.getOrDefault(uuid, 0L);
        long newValue = current + amount;
        newValue = Math.max(0L, Math.min(newValue, LevelCurve.MAX_TOTAL_XP));
        cache.put(uuid, newValue);
        dirty = true;
        return newValue;
    }

    public void saveAsync() {
        if (!dirty) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this::saveSync);
    }

    public synchronized void saveSync() {
        YamlConfiguration config = new YamlConfiguration();
        for (var entry : cache.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            config.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Impossible de sauvegarder playerxp.yml", ex);
        }
    }
}
