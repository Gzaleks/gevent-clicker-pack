package fr.geven.clicker.task;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.ClickerGui;
import fr.geven.clicker.gui.ClickerHolder;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.ShovelTier;
import fr.geven.clicker.upgrade.StrongUpgrades;
import fr.geven.clicker.xp.LevelCurve;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Ajoute le Dirt généré par "Auto Dirting" une fois par seconde (20 ticks), pour chaque joueur
 * qui l'a achetée. Additionnel aux clics réels du joueur, ne les remplace pas.
 *
 * Fréquence volontairement limitée à 1x/seconde : ajouter un double et rafraîchir un texte de
 * scoreboard/tooltip est une opération extrêmement légère, donc même la resserrer beaucoup
 * (par exemple 4x/seconde) resterait négligeable en performance pour un nombre de joueurs
 * raisonnable — la limite actuelle est un choix de lisibilité (le chiffre affiché ne "saute"
 * pas trop vite), pas une nécessité technique de performance.
 */
public class AutoDirtingTask extends BukkitRunnable {

    private final PlayerDataManager dataManager;
    private final UpgradeManager upgradeManager;
    private final XpManager xpManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final FricScoreboardManager scoreboardManager;

    public AutoDirtingTask(PlayerDataManager dataManager, UpgradeManager upgradeManager, XpManager xpManager,
                            DirtyfyUpgradeManager dirtyfyUpgradeManager, FricScoreboardManager scoreboardManager) {
        this.dataManager = dataManager;
        this.upgradeManager = upgradeManager;
        this.xpManager = xpManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.scoreboardManager = scoreboardManager;
    }

    @Override
    public void run() {
        for (Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);
            double rate = strongUpgrades.autoDirtingRatePerSecond();
            if (rate <= 0) continue;

            double newFric = dataManager.addFric(uuid, rate);
            scoreboardManager.updateFric(player, newFric);

            Inventory topInventory = player.getOpenInventory().getTopInventory();
            if (topInventory.getHolder() instanceof ClickerHolder) {
                refreshOpenClickerGui(player, uuid, topInventory, newFric, strongUpgrades);
            }
        }
        dataManager.saveAsync();
    }

    private void refreshOpenClickerGui(Player player, UUID uuid, Inventory inv, double fric,
                                        StrongUpgrades strongUpgrades) {
        long xp = xpManager.getXp(uuid);
        int xpLevel = LevelCurve.levelForXp(xp);
        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        ShovelTier tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        boolean bottleUnlocked = upgradeManager.isBottleUnlocked(uuid);
        int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
        int baseDirtBoosterLevel = dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel;
        boolean fenetreXpBought = dirtyfyUpgradeManager.getState(uuid).fenetreXpBought;

        inv.setItem(ClickerGui.DIRT_SLOT, ClickerGui.buildDirtItem(fric, xpLevel, shovelUnlocked, tier, purchases,
                bottleUnlocked, bottlePurchases, strongUpgrades, baseDirtBoosterLevel, fenetreXpBought));

        if (strongUpgrades.autoDirting()) {
            inv.setItem(ClickerGui.AUTO_DIRTING_SLOT,
                    ClickerGui.buildAutoDirtingItem(strongUpgrades, xpLevel, shovelUnlocked, tier, purchases));
        }
    }
}
