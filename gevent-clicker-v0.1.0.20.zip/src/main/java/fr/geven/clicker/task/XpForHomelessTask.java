package fr.geven.clicker.task;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.upgrade.DirtyfyUpgradePricing;
import fr.geven.clicker.xp.XpBarSync;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Ajoute l'xp passive de "XP for homeless" une fois par seconde (20 ticks), pour chaque joueur
 * ayant au moins un niveau de cette amélioration. Indépendant de la fiole/des clics.
 */
public class XpForHomelessTask extends BukkitRunnable {

    private final XpManager xpManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;

    public XpForHomelessTask(XpManager xpManager, DirtyfyUpgradeManager dirtyfyUpgradeManager) {
        this.xpManager = xpManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
    }

    @Override
    public void run() {
        boolean anyChange = false;
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            int level = dirtyfyUpgradeManager.getState(uuid).xpForHomelessLevel;
            if (level <= 0) continue;

            long rate = Math.round(DirtyfyUpgradePricing.xpForHomelessRate(level));
            if (rate <= 0) continue;

            long newXp = xpManager.addXp(uuid, rate);
            XpBarSync.sync(player, newXp);
            anyChange = true;
        }
        if (anyChange) {
            xpManager.saveAsync();
        }
    }
}
