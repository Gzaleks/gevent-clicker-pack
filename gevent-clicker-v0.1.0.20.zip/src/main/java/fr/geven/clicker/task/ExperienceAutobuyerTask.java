package fr.geven.clicker.task;

import fr.geven.clicker.data.DirtyfyUpgradeManager;
import fr.geven.clicker.data.PlayerDataManager;
import fr.geven.clicker.data.UpgradeManager;
import fr.geven.clicker.data.XpManager;
import fr.geven.clicker.gui.ClickerGui;
import fr.geven.clicker.gui.ClickerHolder;
import fr.geven.clicker.scoreboard.FricScoreboardManager;
import fr.geven.clicker.upgrade.BottleUpgrade;
import fr.geven.clicker.upgrade.StrongUpgrades;
import fr.geven.clicker.xp.XpBarSync;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Toutes les 2 secondes (40 ticks), achète automatiquement le prochain niveau de la fiole
 * d'xp pour chaque joueur ayant acheté ET activé l'Experience Autobuyer (via Automater
 * Settings), s'il a assez de Dirt et que la fiole est débloquée.
 */
public class ExperienceAutobuyerTask extends BukkitRunnable {

    private final PlayerDataManager dataManager;
    private final XpManager xpManager;
    private final UpgradeManager upgradeManager;
    private final DirtyfyUpgradeManager dirtyfyUpgradeManager;
    private final FricScoreboardManager scoreboardManager;

    public ExperienceAutobuyerTask(PlayerDataManager dataManager, XpManager xpManager, UpgradeManager upgradeManager,
                                    DirtyfyUpgradeManager dirtyfyUpgradeManager, FricScoreboardManager scoreboardManager) {
        this.dataManager = dataManager;
        this.xpManager = xpManager;
        this.upgradeManager = upgradeManager;
        this.dirtyfyUpgradeManager = dirtyfyUpgradeManager;
        this.scoreboardManager = scoreboardManager;
    }

    @Override
    public void run() {
        for (Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            DirtyfyUpgradeManager.State state = dirtyfyUpgradeManager.getState(uuid);
            if (!state.experienceAutobuyerBought || !state.experienceAutobuyerEnabled) continue;
            if (!upgradeManager.isBottleUnlocked(uuid)) continue;

            int bottlePurchases = upgradeManager.getBottlePurchases(uuid);
            if (bottlePurchases >= BottleUpgrade.MAX_PURCHASES) continue;

            long price = BottleUpgrade.priceForNextPurchase(bottlePurchases);
            double fric = dataManager.getFric(uuid);
            if (fric < price) continue;

            double newFric = dataManager.addFric(uuid, -price);
            int newBottlePurchases = upgradeManager.addBottlePurchase(uuid);
            dataManager.saveAsync();
            upgradeManager.saveAsync();
            scoreboardManager.updateFric(player, newFric);

            Inventory topInventory = player.getOpenInventory().getTopInventory();
            if (topInventory.getHolder() instanceof ClickerHolder) {
                refreshOpenClickerGui(player, uuid, topInventory, newFric, newBottlePurchases);
            }
        }
    }

    private void refreshOpenClickerGui(Player player, UUID uuid, Inventory inv, double fric, int bottlePurchases) {
        long xp = xpManager.getXp(uuid);
        StrongUpgrades strongUpgrades = upgradeManager.getStrongUpgrades(uuid);
        int xpLevel = xpManager.getLevel(uuid);
        boolean shovelUnlocked = upgradeManager.isShovelUnlocked(uuid);
        var tier = upgradeManager.getShovelTier(uuid);
        int purchases = upgradeManager.getPurchases(uuid);
        int baseDirtBoosterLevel = dirtyfyUpgradeManager.getState(uuid).baseDirtBoosterLevel;
        boolean fenetreXpBought = dirtyfyUpgradeManager.getState(uuid).fenetreXpBought;

        inv.setItem(ClickerGui.XP_BOTTLE_SLOT, ClickerGui.buildXpBottleItem(xp, bottlePurchases, strongUpgrades));
        inv.setItem(ClickerGui.DIRT_SLOT, ClickerGui.buildDirtItem(fric, xpLevel, shovelUnlocked, tier, purchases,
                true, bottlePurchases, strongUpgrades, baseDirtBoosterLevel, fenetreXpBought));
    }
}
