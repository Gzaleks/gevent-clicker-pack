# Gevent_Clicker

Plugin Paper pour Minecraft **26.2**. Version actuelle : **0.9.0**.

## Nouveautés 0.9.0

- **Nouvelle ressource "Grass"** : obtenue en effectuant un Dirtyfy (+1 par défaut, montant non
  précisé dans la demande). Symbole custom (petit bloc d'herbe) via le resource pack, vert clair.
  Persiste à travers les Dirtyfy (seul un `/cl reset` complet la remet à zéro).
  Nouvelle commande `/cl grass give/remove <pseudo> <nombre>` pour les tests, en plus.
- **Scoreboard entièrement retravaillé** :
  - Titre "Gevent Clicker" en vrai bouton doré (image custom bakée, pas juste du texte coloré).
  - Chiffres et ponctuation (0-9, `.` `,` `%` `:`) rendus avec une police custom plus fine que
    la police par défaut "cubique" — même principe que les badges du tab-list. Les mots restent
    en police normale (seuls les chiffres changent), via un nouvel utilitaire `ScoreboardFont`
    qui bascule automatiquement de police caractère par caractère.
  - Nouvelle ligne "Grass" avec son icône.

⚠️ Le montant de Grass gagné par Dirtyfy n'était pas précisé — $1 par défaut, facilement
ajustable (`GRASS_PER_DIRTYFY` dans `ClickerGuiListener`).

## Nouveautés 0.8.0

- **Corrections rapides** : Dirt x2,5 → $89 000, "clics simulés" retiré du tooltip Auto Dirting,
  `/sec` et `/min` partout, renommage complet "Strong Upgrade" → "Strong Upgrades" (y compris
  le titre baké dans le panneau).
- **Bug de sauvegarde corrigé** : plusieurs champs récents (Dirt x2,5, XP x2,5, tout l'Auto
  Dirting) n'étaient jamais écrits dans `playerupgrades.yml` — perte de données au redémarrage.
- **Pelle tier 5** : netherite, 100 achats, +$1.6/clic par achat, prix dès $2 avec croissance
  x1.17 (un peu plus dur que le tier 4), dernier achat ~$10 131 479.
- **Dirtyfy** (premier layer de prestige) : bloc 3x3 (9 slots cliquables, tous identiques)
  centré 2 lignes sous le bloc de terre, texture custom "trou noir avalant de la terre" en une
  seule image continue découpée en 9 tuiles. Apparaît en bedrock au tier 5, débloqué une fois
  ce tier maxé (100/100). Effectuer un Dirtyfy remet tout à zéro et débloque définitivement
  "Dirtyfy Upgrades".
- **Dirtyfy Upgrades** : nouveau slot au-dessus de Strong Upgrades, bedrock jusqu'au premier
  Dirtyfy. Sa propre interface à 6 lignes (couleur #BD6E60, même technique que les autres),
  vide pour l'instant.

⚠️ Comme pour Strong Upgrades à son lancement, l'interface Dirtyfy Upgrades est fonctionnelle
mais vide de contenu — prête à être remplie plus tard.

## Nouveautés 0.7.0

- **Interfaces revenues à l'image unique** (fini l'expérimentation de découpage, trop fragile).
- **Pelle tier 4** : diamant, 80 achats, +$0.8/clic par achat, prix dès $9 avec croissance x1.16
  (un peu plus dur que le tier 3), dernier achat ~$1 001 536.
- **"Auto Dirting"** : nouveau slot dans l'interface Clicker (juste sous "Strong Upgrade"), en
  bedrock dès le tier 4, débloqué en l'achetant dans Strong Upgrade ($100 001). Génère du Dirt
  passif chaque seconde (100/s de base), additionnel aux clics réels. Tâche planifiée dédiée
  (`AutoDirtingTask`), rafraîchit l'interface en direct si elle est ouverte.
- **5 nouvelles améliorations Strong Upgrade** (bedrock → débloquées au tier 4, ou après achat
  d'Auto Dirting pour les 2 dernières) :
  - Dirt x2,5 ($58 000) et XP x2,5 ($180 000) : cumulables avec les x2 existants (multiplication)
  - Auto Dirting ($100 001) : voir ci-dessus
  - Auto Dirting More Infos ($50 000, ⚠️ prix non précisé, proposé par défaut) : détaille le
    tooltip (clics simulés/s, Dirt/minute) — nécessite Auto Dirting acheté au préalable
  - More Auto Dirt ($120 000) : double la production d'Auto Dirting — nécessite Auto Dirting
    acheté au préalable
- **Textures Dirt x2,5 / XP x2,5** ajoutées (même style que les x2, 128×128).

⚠️ **Réponse à ta question sur le lag** : non, augmenter la fréquence de l'Auto Dirting (même
x10-x20) ne poserait pas de problème de performance — ajouter un nombre et rafraîchir un texte
est une opération négligeable. La limite à 1x/seconde actuelle est un choix de confort visuel
(éviter que le chiffre affiché "saute" trop vite), pas une nécessité technique.

⚠️ **Scope volontairement réduit sur 3 items** : "Auto Dirting", "Auto Dirting More Infos" et
"More Auto Dirt" n'ont pas de texture custom dédiée (aucune décrite dans la demande, contrairement
à Dirt x2,5/XP x2,5) — ils utilisent du papier vanilla par défaut pour l'instant. Dis-moi si tu
veux des icônes custom pour eux aussi.

## Nouveautés 0.6.0

- **Enclume retravaillée** : plateau bien plus large et allongé (inspiré de CurseForge), corne
  recalculée avec de vrais points d'ancrage sur les arêtes du plateau (elle était détachée
  avant, résolu).
- **Panneaux d'interface découpés en 4 morceaux** (grille 2x2) pour dépasser un peu la limite
  des 256px/glyphe : gain réel d'environ ×1,85 (196x242 natif -> ~181x248 par morceau en haut,
  ~181x200 en bas). Vérifié avant envoi : reconstruction locale des 4 morceaux, contrôle visuel
  de la couture centrale + comparaison pixel par pixel de part et d'autre (aucune différence
  détectée). Les deux interfaces (clicker et Strong Upgrade) utilisent cette même technique.

## Nouveautés 0.5.7 — correctif critique

- **Bug des interfaces cassées corrigé** : j'avais dépassé la limite dure de 256×256px par
  glyphe de police bitmap (découverte tôt dans ce projet) en voulant augmenter la résolution
  des panneaux à 1568×1936px. Résultat : police entière cassée silencieusement, interfaces
  entièrement vanilla. Revenu à la résolution native qui fonctionne (196×242, sous la limite).
  ⚠️ **Les panneaux d'interface ne peuvent pas recevoir le même traitement "haute résolution"
  que les items/badges** : ils sont déjà affichés à 242px de haut, très proche du plafond de
  256px — quasiment aucune marge de sur-échantillonnage possible pour cet asset précis.
- **`/cl fric` renommé en `/cl dirt`** (give/remove) — oubli corrigé.
- **Texture de l'enclume refaite** : l'ancien dessin avait des polygones mal ordonnés qui se
  chevauchaient (rendu cassé/glitché en jeu). Nouvelle version plus simple et robuste : empilage
  de blocs isométriques propres (socle, tronc, plateau, corne).

## Nouveautés 0.5.6

- **Pelle réalignée** : tête et manche calculés mathématiquement le long du même axe (plus de
  décalage visuel).
- **Enclume isométrique** : remplace le lingot de netherite pour le tier-up de la pelle. Item
  papier custom, enchanté (lueur, sans texte d'enchantement visible).
- **Résolution des interfaces mise à jour** : panneaux clicker et Strong Upgrade régénérés en
  8x leur taille affichée (comme les items/badges), au lieu d'être quasi 1:1 avec l'affichage.
- **Halos retirés** : pelle et fiole d'xp dans l'interface clicker affichent maintenant leur
  apparence normale, sans le halo coloré ajouté au tout début du projet.

## Nouveautés 0.5.3

- **Badges tab-list en bien plus haute résolution** : hauteur d'affichage passée de ~9-10px à
  **18px** (le double), avec le texte à nouveau "baked" dans l'image (comme demandé — la
  finesse voulue vient du nombre de pixels disponibles par lettre, pas de la technique de
  rendu). Toujours net, sans anti-aliasing (alpha seuillé en dur). Revenu à un seul glyphe par
  badge (plus simple, plus fiable que la superposition de texte).
- Comme `/cl pack <sha1>` est maintenant disponible, tu peux tester ce changement **sans
  redémarrer le serveur** : uploade le nouveau pack, lance `/cl pack <sha1>`, regarde le tab.

## Nouveautés 0.5.2

- **`/cl pack <sha1>`** : repousse le resource pack (URL fixe dans `config.yml`) à tous les
  joueurs déjà connectés via l'API `Player#setResourcePack`, sans redémarrage serveur. Pense à
  quand même mettre à jour `resource-pack-sha1` dans `server.properties` pour les prochaines
  connexions. Pour le code du plugin, le `/reload confirm` vanilla (déjà existant, rien à
  coder) recharge les plugins depuis leur `.jar` sans redémarrage — raisonnablement sûr pour
  ce plugin vu qu'il nettoie proprement ses listeners, mais pas garanti sans risque selon le
  reste du serveur.
- **Badges tab-list refaits avec une meilleure technique** : au lieu de "dessiner" le texte en
  pixels dans une image (résolution limitée), le badge est maintenant une image de fond SEULE
  (juste le rectangle coloré) + le texte du rank écrit avec la vraie police Minecraft (nette,
  native) posé par-dessus via un espace négatif — même principe que le panneau du clicker.
  ⚠️ Le calage (largeur du rewind, marges) est une estimation basée sur la largeur standard des
  lettres en gras — comme toujours avec cette technique, attends-toi à devoir ajuster après un
  premier test en jeu si le texte déborde du fond ou n'est pas bien centré.

## Nouveautés 0.5.1

- **Badges tab-list corrigés** : hauteur réduite (12→9) pour ne plus déborder de la ligne.
- **Anti-aliasing retiré** des textures de badges : alpha seuillé en dur (binaire, pas de
  dégradé), downscale en NEAREST au lieu de LANCZOS — contours nets façon pixel art.
- **Bug du pseudo illisible corrigé** : la police custom du badge se propageait au texte du
  pseudo ajouté juste après (héritage de style en Adventure), donc le jeu cherchait les
  lettres normales dans une police qui ne contient que le glyphe du badge → cases vides.
  Police réinitialisée explicitement sur l'espace et le pseudo.
- **`/rankup` remplacé par `/setrank <pseudo> <rank>`** : définit directement n'importe quel
  rank (staff ou non), avec auto-complétion (pseudos connectés puis noms de rank). Corrige le
  trou de conception (impossible de donner le tout premier rank staff).

## Nouveautés 0.5.0

- **Pelles renommées** : "Clicker Upgrader X" → **"Pelle Tier X"** partout (tooltips, messages).
- **Fric → Dirt** : renommage complet de la monnaie affichée. Symbole `$` → **`ɗ`**, couleur
  passée du vert au **marron** (`#8B5A2B`) partout où une valeur est affichée (scoreboard,
  tooltips, messages admin). Les identifiants internes du code (méthodes `getFric`,
  classe `FricScoreboardManager`, etc.) n'ont pas été renommés — seul l'affichage change,
  pour ne pas risquer de casser quoi que ce soit inutilement.
- **Système de rank ajouté** : 2 ranks pour l'instant — `Dirty` (marron, rank joueur par
  défaut) et `Admin` (rouge foncé, rank staff). Nouveau fichier `ranks.yml`.
- **Badges dans le tab-list** : rectangle stylisé coloré avec le nom du rank à l'intérieur,
  devant le pseudo — via la même technique de police bitmap custom que les interfaces (donc
  ⚠️ expérimental, comme toujours avec cette technique : attends-toi à devoir ajuster la
  taille/position après un premier test en jeu).
- **Commande `/rankup <pseudo>`** (admin uniquement) : fait passer un joueur à son rank STAFF
  suivant. ⚠️ **Ne fonctionne QUE si le joueur a déjà un rank staff** — comme demandé, "Dirty"
  n'étant pas un rank staff, `/rankup` n'a aucun effet dessus. Actuellement il n'y a qu'un seul
  rank staff (Admin), donc **il n'existe pour l'instant aucune commande pour donner le tout
  premier rank staff à quelqu'un** (`/rankup` ne peut que faire progresser un staff existant
  vers un rank staff supérieur, qui n'existe pas encore). Dis-moi si tu veux que j'ajoute un
  `/setrank <pseudo> <rank>` pour combler ce manque, ou si un autre rank staff plus bas arrive
  bientôt et rend ça inutile.

⚠️ **La pelle tier 4 demandée juste avant n'a pas encore été traitée** — aucune caractéristique
n'a été précisée (matériau, nombre d'achats, bonus/clic, prix, croissance), contrairement aux
tiers 2/3 où tu m'avais tout donné. Dis-moi ces valeurs et je l'ajoute.

## Nouveautés 0.4.4 — bug de fond sur le prix de la fiole, trouvé et corrigé

Le prix de la fiole réutilisait `LevelCurve.xpForNextLevel()`, qui retourne des valeurs
**arrondies à l'entier**, prévues à l'origine pour les niveaux d'xp du joueur (où l'arrondi ne
se voit pas, les nombres sont énormes). Appliqué au nombre d'achats de la fiole (qui part de 0),
les toutes premières valeurs de la table (10, 10, 10, 11...) sont quasi identiques à cause de cet
arrondi — donc le prix de la fiole restait plat sur les 2-3 premiers achats avant de "sauter" par
paliers, au lieu de progresser en douceur.

Correctif : nouvelle méthode `LevelCurve.preciseXpForNextLevel()` qui calcule la valeur EXACTE
(non arrondie), utilisée uniquement pour ce calcul de prix (les niveaux d'xp du joueur, eux,
continuent d'utiliser la table arrondie comme avant — aucun changement ailleurs). Le prix de la
fiole progresse maintenant achat par achat sans paliers plats : $3000, $3058, $3117, $3177...

## Nouveautés 0.4.3

- **Nouveaux prix des 4 améliorations Strong Upgrade** : Fric x2 $17 000, XP x2 $19 000,
  Better Shovel $15 500, Better Experience $12 800 (total $64 300).
- **Prix de la fiole d'xp augmenté drastiquement** : multiplicateur x12 → **x300** (x25).
  1er achat : $120 → **$3 000**. À 50 achats : $1 740 → **$8 700**. À 100 achats :
  $5 100 → **$25 500**.

## Nouveautés 0.4.2

- **Tier 3 pelle** : croissance x1.1 → **x1.14**. Dernier achat (60/60) : **$22 772**.
- **Nouveaux prix des 4 améliorations Strong Upgrade** : Fric x2 $9000, XP x2 $7000,
  Better Shovel $8500, Better Experience $6800 (total $31 300, plus proche de la fourchette
  $80k-120k suggérée mais encore en dessous — à toi de voir si ça suffit après test).

## Nouveautés 0.4.1

- **Tier 2 pelle** : croissance x1.1 → **x1.18**. Dernier achat (40/40) : **$1 272**.
- **Tier 3 pelle** : croissance x1.2 → **x1.1**. Dernier achat (60/60) : **$2 769**.
- **Bug scoreboard corrigé** : les achats dans Strong Upgrade ne mettaient jamais à jour le
  Fric affiché (le listener n'avait jamais reçu le scoreboardManager).
- **Nouveaux prix des 4 améliorations** : Fric x2 $5000, XP x2 $4000, Better Shovel $7500,
  Better Experience $4800.
  ⚠️ **Question de cohérence posée** : avec ces prix, un joueur peut se les payer en quelques
  centaines de clics une fois la pelle tier3 bien avancée (gain déjà ~$26/clic à tier3 40/40),
  donc largement AVANT de finir le tier3 — pas juste avant comme visé. Si tu veux qu'elles
  restent un vrai palier de fin de tier3, viser plutôt $80 000-120 000 cumulés serait plus
  cohérent. Je les ai intégrées telles quelles, à toi de trancher.
- **Bouton "Retour"** ajouté (bas-gauche de Strong Upgrade), flèche custom, referme et rouvre
  le clicker principal.
- **Textures Better Shovel / Better Experience refaites**, inspirées des items vanilla
  (silhouette de pelle en fer / fiole d'xp) avec des pics dorés ajoutés — bien plus lisibles
  que la première version.

## Nouveautés 0.4.0

- **Bug de la fiole corrigé** : le prix était basé sur le niveau d'xp *live* du joueur, qui
  change à chaque clic sur le bloc de terre (puisque les clics donnent de l'xp une fois la
  fiole débloquée) — le prix fluctuait donc sans qu'aucun achat n'ait eu lieu. Il est maintenant
  basé sur le nombre d'achats de la fiole elle-même, qui n'évolue qu'à l'achat.
- **Tier 2 de la pelle adouci encore plus** : croissance x1.3 → **x1.1**. Dernier achat (40/40) :
  **~$83** (calculé avec la formule actuelle).
- **Tier 3 de la pelle adouci** : croissance x1.4 → **x1.2**. Dernier achat (60/60) :
  **~$469 563** (calculé avec la formule actuelle).
- **4 nouvelles améliorations permanentes** dans l'interface Strong Upgrade, toutes à achat
  unique, réinitialisées par `/cl reset` :
  - **Fric x2** ($50 000) : double le gain de Fric par clic
  - **XP x2** ($50 000) : double l'xp gagnée par clic
  - **Better Shovel** ($30 000) : +$0.1/clic à TOUS les achats de pelle, effet rétroactif inclus
  - **Better Experience** ($30 000) : +0.1xp/clic à TOUS les achats de fiole, effet rétroactif inclus

  Chaque item affiche "Acheté"/"Non acheté" au survol, et devient enchanté (lueur, sans texte
  d'enchantement visible) une fois acheté. 4 nouvelles textures ajoutées au resource pack.

⚠️ **Prix des 4 nouvelles améliorations non précisés par toi — valeurs proposées par défaut**
  ($50k/$50k/$30k/$30k). Dis-moi si tu veux ajuster.

## Nouveautés 0.3.0

- **Prix du tier 2 de la pelle adouci** : croissance passée de x1.5 à **x1.3** par achat (base
  $2 inchangée). Avant, ~$876 au 16e achat et ça explosait vite ; maintenant le dernier achat
  (40/40) coûte environ $55 000 au lieu de milliards — beaucoup plus jouable.
- **Tier 3 de la pelle ajouté** : pelle en fer, **60 niveaux**, +$0.4/clic par achat, prix dès
  $10 avec une croissance de **x1.4** (plus raide que le tier 2, comme demandé — plus dur à
  maxer). Se débloque en maxant le tier 2 (40/40), fait apparaître un item d'amélioration sous
  la pelle (lingot de netherite pour l'instant, remplaçable par une tête custom via la
  bibliothèque `CustomHeads` déjà en place), clic gratuit et instantané.
- **Nouvel item "Strong Upgrade"** : papier avec texture custom (flèche verte vers le haut,
  aura jaune — nouvelle icône ajoutée au resource pack). Positionné 2 slots à droite du bloc de
  terre. Apparaît en bedrock (verrouillé, "pelle tier 3") dès le premier achat de la fiole
  d'xp ; se débloque définitivement en atteignant la pelle tier 3. Un clic ouvre une **nouvelle
  interface à 6 lignes**, vide pour l'instant (structure prête pour du contenu futur), avec le
  même style que le clicker principal mais en **vert** (liserés gris identiques).

Le resource pack a aussi été mis à jour (nouveau panneau vert + icône flèche) — pense à
remplacer les deux fichiers et à mettre à jour le SHA-1.

## Nouveautés 0.2.4

- **Bug du bedrock manquant, trouvé et corrigé** : quand la pelle se débloquait via un clic sur
  le bloc de terre, le slot de la fiole n'était jamais mis à jour pour passer en bedrock — seul
  `/cl fric give` reconstruisait tous les slots d'un coup (d'où le fait que ça "marchait" après
  un give). Le slot de la fiole est maintenant mis à jour à l'instant précis où la pelle se
  débloque.
- **Label "Bonus xp" renommé en "Bonus Fric"** sur le bloc de terre — c'était bien le
  multiplicateur de Fric par niveau qui s'affichait, pas un bonus d'xp. Valeurs inchangées.
- **Niveau de la fiole replafonné à 1000** (comme le niveau d'xp du joueur) : affiché
  "Niveau : X / 1000" dans son tooltip, achat bloqué et bloqué au maximum au-delà.

## Nouveautés 0.2.3

- **Bibliothèque de têtes customs** (`fr.geven.clicker.util.CustomHeads`) : structure réutilisable
  pour toute future tête custom. Je n'ai pas pu récupérer de texture vérifiée sur
  minecraft-heads.com (bloque les requêtes automatisées) — instructions dans le fichier pour
  coller toi-même la valeur base64 de ton choix, un simple copier-coller, rien d'autre à changer.
  Tant qu'aucune valeur n'est renseignée, l'item d'amélioration tier 2 reste un lingot de
  netherite (repli automatique, jamais de tête cassée affichée).
- **Symbole $ en suffixe partout** : "1 234.5$" au lieu de "$1 234.5", changé une fois pour
  toutes dans `NumberFormatting` (scoreboard, tooltips, tout en hérite automatiquement).
- **Tooltip de la fiole clarifié** : n'affiche plus le niveau d'xp du joueur (ça, c'est le
  scoreboard) — affiche désormais "Niveau de l'amélioration : X" (le nombre d'achats de la
  fiole elle-même).
- **Prix de la fiole légèrement augmenté** : multiplicateur passé de x10 à **x12** sur l'xp du
  niveau suivant (formule : `12 × xpForNextLevel(niveau actuel du joueur)`, donc $120 au
  niveau 0 au lieu de $100).
- Le bloc de bedrock pour la fiole verrouillée : j'ai relu tout le code concerné, la logique est
  bien présente et correcte à tous les points où je l'ai vérifiée — je n'ai pas trouvé de
  régression. Si le problème persiste après ce build, dis-moi à quel moment exact ça se produit.

## Nouveautés 0.2.2

- **Bug de compilation corrigé** : `bottlePurchases` était redéclaré deux fois dans
  `ClCommand.refreshAllSlots` (repéré par Replit sur ton autre serveur, merci) — supprimé.
- **Gabarit d'amélioration** : remplacé par un lingot de netherite (`NETHERITE_INGOT`) au lieu
  du gabarit de forge. Le gabarit avait un tooltip spécial ("S'applique à / Ingrédients") câblé
  en dur côté client pour ce type d'item précis, non masquable par les ItemFlags standards —
  changer de matériau était la seule vraie solution.
- **Tooltip de la pelle condensé** : "+$0.1/clic par achat" (plus besoin de répéter "Fric"
  puisque le symbole $ le dit déjà), code couleur vert conservé.
- **Prix de la fiole corrigé** : restauré la formule d'origine sur laquelle on s'était mis
  d'accord (10× l'xp du niveau suivant, soit $100 au niveau 0) au lieu de la courbe inventée par
  erreur la dernière fois. Le prix suit donc le **niveau d'xp actuel du joueur**, pas le nombre
  d'achats déjà faits — plus de plafond arbitraire de 50 achats, le prix grimpe naturellement
  avec le niveau jusqu'à devenir prohibitif proche du niveau 1000.
- **Affichage "xp par clic" corrigé** : affiche maintenant la valeur exacte (ex: "2.6") au lieu
  d'être arrondie à l'entier alors que le détail entre parenthèses montrait la valeur précise.

## Nouveautés 0.2.1

- **Mécanique de la fiole corrigée** : les achats de la fiole n'achètent plus un niveau d'xp
  directement. Une fois débloquée (pelle tier 2), **chaque clic sur le bloc de terre rapporte
  aussi de l'xp** : 1 point de base + 0.2 par achat d'amélioration de la fiole (cumulatif). Le
  joueur monte de niveau naturellement au fil des clics ; chaque niveau garde son bonus de Fric
  habituel (`FricBonus`, +x0.2 par niveau, inchangé).
  ⚠️ Le prix/nombre d'achats max de cette amélioration (nouvelle classe `BottleUpgrade`)
  n'avaient pas été précisés — valeurs proposées par défaut : $5 de base, croissance x1.3,
  50 achats max. Ajustable facilement si besoin.
- **Condition de déblocage de la pelle** : la valeur en Fric est maintenant en vert clair,
  au format "X.Y$" (suffixe) au lieu de "$X.Y" (préfixe).
- **Tier 2 de la pelle** : prix du premier achat passé à $2 (au lieu de $1, comme le tier 1).
- **Tooltips vanille masqués** sur la pelle et le gabarit d'amélioration netherite (infos
  d'attaque/durabilité, "s'applique à / ingrédients").
- Les lignes `minecraft:xxx` / `N composant(s)` visibles sur tes screenshots viennent du mode
  F3+H (tooltips avancés) de ton client — un réglage local, pas quelque chose que le plugin
  peut ou doit masquer.

## Nouveautés 0.2.0 — système de déblocage progressif

**Nouveau joueur / après `/cl reset`** : seul le bloc de terre (Fric) est utilisable dès le départ.

- **Pelle "Clicker Upgrader"** : apparaît verrouillée (bloc de bedrock, tooltip "Non débloqué —
  Conditions de déblocage : posséder $1"). Dès que le joueur possède $1 (même en le dépensant
  juste après), elle se débloque **définitivement** et devient la pelle en bois habituelle.
- **Fiole d'xp** : totalement absente de l'interface tant que la pelle n'est pas débloquée.
  Une fois la pelle débloquée, elle apparaît à son tour verrouillée (bedrock, tooltip "Non
  débloqué — Conditions de déblocage : pelle tier 2"), jusqu'à ce que la pelle atteigne le tier 2.
- **Tooltip de la fiole enrichi** : affiche maintenant aussi le bonus de Fric apporté par le
  niveau actuel et celui du niveau suivant (`Bonus actuel : x1.2` / `Niveau suivant : x1.4`).

**Tiers de la pelle** :
- Tier 1 (bois) : inchangé — 20 achats, +$0.1/clic chacun, prix dès $1 (x1.35 par achat).
- Une fois le tier 1 à 20/20, un **gabarit d'amélioration en netherite** apparaît juste en
  dessous de la pelle dans l'interface. Son tooltip : "Pelle tier 1 > tier 2, avantage :
  +$0.1/clic > +$0.2/clic". Cliquer dessus améliore la pelle **instantanément et gratuitement**
  au tier 2 (pelle en pierre), débloque la fiole d'xp au passage, et fait disparaître le gabarit.
- Tier 2 (pierre) : 40 achats, +$0.2/clic chacun, prix dès $5, croissance x1.5 (nettement plus
  raide que le tier 1, comme demandé).

Toute cette progression est sauvegardée par joueur (`playerupgrades.yml`, structure enrichie) et
correctement remise à zéro par `/cl reset`.

## Nouveautés 0.1.2 — la vraie cause de l'assombrissement, enfin trouvée

Depuis le début de la section resource pack, chaque couleur que je générais rendait plus sombre
en jeu que dans le fichier source — j'ai longtemps supposé un effet moteur inévitable et essayé
de compenser en éclaircissant les couleurs à l'aveugle. **Ce n'était pas ça.**

La vraie cause : le titre de l'inventaire (le texte qui invoque notre image de fond via la police
custom) n'avait **aucune couleur explicite définie**. Or les titres de coffre vanilla sont teintés
en gris foncé par défaut (pas blanc) — cette teinte se multipliait avec absolument tout ce que
dessinait l'image (fond, liserés, tout), assombrissant uniformément chaque pixel.

Correctif : `.color(NamedTextColor.WHITE)` ajouté sur le Component du titre. Le blanc neutre en
multiplication ne change rien aux couleurs réelles de l'image — tout devrait enfin s'afficher
avec les couleurs exactes du fichier source, liserés inclus.

## Nouveautés 0.1.0 — changement architectural majeur

**`/clicker` (et le raccourci hotbar) ouvrent désormais un menu 100% custom en entités
d'affichage**, au lieu d'un inventaire-coffre reskiné :

- Le menu est composé d'entités **Item Display** (icônes), **Text Display** (titre,
  statistiques) et **Interaction** (hitboxes invisibles qui détectent les clics — mécanisme
  natif Minecraft, pas de calcul de trajectoire à la main).
- Il apparaît **ancré devant le joueur** à l'ouverture (pas collé à la caméra) et se **ferme
  automatiquement** si le joueur s'éloigne de plus de 6 blocs — comme un coffre vanille.
- Un **bouton "Fermer"** cliquable est présent dans le menu.
- La logique de jeu (gains de Fric, achat de niveau d'xp, achat d'amélioration) est
  **strictement identique** à l'ancien système — mêmes managers, mêmes formules, aucune
  donnée de sauvegarde affectée.

⚠️ **Cette fonctionnalité est expérimentale et n'a pas pu être testée en jeu de mon côté.**
Contrairement au resource pack (où je pouvais au moins vérifier les fichiers), ce système
repose sur des API d'entités (Display, Interaction) que je ne peux absolument pas valider sans
un vrai client Minecraft. Attends-toi à devoir remonter des bugs précis (positionnement,
clics qui ne répondent pas, entités qui restent affichées, etc.) pour qu'on itère dessus.

**L'ancien système en inventaire-coffre reste dans le code** (fichiers `ClickerGui`,
`ClickerGuiListener`, `ClickerHolder`, `GuiOpener` intacts, simplement plus appelés par défaut)
au cas où il faille y revenir rapidement.

## Nouveautés 0.0.5

- Le titre de l'inventaire `/clicker` est désormais composé de deux caractères spéciaux invoquant
  une image de fond custom via la police du resource pack (`gevent_clicker:clickerbg`), au lieu
  d'un simple texte "Gevent Clicker". Ceci isole le thème visuel custom à cette interface
  uniquement — les vrais coffres du serveur restent 100% vanille. Voir le README du resource pack
  pour le détail technique.

- Le raccourci hotbar est maintenant un `minecraft:paper` (au lieu de `minecraft:dirt`), pour
  être compatible avec le resource pack "Gevent Clicker Pack" (voir plus bas).
- Tous les slots inutilisés de l'interface `/clicker` sont désormais comblés par un item de
  remplissage décoratif (papier vide, non cliquable — même protection que les autres items du
  GUI).

## Resource pack "Gevent Clicker Pack"

Un resource pack compagnon est fourni séparément (`GeventClickerPack.zip`) :
- Reskin du raccourci hotbar en pointeur de souris.
- Reskin des slots inutilisés du GUI en carrés doux arrondis (au lieu de cases grises vides).
- **Sans le pack installé, tout reste fonctionnel** : le raccourci est juste un papier normal,
  les slots de remplissage sont du papier vide — rien n'est cassé.

Voir le README inclus dans le pack pour le détail technique et une limitation actuelle assumée
(le fond du coffre lui-même n'est pas encore retravaillé, faute de référence exacte disponible
dans mon environnement).

## Versioning

À partir de cette mise à jour, le suivi de version suit ce schéma (comme demandé) :
- Petite mise à jour : `+0.0.1` (ex: 0.0.1 → 0.0.2 → 0.0.3...)
- Moyenne mise à jour : `+0.1.0` (sur ton signal)
- Grosse mise à jour : `+1.0.0` (sur ton signal)

Le tout premier envoi portait par erreur le numéro `1.0.0` (choix arbitraire de ma part, pas
volontairement une "grosse mise à jour"). Cette mise à jour recale donc la base à `0.0.2`, en
traitant l'envoi précédent comme un `0.0.1` implicite. Le numéro de version est mis à jour dans
`pom.xml`, `plugin.yml`, et se répercute automatiquement dans le nom du `.jar` final.

## Résilience au `/reload`

Le plugin est conçu pour bien se comporter avec `/reload` : pas de tâche planifiée qui pourrait
fuiter, sauvegarde systématique des données à la désactivation, scoreboards reconstruits à neuf
à chaque activation (pas de conflit d'objectif existant), et désenregistrement explicite de tous
les écouteurs à la désactivation.

Cela dit, `/reload` reste **déconseillé par les développeurs de Paper eux-mêmes** pour un usage
en production : ce n'est pas spécifique à ce plugin, mais au fonctionnement de `/reload` sur
Bukkit/Paper en général (autres plugins mal codés, fuites mémoire au niveau du classloader du
serveur, désynchronisations diverses). Un simple `/stop` + redémarrage reste la méthode la plus
sûre pour appliquer une mise à jour. Je ne peux pas garantir un comportement 100% fiable de
`/reload` puisque ça dépend aussi du serveur et des autres plugins installés — mais côté
Gevent_Clicker, tout est fait pour que ça se passe bien.

## Fonctionnalités

### Clicker Fric
- `/clicker` **ou** un clic sur le bloc de terre de la hotbar ouvre l'interface (6 lignes).
- Bloc de terre (slot 22) : chaque clic ajoute du Fric (vert, symbole `$`), sauvegardé de
  façon persistante.
- Gain par clic = `(0.1 + bonus Clicker Upgrader) × multiplicateur de niveau d'xp`.
- Le tooltip n'affiche plus le détail du bonus "Clicker Upgrader" (retiré sur demande, la
  stat reste calculée en interne — sera réaffichée ailleurs plus tard).

### Fiole d'expérience — achetable (slot 4, tout en haut au milieu)
- Achète un niveau d'xp en dépensant du Fric. Prix = `10 × xp(niveau)` (de $100 au niveau 0
  à $20 milliards au niveau 999→1000).
- Survol : nom, niveau actuel / 1000, prix du prochain niveau (ou "maximum atteint").
- Clic : si assez de Fric, achète le niveau suivant (déduction immédiate, montée de niveau,
  mise à jour scoreboard + barre d'xp vanille + tooltip du bloc de terre). Sinon, message
  d'erreur discret (action bar) + son de refus.

### Clicker Upgrader — pelle en bois, tier 1 (slot 20, 2 slots à gauche du bloc de terre)
- +$0.1 de gain de base par clic, à chaque achat, **jusqu'à 20 achats**.
- Prix : `⌈1 × 1.35^k⌉` pour le k-ième achat (k = 0 à 19) → $1 au 1er achat, ≈$300 au 20e
  (total pour tout maxer ≈ $1163). Croissance douce, cohérente avec un item de tier 1 (à
  comparer aux montants bien plus élevés de l'xp, qui va jusqu'à 20 milliards).
- Survol : titre "Clicker Upgrader 1", achats actuels / 20, prix du prochain achat.
- Les tiers suivants (pelle en pierre = tier 2, etc.) seront ajoutés plus tard, sur tes
  instructions — la structure du code est prête à les recevoir.

### Bonus de Fric lié au niveau d'xp (inchangé, comme demandé)
- Multiplicateur = `1 + 0.2 × niveau` (x1.2 au niveau 1, x1.4 au niveau 2, etc.), appliqué à
  l'ensemble du gain par clic (base + bonus Clicker Upgrader).

### Bloc de terre "raccourci" (hotbar)
- Toujours présent au slot 4 (milieu) de la hotbar, indéplaçable, survit à la mort.
- Clic (en main ou dans un inventaire) ouvre `/clicker`.

### Scoreboard (toujours affiché)
- Ligne **Fric** : vert, `$123.4`.
- Ligne **Expérience** : aqua, `Niveau <nombre> à <pourcentage>%`.
- Bug d'affichage ("a"/"b" parasites) corrigé.

### Système d'XP custom (niveaux 0 à 1000)
- Xp vanille entièrement bloquée ; xp uniquement via achat (fiole) ou commande admin.
- Formule : `xp(n) = 10 × r^n`, `r ≈ 1.01932`, `xp(999) = 2 000 000 000` exactement.

### Commande admin de test
```
/cl fric give <pseudo> <nombre>
/cl fric remove <pseudo> <nombre>
/cl xp give <pseudo> <nombre>
/cl xp remove <pseudo> <nombre>
```
Permission `geventclicker.admin` (OP par défaut).

## Choix de conception à connaître

- **Ordre des bonus** : le gain par clic est `(base + bonus Clicker Upgrader) × multiplicateur xp`.
  Le multiplicateur de niveau s'applique donc aussi au bonus de la pelle, pas seulement à la
  base — ça amplifie encore l'intérêt de monter de niveau. Dis-moi si tu préfères que le
  multiplicateur xp ne s'applique qu'à la base fixe (0.1) et pas aux améliorations achetées.
- Le Fric donné via `/cl fric give` reste un ajout brut (non multiplié), pour des tests précis.
- Achat de la fiole d'xp et de la pelle : mêmes protections anti double-clic/spam que le
  bloc de terre (debounce 40ms par slot).

## Compilation

```bash
mvn clean package
```

Jar final : `target/gevent-clicker-1.0.0.jar`, à placer dans `plugins/` de ton serveur
Paper 26.2.

> ⚠️ Toujours pas d'accès réseau dans mon environnement pour tirer les dépendances Paper et
> compiler moi-même. Code relu attentivement, formules testées séparément en Python — compile
> chez toi et envoie-moi la moindre erreur, je corrige immédiatement.
